package com.em.browser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebChromeClient
import android.webkit.WebStorage
import android.webkit.WebViewDatabase
import java.io.File
import java.util.Locale
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.animation.ObjectAnimator
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Button
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.os.LocaleListCompat
import androidx.core.view.ViewCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.core.content.ContextCompat
import androidx.webkit.Profile
import androidx.webkit.ProfileStore
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.snackbar.Snackbar
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.BarcodeFormat

class MainActivity : AppCompatActivity() {


    @Volatile private var isResettingBrowser = false

    private data class BrowserTab(
        var webView: WebView,
        var profileName: String = Profile.DEFAULT_PROFILE_NAME,
        var title: String = "New tab",
        var thumbnail: Bitmap? = null,
        var accountRecoveryModeApplied: Boolean = false
    )

    private inner class InspectBridge {
        @JavascriptInterface
        fun report(payload: String) {
            runOnUiThread { showInspectDetails(payload) }
        }
    }

    private val inspectBridge = InspectBridge()
    @Volatile private var recoveryActionPermit = ""
    private inner class RecoveryActionGuard {
        @JavascriptInterface
        fun permitted(token: String): Boolean = token.isNotBlank() && recoveryActionPermit == token
    }
    private val recoveryActionGuard = RecoveryActionGuard()

    private class CredentialDocument(val generation: Long) {
        var committedUrl: String? = null
        var documentId: String? = null
        var token: String? = null
        var attempt = 0L
        // Ignore older successful callbacks without waiting for newer ones to arrive.
        var confirmedAttempt = 0L
    }
    private val credentialDocuments = java.util.WeakHashMap<WebView, CredentialDocument>()
    private val credentialEnabledViews = java.util.WeakHashMap<WebView, Boolean>()
    private var credentialCompatibilityWarningShown = false

    private fun credentialHost(uri: android.net.Uri?): String? {
        if (uri == null || !uri.scheme.equals("https", true)) return null
        val host = uri.host?.lowercase(Locale.US) ?: return null
        if (host !in setOf("accounts.google.com", "myaccount.google.com")) return null
        val authority = uri.encodedAuthority ?: return null
        if (!authority.equals(host, true) && !authority.equals("$host:443", true)) return null
        return host
    }

    private inner class CredentialBridge : WebViewCompat.WebMessageListener {
        override fun onPostMessage(
            view: WebView,
            message: WebMessageCompat,
            sourceOrigin: android.net.Uri,
            isMainFrame: Boolean,
            replyProxy: JavaScriptReplyProxy
        ) {
            if (!isMainFrame || credentialEnabledViews[view] != true || isResettingBrowser ||
                isFinishing || isDestroyed || automationActivityStopped ||
                !lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED) ||
                view !== currentWebView() || !view.isAttachedToWindow || tabs.none { it.webView === view }) return
            val originHost = credentialHost(sourceOrigin) ?: return
            val currentUrl = view.url ?: return
            if (credentialHost(android.net.Uri.parse(currentUrl)) != originHost) return
            val document = credentialDocuments[view] ?: return
            if (credentialHost(android.net.Uri.parse(document.committedUrl.orEmpty())) != originHost) return
            val data = runCatching { message.data }.getOrNull() ?: return
            if (data.length > 65_536) return
            val request = runCatching { JSONObject(data) }.getOrNull() ?: return
            val id = request.opt("id") as? String ?: return
            val operation = request.opt("operation") as? String ?: return
            val url = request.opt("url") as? String ?: return
            val token = request.opt("token") as? String ?: return
            val documentId = request.opt("documentId") as? String ?: return
            if (id.length !in 1..80 || !id.all { it.isLetterOrDigit() || it == '-' } ||
                token != document.token || documentId != document.documentId || url != currentUrl) return

            val value = when (operation) {
                "processRow" -> {
                    val raw = request.opt("value") as? String ?: return
                    val row = parseCredentialRow(raw)
                    if (row != null) saveCredentialRow(row)
                    row?.email.orEmpty()
                }
                "password" -> getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(KEY_PASSWORD_CURRENT, passwordAutomationCurrent).orEmpty()
                "recovery" -> getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(KEY_RECOVERY_EMAIL_VALUE, recoveryEmailValue).orEmpty()
                "totp" -> {
                    val uri = android.net.Uri.parse(currentUrl)
                    val setupCode = authenticatorAutomationActive && authenticatorAutomationView === view &&
                        authenticatorAutomationStage in setOf("qr", "code") &&
                        originHost == "myaccount.google.com" &&
                        uri.path.orEmpty().trimEnd('/').equals("/two-step-verification/authenticator", true)
                    if (setupCode) "" else currentTotpCode()
                }
                else -> return
            }
            replyProxy.postMessage(JSONObject().put("id", id).put("value", value).toString())
        }

        // This is also called directly by the native recovery-page probe, not by JavaScript.
        fun updateDetectedRecoveryEmail(value: String) {
            val email = extractEmailFromText(value)
            runOnUiThread { updateSavedAccountRecovery(email, currentWebView()?.let { accountKeyByWebView[it] }) }
        }

        private fun currentTotpCode(): String {
            val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
            val storedTwoFa = prefs.getString(KEY_TWO_FA_LINK, "").orEmpty()
            val secret = extractBase32Secret(storedTwoFa) ?: authenticatorSecret.takeIf { it.isNotBlank() }
            if (secret.isNullOrBlank()) return ""
            return runCatching {
                val now = System.currentTimeMillis()
                val period = authenticatorPeriod
                val code = generateTotp(secret, now, authenticatorAlgorithm, authenticatorDigits, period)
                val expiresAt = (now / 1000L / period + 1L) * period * 1000L
                JSONObject().put("code", code).put("expiresAt", expiresAt).toString()
            }.getOrNull().orEmpty()
        }
    }

    private val credentialBridge = CredentialBridge()

    private val tabs = mutableListOf<BrowserTab>()
    private var activeTab = 0
    private var accountRecoveryModeEnabled = false
    // True once the very first tab of this app session has been created. addTab used to
    // decide "give this tab the shared default profile" purely from tabs.isEmpty() — which
    // is also true after the person closes every tab and then opens a new one, handing that
    // "new" tab the same profile (so the same cookies/session) as whatever was open before,
    // which looked exactly like the old tab coming back instead of a genuinely fresh one.
    private var hasCreatedFirstTabThisSession = false
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var rootLayout: LinearLayout
    private lateinit var chromeBar: LinearLayout
    private lateinit var addressBar: android.widget.EditText
    private lateinit var tabCountView: TextView
    private lateinit var contentFrame: LinearLayout
    private lateinit var pageProgress: ProgressBar
    private lateinit var sideMenu: LinearLayout
    private lateinit var sideMenuScroll: MaxHeightScrollView

    /**
     * A ScrollView that hugs its content's height up to [maxHeightPx], and only becomes
     * scrollable beyond that. With a plain ScrollView, WRAP_CONTENT never scrolls (it just
     * grows to fit everything) and MATCH_PARENT always leaves empty space when the content
     * is shorter than the screen — this is the standard way to get "hug content, but cap
     * and scroll past a limit" instead.
     */
    private class MaxHeightScrollView(context: android.content.Context) : android.widget.ScrollView(context) {
        var maxHeightPx: Int = Int.MAX_VALUE
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val cappedSpec = if (maxHeightPx < Int.MAX_VALUE) {
                View.MeasureSpec.makeMeasureSpec(maxHeightPx, View.MeasureSpec.AT_MOST)
            } else heightMeasureSpec
            super.onMeasure(widthMeasureSpec, cappedSpec)
        }
    }
    private lateinit var systemBottomSpacer: View
    private var progressAnimator: ObjectAnimator? = null

    private var automationMasterEnabled = false
    private var inspectModeEnabled = false
    private var passwordAutomationEnabled = false
    @Volatile private var passwordAutomationActive = false
    private var passwordAutomationCurrent = ""
    private var appPasswordAutomationEnabled = false
    private var appPasswordAutomationActive = false
    private var appPasswordAutomationCreateClicked = false
    private var appPasswordAutomationSavePending = false
    private var appPasswordAutomationSaved = false
    private var appPasswordAutomationStartedAt = 0L
    private var youtubePremiumAutomationEnabled = false
    private var youtubePremiumAutomationActive = false
    private var youtubePremiumAutomationSaved = false
    private var youtubePremiumAutomationStartedAt = 0L
    private var youtubePremiumAutomationGeneration = 0L
    private var adsAutomationEnabled = false
    private var adsAutomationActive = false
    private var adsAutomationGeneration = 0L
    private var adsAutomationDocumentGeneration = 0L
    private var adsAutomationView: WebView? = null
    private var adsAutomationAccount = ""
    private var adsAutomationLoadedAt = 0L
    private var adsAutomationLoadFailed = false
    private var adsAutomationStartedAt = 0L
    // Per-account record of the Auto stages that already finished successfully.
    // Auto resumes from this record: a finished stage is skipped, never repeated.
    private val completedStagesByAccount = mutableMapOf<String, MutableSet<String>>()
    // Recovery email auto-extracted from a pasted credential row (email + password/secret +
    // recovery email, any order). Only used to auto-fill Google's "Enter recovery email
    // address" verification field — unrelated to the separate Recovery-removal automation.
    private var recoveryEmailValue = ""
    private var passwordAutomationNew = ""
    private var passwordChangeSubmitted = false
    private var passwordReauthSubmitted = false
    private var passwordConfirmationClickIssued = false
    private var passwordConfirmationToken = ""
    private var passwordAutomationView: WebView? = null
    private var passwordAutomationAccount = ""
    private var passwordAutomationSuccessPending = false
    // Hard guard for the entire password stage. This stays true across WebView
    // reloads/navigation and is cleared only after Google reports success or an
    // explicit password-change error.
    private var passwordFlowStartedForCurrentAutomation = false
    private var recoveryDirectRetryCount = 0
    private var recoveryEmailAutomationActive = false
    private var creationTimeAutomationEnabled = false
    private var creationTimeAutomationActive = false
    private var creationTimeAutomationProbeInFlight = false
    private var creationTimeAutomationWaitStartedAt = 0L
    private var creationTimeAutomationCompletionPending = false
    private var creationTimeAutomationGeneration = 0L
    private var devicesAutomationEnabled = false
    private var devicesAutomationActive = false
    private var devicesAutomationView: WebView? = null
    private var devicesAutomationAccount = ""
    private var devicesAutomationGeneration = 0L
    private var devicesAutomationDocumentGeneration = 0L
    private var devicesAutomationStartedUrl = ""
    private var devicesAutomationDocumentOrigin: Double? = null
    private var devicesAutomationPreviousDocumentOrigin: Double? = null
    private var devicesAutomationCommitted = false
    private var devicesAutomationFinishedAt = 0L
    private var devicesAutomationReadyAt = 0L
    private var devicesAutomationFailed = false
    private var devicesAutomationScheduledDocument = 0L
    private var devicesAutomationAccountNoticeShown = false
    private var devicesAutomationAwaitingVerification = false
    private var devicesAutomationVerificationNoticeShown = false
    private var devicesAutomationPaused = false
    private var devicesAutomationInitialPending = false
    private var devicesAutomationInitialReadyAt = 0L
    private var devicesAutomationInitialReadyOrigin = 0.0
    private var recoveryTargetForRun = ""
    private var recoverySaveIssued = false
    private var recoveryDoneIssued = false
    private var recoveryDoneAcknowledged = false
    private var recoveryActionPending = false
    private var recoveryFinishProbeInFlight = false
    private var recoveryTargetNoticeShown = false
    private class DevicesPageDocument(var url: String) {
        var committed = false
        var finished = false
        var revision = 0L
    }
    private val devicesPageDocuments = java.util.WeakHashMap<WebView, DevicesPageDocument>()
    private var backupAutomationEnabled = false
    private var backupAutomationView: WebView? = null
    private var backupAutomationAccount = ""
    private var backupAutomationSaveFailed = false
    private var backupAutomationGeneration = 0L
    private var backupAutomationDocumentGeneration = 0L
    private var automationActivityStopped = false
    private var backupAutomationProbeInFlight = false
    private var backupAutomationRunnable: Runnable? = null
    private var backupAutomationCandidateAccount = ""
    private var backupAutomationCandidateCodes = emptyList<String>()
    private var backupAutomationCandidateSince = 0L
    private var backupAutomationIgnoredAccount = ""
    private var backupAutomationIgnoredCodes = emptyList<String>()
    private var phoneNumbersAutomationActive = false
    private var phoneNumbersDeletePending = false
    private var phoneNumbersDeleteConfirmIssued = false
    private var phoneNumbersDeleteCountBeforeClick = 0
    private var phoneNumbersNoDeleteSince = 0L
    private var combinedAutomationWaitingForPassword = false
    private var automationCompletedForCurrentAccount = false
    private var automationHasRunInCurrentGoogleSession = false
    private var lastAutomationUrl = ""
    private var recoveryRemovalAwaitingVerification = false
    private var recoveryEmailPageOpened = false
    private var recoveryTrashClicked = false
    private var recoverySuccessNotificationSeen = false
    private var completedAccountKey = ""
    private var currentAccountKey = ""
    // Account identity is tracked per tab/WebView so Authenticator records from
    // different tabs are always written to the same app-wide log without mixing accounts.
    private val accountKeyByWebView = java.util.WeakHashMap<WebView, String>()
    private val backupCodePromptGenerations = java.util.WeakHashMap<WebView, Long>()
    private var authenticatorSecret = ""
    private var authenticatorLabel = ""
    private var authenticatorAlgorithm = "SHA1"
    private var authenticatorDigits = 6
    private var authenticatorPeriod = 30L
    private var authenticatorOtpauthUri = ""
    private var pendingAuthenticatorChange: TotpConfig? = null
    private var pendingAuthenticatorChangeAccount = ""
    private var pendingAuthenticatorChangeStartedAt = 0L
    private var authenticatorTimer: android.os.CountDownTimer? = null
    private var authenticatorAutomationEnabled = false
    private var authenticatorAutomationActive = false
    private var authenticatorAutomationStage = "idle"
    private var authenticatorAutomationQrScanned = false
    private var authenticatorAutomationCodeSubmitted = false
    private var authenticatorAutomationTurnOnClicked = false
    private var authenticatorAutomationFinalTurnOnClicked = false
    private var authenticatorAutomationFinalRefreshDone = false
    private var authenticatorAutomationSuccessSeen = false
    private var authenticatorAutomationLoadStarted = false
    private var authenticatorAutomationTrashClickIssued = false
    private var authenticatorAutomationRemoveAnywayClickIssued = false
    private var authenticatorAutomationRemoveOkClickIssued = false
    private var authenticatorAutomationRemovalToken = ""
    private var authenticatorAutomationView: WebView? = null
    private var authenticatorAutomationAccount = ""
    private var authenticatorAutomationSuccessPending = false
    private var authenticatorAutomationRemovalFlow = false
    private var authenticatorAutomationQrScanInFlight = false
    // Kotlin-side companion to the JS-only window.__emAuthenticatorSetupClickIssued guard:
    // that flag lives on the page's own document, so it resets if the click itself causes a
    // full page navigation (not just an in-page DOM change) — a narrow window where the old
    // document's pending callback and the new document's fresh check could each see an
    // unclicked button and both fire. This flag survives across that navigation instead.
    private var authenticatorAutomationSetupClickIssued = false
    private var twoStepAutomationEnabled = false
    private var twoStepAutomationActive = false
    private var twoStepAutomationView: WebView? = null
    private var twoStepAutomationAccount = ""
    private var twoStepAutomationStage = "idle"
    private var twoStepAutomationRefreshDone = false
    private var twoStepAutomationTurnOnClicked = false
    private var twoStepAutomationSkipClicked = false
    private var twoStepAutomationFallbackRefreshDone = false
    // Hard boundary between Auto stages: every hand-off gets one fixed 3s quiet period.
    private var automationStageHandoffPending = false
    private var automationHandoffGeneration = 0L
    private var automationLastHandoffStage = ""
    private var securityStageHandoffView: WebView? = null
    private var securityStageHandoffAccount = ""
    // Google may require the account password again between Auto stages. This
    // verifier pauses the current stage, submits the saved Current Password,
    // and resumes only after the verification page has been left.
    private var googleVerificationActive = false
    private var googleVerificationSubmitIssued = false
    private var googleVerificationNoticeShown = false
    private var googleVerificationCheckPending = false
    private var googleVerificationProbeInFlight = false
    private var googleVerificationGeneration = 0L

    companion object {
        private const val HOME_URL = "https://accounts.google.com/?hl=en"
        private const val AUTOMATION_STAGE_GAP_MS = 3000L
        private const val CREATION_TIME_DETECTION_TIMEOUT_MS = 15_000L
        private const val CREATION_TIME_SETTLE_DELAY_MS = 200L
        private const val CREATION_TIME_PROBE_INTERVAL_MS = 200L
        private const val RECOVERY_EMAIL_URL = "https://myaccount.google.com/recovery/email"
        private const val CREATION_TIME_URL = "https://myactivity.google.com/product/youtube/controls?hl=en&utm_source=my-activity"
        private const val DEVICES_URL = "https://myaccount.google.com/collection/recoveryemail?oev=lytf%3D7%26wvtx%3D6%26trs%3Dsae&utm_source=security-advisor&utm_medium=App&utm_campaign=sae&continue=https%3A%2F%2Fmyaccount.google.com%2Fsecurity-checkup%2F1%3Fcontinue%3Dhttps%253A%252F%252Fmyaccount.google.com%252F%253Futm_source%253Dsign_in_no_continue%26continue%3Dhttps%253A%252F%252Faccounts.google.com%252FServiceLogin%253Fcontinue%253Dhttps%253A%252F%252Fmyaccount.google.com%252F%253Futm_source%25253Dsign_in_no_continue%2526hl%253Den%2526authuser%253D0%2526passive%253Dtrue%2526sarp%253D1%2526aodrpl%253D1%2526checkedDomains%253Dyoutube%2526checkConnection%253Dyoutube%253A118%2526pstMsg%253D1%26flowType%3D1%26hl%3Den%26hl%3Den%26rapt%3DAEjHL4PqZfupej-C9TBiwCYOUAmFRSkWzQdFUycXJL-syfdv63U-6OPvsNEDQ4CKF542DApKTMhhrdo9GRJ1mOvQf_stMUSsYg%26rapt%3DAEjHL4PqZfupej-C9TBiwCYOUAmFRSkWzQdFUycXJL-syfdv63U-6OPvsNEDQ4CKF542DApKTMhhrdo9GRJ1mOvQf_stMUSsYg%26pli%3D1%26arec%3D1&hl=en&roc=true&opendialog=collectemail&rapt=AEjHL4PqZfupej-C9TBiwCYOUAmFRSkWzQdFUycXJL-syfdv63U-6OPvsNEDQ4CKF542DApKTMhhrdo9GRJ1mOvQf_stMUSsYg"
        private const val BACKUP_AUTOMATION_PROBE_INTERVAL_MS = 500L
        private const val BACKUP_AUTOMATION_SETTLE_MS = 2_000L
        private const val ACCOUNT_RECOVERY_URL = "https://accounts.google.com/v3/signin/recoveryidentifier?hl=en&source=esir&flowName=GlifWebSignIn"
        private const val PREFS = "browser_prefs"
        private const val KEY_TABS_STATE = "tabs_state"
        private const val KEY_ACTIVE_TAB = "active_tab"
        private const val KEY_AUTOMATION_MASTER_ENABLED = "automation_master_enabled"
        private const val KEY_INSPECT_MODE_ENABLED = "inspect_mode_enabled"
        private const val KEY_PASSWORD_AUTOMATION_ENABLED = "password_automation_enabled"
        private const val KEY_APP_PASSWORD_AUTOMATION_ENABLED = "app_password_automation_enabled"
        private const val KEY_PASSWORD_CURRENT = "password_automation_current"
        private const val KEY_PASSWORD_NEW = "password_automation_new"
        private const val KEY_CREATION_TIME_AUTOMATION_ENABLED = "creation_time_automation_enabled"
        private const val KEY_DEVICES_AUTOMATION_ENABLED = "recovery_stage_enabled"
        private const val KEY_BACKUP_AUTOMATION_ENABLED = "backup_automation_enabled"
        private const val KEY_ACCOUNT_RECOVERY_MODE_ENABLED = "account_recovery_mode_enabled"
        private const val KEY_AUTHENTICATOR_AUTOMATION_ENABLED = "authenticator_automation_enabled"
        private const val KEY_TWO_STEP_AUTOMATION_ENABLED = "two_step_automation_enabled"
        private const val AUTHENTICATOR_SETUP_URL = "https://myaccount.google.com/two-step-verification/authenticator"
        private const val KEY_TOTP_SECRET = "totp_secret"
        private const val KEY_TOTP_LABEL = "totp_label"
        private const val KEY_TOTP_ALGORITHM = "totp_algorithm"
        private const val KEY_TOTP_DIGITS = "totp_digits"
        private const val KEY_TOTP_PERIOD = "totp_period"
        private const val KEY_TOTP_ACCOUNTS = "totp_accounts"
        // Missing means a legacy/unknown owner; empty means explicitly entered for the next sign-in.
        private const val KEY_TOTP_OWNER = "totp_owner"
        private const val KEY_ACCOUNT_CHANGE_LOG_VERSION = "account_change_log_version"
        private const val KEY_STAGED_SIGN_IN_CREDENTIALS = "staged_sign_in_credentials"
        private const val KEY_TWO_FA_LINK = "two_fa_link"
        private const val KEY_RECOVERY_EMAIL_VALUE = "recovery_email_value"
        private const val KEY_RECOVERY_TARGETS = "recovery_targets_by_account"
        private const val TWO_STEP_SETUP_URL = "https://myaccount.google.com/signinoptions/twosv"
        private const val PASSWORD_SETUP_URL = "https://myaccount.google.com/signinoptions/password"
        private const val APP_PASSWORDS_URL = "https://myaccount.google.com/apppasswords"
        private const val YOUTUBE_PREMIUM_URL = "https://m.youtube.com/premium"
        private const val YOUTUBE_PREMIUM_TIMEOUT_MS = 30_000L
        private const val KEY_YOUTUBE_PREMIUM_AUTOMATION_ENABLED = "youtube_premium_automation_enabled"
        private const val ADS_URL = "https://ads.google.com/aw/signup/mobile/business?ocid=8675103592&euid=6674217783&__u=3880712767&uscid=8675103592&__c=8462509608&authuser=0&sourceid=emp&subid=ww-ww-xs-ip-awhc-a-ogb_cons!o2-EG-en-xs-ip-ogb_ai-sf-mw-uao-s500g500%7Cib:7317537941%7Cib:3763885777%7Cib:1232289030%7C-ahpm-0000000217-0000000004%7C-unqsi-CJWh1YHTkJgDFaAkdQEdfV09JQ-unqsi-uao-agembe-acce&utm_medium=et&utm_campaign=EG-en-xs-ip-ogb_ai-sf-mw-uao-s500g500%7Cib:7317537941%7Cib:3763885777%7Cib:1232289030%7C-ahpm-0000000217-0000000004%7C-unqsi-CJWh1YHTkJgDFaAkdQEdfV09JQ-unqsi-uao-agembe-acce&currentStep="
        private const val KEY_ADS_AUTOMATION_ENABLED = "ads_automation_enabled"
        private const val ADS_DETECTION_TIMEOUT_MS = 5_000L
        private const val ADS_LOAD_TIMEOUT_MS = 30_000L
        private const val KEY_COMPLETED_STAGES = "automation_completed_stages"
        private val AUTOMATION_PIPELINE = listOf(
            "authenticator", "two_step", "backup", "password", "creation_time", "ads", "youtube_premium", "app_password"
        )
        private const val APP_PASSWORD_AUTOMATION_TIMEOUT_MS = 90_000L
    }

    // Tapping anywhere else closes the keyboard automatically instead of leaving it up
    // after the person has clearly moved on from the field they were typing in.
    //
    // This used to run unconditionally on every single tap anywhere in the app, clearing
    // focus from whatever currentFocus was — including the WebView itself once a page
    // element (like Google's own apps-grid dropdown) had taken focus inside it. Clearing
    // the WebView's focus mid-tap made the page's own blur/focusout handling treat it as a
    // click-away and close that dropdown before the real click on its item ever landed,
    // which is exactly why nothing inside it could be opened. Now this only ever acts on an
    // EditText (our own address bar / dialog fields) that the tap genuinely landed outside
    // of, and only when the keyboard is actually showing — never on the WebView itself.
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val focused = currentFocus
            if (focused is EditText) {
                val rect = Rect()
                focused.getGlobalVisibleRect(rect)
                if (!rect.contains(ev.rawX.toInt(), ev.rawY.toInt())) {
                    val insets = ViewCompat.getRootWindowInsets(window.decorView)
                    val imeVisible = insets?.isVisible(WindowInsetsCompat.Type.ime()) ?: true
                    if (imeVisible) {
                        (getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)
                            ?.hideSoftInputFromWindow(focused.windowToken, 0)
                    }
                    focused.clearFocus()
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Force the app locale to English so WebView and all tabs use an English locale
        // regardless of the device language or a previously selected browser language.
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("en"))
        java.util.Locale.setDefault(java.util.Locale.US)
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        accountRecoveryModeEnabled = prefs.getBoolean(KEY_ACCOUNT_RECOVERY_MODE_ENABLED, false)
        automationMasterEnabled = prefs.getBoolean(KEY_AUTOMATION_MASTER_ENABLED, false)
        val automationInterrupted = savedInstanceState != null && automationMasterEnabled
        if (automationInterrupted) {
            automationMasterEnabled = false
            prefs.edit().putBoolean(KEY_AUTOMATION_MASTER_ENABLED, false).apply()
        }
        inspectModeEnabled = prefs.getBoolean(KEY_INSPECT_MODE_ENABLED, false)
        // Each child switch is a real persisted setting. Never force a child
        // automation back to ON when the activity is recreated.
        passwordAutomationEnabled = prefs.getBoolean(KEY_PASSWORD_AUTOMATION_ENABLED, false)
        appPasswordAutomationEnabled = prefs.getBoolean(KEY_APP_PASSWORD_AUTOMATION_ENABLED, false)
        youtubePremiumAutomationEnabled = prefs.getBoolean(KEY_YOUTUBE_PREMIUM_AUTOMATION_ENABLED, false)
        adsAutomationEnabled = prefs.getBoolean(KEY_ADS_AUTOMATION_ENABLED, false)
        loadCompletedStages()
        passwordAutomationCurrent = prefs.getString(KEY_PASSWORD_CURRENT, "") ?: ""
        recoveryEmailValue = prefs.getString(KEY_RECOVERY_EMAIL_VALUE, "") ?: ""
        passwordAutomationNew = prefs.getString(KEY_PASSWORD_NEW, "") ?: ""
        creationTimeAutomationEnabled = prefs.getBoolean(KEY_CREATION_TIME_AUTOMATION_ENABLED, false)
        backupAutomationEnabled = prefs.getBoolean(KEY_BACKUP_AUTOMATION_ENABLED, false)
        authenticatorAutomationEnabled = prefs.getBoolean(KEY_AUTHENTICATOR_AUTOMATION_ENABLED, false)
        twoStepAutomationEnabled = prefs.getBoolean(KEY_TWO_STEP_AUTOMATION_ENABLED, false)
        authenticatorSecret = prefs.getString(KEY_TOTP_SECRET, "") ?: ""
        authenticatorLabel = prefs.getString(KEY_TOTP_LABEL, "") ?: ""
        authenticatorAlgorithm = prefs.getString(KEY_TOTP_ALGORITHM, "SHA1") ?: "SHA1"
        authenticatorDigits = prefs.getInt(KEY_TOTP_DIGITS, 6).coerceIn(6, 8)
        authenticatorPeriod = prefs.getLong(KEY_TOTP_PERIOD, 30L).coerceIn(15L, 120L)
        authenticatorOtpauthUri = prefs.getString("totp_uri", "") ?: ""
        if (authenticatorSecret.isBlank()) {
            extractBase32Secret(prefs.getString(KEY_TWO_FA_LINK, "").orEmpty())?.let { secret ->
                authenticatorSecret = secret
                authenticatorLabel = "2FA"
            }
        }

        buildInterface()
        if (automationInterrupted) {
            Snackbar.make(drawerLayout, "Automation stopped after app restart. Turn Auto on to retry", Snackbar.LENGTH_LONG).show()
        }
        if (!restoreTabsState()) {
            addTab(homeUrl())
        }

        var lastBackPressedAt = 0L
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Close the side menu first if it is open.
                if (::drawerLayout.isInitialized && drawerLayout.isDrawerOpen(Gravity.END)) {
                    drawerLayout.closeDrawer(Gravity.END)
                    lastBackPressedAt = 0L
                    return
                }

                // Keep normal browser navigation working.
                val webView = currentWebView()
                if (webView?.canGoBack() == true) {
                    webView.goBack()
                    lastBackPressedAt = 0L
                    return
                }

                val now = System.currentTimeMillis()
                if (now - lastBackPressedAt <= 2000L) {
                    lastBackPressedAt = 0L
                    finish()
                } else {
                    lastBackPressedAt = now
                    Snackbar.make(
                        drawerLayout,
                        "Press back again to exit",
                        1200
                    ).apply {
                        setDuration(1200)
                    }.show()
                }
            }
        })
    }

    private fun buildInterface() {
        // Keep the Android status/navigation areas visible instead of drawing the browser UI over them.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = resolveColor(com.google.android.material.R.attr.colorSurface)
        window.navigationBarColor = resolveColor(com.google.android.material.R.attr.colorSurface)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = true
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = true

        drawerLayout = DrawerLayout(this).apply {
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
            // Keep the browser chrome from auto-focusing the address field when a
            // new tab/activity is created. The user must tap an input field to
            // place the caret there.
            isFocusableInTouchMode = true
        }

        // Android 15 can enforce edge-to-edge for targetSdk 35. Explicitly reserve the system-bar space.
        // Keep browser content below the Android status bar and, importantly,
        // reserve the full navigation-bar area at the bottom. Some Android
        // devices use an overlay/gesture navigation bar, so relying only on
        // WebView scrolling can leave website footer links (Privacy, Terms,
        // Language, etc.) underneath the phone's navigation controls.
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, bars.top, 0, 0)
            if (::systemBottomSpacer.isInitialized) {
                systemBottomSpacer.layoutParams = systemBottomSpacer.layoutParams.apply {
                    height = bars.bottom
                }
                systemBottomSpacer.requestLayout()
            }
            insets
        }

        chromeBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
            elevation = dp(2).toFloat()
        }

        fun chromeButton(label: String, size: Float = 24f): TextView = TextView(this).apply {
            text = label
            textSize = size
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            isClickable = true
            isFocusable = true
            background = null
        }

        val menuButton = chromeButton("⋮", 24f).apply {
            contentDescription = "Menu"
            setOnClickListener { drawerLayout.openDrawer(Gravity.END) }
        }
        chromeBar.addView(menuButton, LinearLayout.LayoutParams(dp(36), dp(40)).apply { gravity = Gravity.CENTER_VERTICAL; marginEnd = dp(14) })

        tabCountView = chromeButton("1", 11f).apply {
            contentDescription = "Tabs"
            setPadding(dp(3), dp(2), dp(3), dp(2))
            background = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.bg_tab_count)
            setOnClickListener { showTabSwitcher() }
        }
        chromeBar.addView(tabCountView, LinearLayout.LayoutParams(dp(28), dp(28)).apply { gravity = Gravity.CENTER_VERTICAL; marginEnd = dp(14) })

        val addButton = chromeButton("+", 25f).apply {
            contentDescription = "New tab"
            setOnClickListener { addTab(homeUrl()) }
        }
        chromeBar.addView(addButton, LinearLayout.LayoutParams(dp(38), dp(42)).apply { gravity = Gravity.CENTER_VERTICAL; marginEnd = dp(14) })

        addressBar = android.widget.EditText(this).apply {
            textSize = 14f
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setHintTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            hint = "Search or enter address"
            setPadding(dp(10), 0, dp(10), 0)
            background = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.bg_address_bar)
            isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusableInTouchMode = true
            var parsingCredentialRow = false
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if (parsingCredentialRow) return
                    // Only ever parse a credential row out of text the person is actively
                    // typing/pasting into a FOCUSED field. Without this, the app's own normal
                    // "update the address bar to show the page that just loaded" (which also
                    // fires this same listener) could be misread as a pasted row — e.g. a
                    // Google redirect URL that happens to contain both an email and, in a
                    // query parameter, the literal password text — and clobber the saved
                    // password with garbage extracted from that URL.
                    if (!isFocused) return
                    val snapshot = s?.toString().orEmpty()
                    // Rewriting the field's own text from inside this callback (which a paste
                    // of "email + password + secret" needs to do) can race with the paste
                    // itself on some keyboards/clipboard managers. Posting it lets the current
                    // text-change dispatch finish first, so the rewrite reliably sticks.
                    post {
                        if (parsingCredentialRow) return@post
                        if (!isFocused) return@post
                        if (text.toString() != snapshot) return@post // text changed again since; newer event will handle it
                        val row = parseCredentialRow(snapshot) ?: return@post
                        saveCredentialRow(row)
                        parsingCredentialRow = true
                        setText(row.email)
                        setSelection(text.length)
                        parsingCredentialRow = false
                        if (::drawerLayout.isInitialized) {
                            Snackbar.make(drawerLayout, "Password/2FA saved from pasted text", Snackbar.LENGTH_SHORT).show()
                        }
                    }
                }
                override fun afterTextChanged(s: android.text.Editable?) = Unit
            })
            setOnFocusChangeListener { _, hasFocus ->
                // Fallback: if a row was pasted in a way the live watcher missed, catch it
                // the moment the field loses focus too.
                if (!hasFocus && !parsingCredentialRow) {
                    parseCredentialRow(text.toString())?.let { row ->
                        saveCredentialRow(row)
                        parsingCredentialRow = true
                        setText(row.email)
                        setSelection(text.length)
                        parsingCredentialRow = false
                    }
                }
            }
            setOnEditorActionListener { v, _, _ ->
                loadAddress(v.text?.toString().orEmpty())
                true
            }
        }
        chromeBar.addView(addressBar, LinearLayout.LayoutParams(0, dp(34), 1f).apply {
            gravity = Gravity.CENTER_VERTICAL
            marginStart = dp(8)
            marginEnd = dp(8)
        })

        val homeButton = chromeButton("⌂", 23f).apply {
            contentDescription = "Home"
            setOnClickListener { currentWebView()?.loadUrl(homeUrl()) }
        }
        chromeBar.addView(homeButton, LinearLayout.LayoutParams(dp(36), dp(40)).apply { gravity = Gravity.CENTER_VERTICAL; marginStart = dp(4) })

        // Standard browser-style page loading indicator: a thin, natural blue line
        // directly below the tab/address bar. It does not consume the status-bar area.
        pageProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            isIndeterminate = false
            visibility = View.GONE
            progressDrawable = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.progress_page)
            setPadding(0, 0, 0, 0)
        }

        contentFrame = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // A dedicated inset spacer guarantees that the bottom of every WebView
        // stays above the phone's system navigation/gesture area.
        systemBottomSpacer = View(this).apply {
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        rootLayout.addView(chromeBar, LinearLayout.LayoutParams(-1, dp(58)))
        rootLayout.addView(pageProgress, LinearLayout.LayoutParams(-1, dp(3)))
        rootLayout.addView(contentFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        rootLayout.addView(systemBottomSpacer, LinearLayout.LayoutParams(-1, 0))

        drawerLayout.addView(rootLayout, DrawerLayout.LayoutParams(-1, -1))
        buildSideMenu()
        // The menu's rounded "card" is the ScrollView (sideMenuScroll). It hugs the menu's
        // own content height (so there's no empty space when the content is short) but is
        // capped at the available height — recomputed below as system bars/keyboard change —
        // so a longer menu, or one squeezed by the on-screen keyboard, becomes scrollable
        // instead of clipping off the bottom.
        drawerLayout.addView(sideMenuScroll, DrawerLayout.LayoutParams(dp(216), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.END
            topMargin = dp(12)
            bottomMargin = dp(12)
        })
        ViewCompat.setOnApplyWindowInsetsListener(drawerLayout) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val lp = sideMenuScroll.layoutParams as DrawerLayout.LayoutParams
            lp.topMargin = bars.top + dp(12)
            lp.bottomMargin = maxOf(bars.bottom, ime.bottom) + dp(12)
            sideMenuScroll.layoutParams = lp
            val availableHeight = (if (v.height > 0) v.height else resources.displayMetrics.heightPixels)
            sideMenuScroll.maxHeightPx = (availableHeight - lp.topMargin - lp.bottomMargin).coerceAtLeast(dp(120))
            insets
        }

        // Keep the DrawerLayout's normal touch routing. A child view must receive
        // its own clicks/switch gestures, while the scrim outside the drawer
        // consumes the touch and closes the drawer instead of letting it reach
        // the WebView underneath. Do NOT put an OnTouchListener on sideMenu or
        // sideMenuScroll: a consuming parent listener would break both the
        // Switches/Buttons inside it AND the ScrollView's own drag-to-scroll.
        sideMenu.isClickable = true
        sideMenu.isFocusable = true
        sideMenuScroll.isClickable = true
        sideMenuScroll.isFocusable = true
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, Gravity.END)

        setContentView(drawerLayout)
        // Give initial focus to the non-input root so Android does not place a
        // caret in the address bar automatically. Tapping the address/search
        // field still focuses it normally.
        rootLayout.post { rootLayout.requestFocus() }
    }

    private fun buildSideMenu() {
        sideMenu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Menu content is English, so keep the menu itself LTR.
            // The DrawerLayout position remains unchanged.
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(0, dp(16), 0, dp(10))
            isClickable = true
            isFocusable = true
        }

        // The rounded "card" look now lives on the ScrollView that wraps the menu, so the
        // whole card can be dragged up/down to reach items that don't fit the screen (e.g.
        // when the keyboard is open) instead of those items being cut off and unreachable.
        sideMenuScroll = MaxHeightScrollView(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(28).toFloat()
                setColor(resolveColor(com.google.android.material.R.attr.colorSurface))
            }
            elevation = dp(8).toFloat()
            clipToOutline = true
            isClickable = true
            isFocusable = true
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            // Without this, DrawerLayout's own drag handling can swallow the vertical drag
            // before this ScrollView's touch handling gets a chance, so the list never scrolls.
            setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
            addView(sideMenu, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        val title = TextView(this).apply {
            text = "eM gmail"
            textSize = 20f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(dp(24), dp(6), dp(24), dp(12))
        }
        sideMenu.addView(title)

        fun menuItem(label: CharSequence, onClick: () -> Unit): TextView = TextView(this).apply {
            text = label
            textSize = 15.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(dp(24), 0, dp(24), 0)
            // No pressed/selected highlight color: keep the app monochrome.
            background = null
            setOnClickListener { onClick() }
        }

        fun menuSwitchItem(label: String, checked: Boolean, onChanged: (Boolean) -> Unit): LinearLayout {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                setPadding(dp(24), 0, dp(12), 0)
                minimumHeight = dp(46)
            }
            val text = TextView(this).apply {
                this.text = label
                textSize = 15.5f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER_VERTICAL
                setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            }
            val switch = createAutomationToggle(checked, onChanged)
            row.addView(text, LinearLayout.LayoutParams(0, dp(46), 1f))
            row.addView(switch, LinearLayout.LayoutParams(dp(46), dp(28)))
            return row
        }

        sideMenu.addView(
            menuItem("Accounts") { drawerLayout.closeDrawer(Gravity.END); showSavedAuthenticatorAccountsDialog() }.apply {
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46))
        )
        sideMenu.addView(menuItem("2FA Link") { drawerLayout.closeDrawer(Gravity.END); showTwoFaLinkDialog() }.apply { typeface = android.graphics.Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(
            menuSwitchItem("Recovery Mode", accountRecoveryModeEnabled) { enabled ->
                setAccountRecoveryMode(enabled)
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        )
        addAutomationMasterMenuItem()
        sideMenu.addView(menuItem("Clear Data") { drawerLayout.closeDrawer(Gravity.END); showClearAllDataDialog() }.apply { typeface = android.graphics.Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
    }

    /**
     * Compact automation toggle matching the supplied reference: a clean pill
     * track, white circular thumb, green ON state and gray OFF state. The
     * thumb intentionally sits on the left when ON and on the right when OFF,
     * matching the reference image.
     */
    private fun createAutomationToggle(initialChecked: Boolean, onChanged: (Boolean) -> Unit): FrameLayout {
        val trackWidth = dp(46)
        val trackHeight = dp(28)
        val thumbSize = dp(20)
        val horizontalInset = dp(4)
        val onColor = Color.rgb(20, 198, 100) // #14C664 from the supplied reference
        val offColor = Color.rgb(204, 204, 204) // #CCCCCC from the supplied reference

        var checked = initialChecked
        val container = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(trackWidth, trackHeight)
            isClickable = true
            isFocusable = true
            contentDescription = if (checked) "ON" else "OFF"
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }

        val track = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = trackHeight / 2f
            }
        }
        container.addView(track, FrameLayout.LayoutParams(trackWidth, trackHeight))

        val thumb = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
            }
            elevation = dp(1).toFloat()
        }
        val thumbParams = FrameLayout.LayoutParams(thumbSize, thumbSize).apply {
            topMargin = (trackHeight - thumbSize) / 2
            leftMargin = horizontalInset
        }
        container.addView(thumb, thumbParams)

        fun render(animated: Boolean) {
            track.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = trackHeight / 2f
                setColor(if (checked) onColor else offColor)
            }
            val targetX = if (checked) 0 else trackWidth - (horizontalInset * 2) - thumbSize
            if (animated) {
                thumb.animate().translationX(targetX.toFloat()).setDuration(120L).start()
            } else {
                thumb.translationX = targetX.toFloat()
            }
            container.contentDescription = if (checked) "ON" else "OFF"
        }

        render(false)
        container.setOnClickListener {
            checked = !checked
            render(true)
            onChanged(checked)
            val externallySet = container.tag
            if (externallySet is Boolean) {
                if (externallySet != checked) {
                    checked = externallySet
                    render(false)
                }
                container.tag = null
            }
        }
        return container
    }

    private fun stopAutomationMasterExecution() {
        automationMasterEnabled = false
        automationStageHandoffPending = false
        automationHandoffGeneration++
        automationLastHandoffStage = ""
        securityStageHandoffView = null
        securityStageHandoffAccount = ""
        googleVerificationGeneration++
        googleVerificationProbeInFlight = false
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(KEY_AUTOMATION_MASTER_ENABLED, false)
            .apply()
        clearPasswordAutomationState()
        stopAppPasswordAutomation()
        stopAdsAutomation()
        stopYoutubePremiumAutomation()
        recoveryEmailAutomationActive = false
        stopCreationTimeAutomation()
        stopDevicesAutomation()
        phoneNumbersAutomationActive = false
        phoneNumbersDeletePending = false
        phoneNumbersDeleteConfirmIssued = false
        phoneNumbersDeleteCountBeforeClick = 0
        phoneNumbersNoDeleteSince = 0L
        combinedAutomationWaitingForPassword = false
        googleVerificationActive = false
        googleVerificationSubmitIssued = false
        googleVerificationNoticeShown = false
        googleVerificationCheckPending = false
        stopAuthenticatorAutomation()
        stopTwoStepAutomation()
        stopBackupAutomation()
    }

    private fun addAutomationMasterMenuItem() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val settingsLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            // Child automation labels use the exact same left inset as the
            // main drawer items, so English starts at one clean vertical edge.
            setPadding(0, 0, 0, 0)
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), 0, dp(12), 0)
        }

        val label = TextView(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            text = "Auto"
            textSize = 15.5f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, 0, dp(12), 0)
            setOnClickListener {
                // Auto is both the master execution control and the parent
                // of the automation settings. Tapping the label only
                // expands/collapses the settings; it never changes Auto.
                settingsLayout.visibility =
                    if (settingsLayout.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        }

        lateinit var switch: FrameLayout
        switch = createAutomationToggle(automationMasterEnabled) { checked ->
            automationMasterEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_AUTOMATION_MASTER_ENABLED, checked).apply()
            if (checked) {
                // Auto starts the selected action stages in pipeline order.
                automationCompletedForCurrentAccount = false
                automationHasRunInCurrentGoogleSession = false
                val currentUrl = currentWebView()?.url.orEmpty()
                if (creationTimeAutomationEnabled || isAutomationPageUrl(currentUrl)) {
                    startConfiguredAutomationForCurrentAccount()
                }
            } else {
                stopAutomationMasterExecution()
            }
        }

        row.addView(label, LinearLayout.LayoutParams(0, dp(46), 1f))
        row.addView(switch, LinearLayout.LayoutParams(dp(46), dp(28)))
        container.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))

        fun addSettingRow(title: String, enabled: Boolean, onSettingClick: () -> Unit, onChanged: (Boolean) -> Unit) {
            val settingRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                gravity = Gravity.CENTER_VERTICAL
                // Match every other drawer label: English starts at the same
                // left edge instead of being pushed inward by an extra indent.
                setPadding(dp(24), 0, dp(12), 0)
            }
            val settingLabel = TextView(this).apply {
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                text = title
                textSize = 14.5f
                gravity = Gravity.CENTER_VERTICAL
                setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
                setOnClickListener { onSettingClick() }
            }
            val settingSwitch = createAutomationToggle(enabled, onChanged)
            settingRow.addView(settingLabel, LinearLayout.LayoutParams(0, dp(40), 1f))
            settingRow.addView(settingSwitch, LinearLayout.LayoutParams(dp(46), dp(28)))
            val order = listOf("Authenticator", "2-Step", "Backup", "Password", "Creation Time", "Ads", "YouTube premium", "App password", "Inspect")
            val index = (0 until settingsLayout.childCount).count { i ->
                val existing = (settingsLayout.getChildAt(i) as LinearLayout).getChildAt(0) as TextView
                order.indexOf(existing.text.toString()) < order.indexOf(title)
            }
            settingsLayout.addView(settingRow, index, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
        }

        fun restartConfiguredAutomationIfMasterIsAlreadyOn() {
            if (!automationMasterEnabled || automationStageHandoffPending) return
            val currentUrl = currentWebView()?.url.orEmpty()
            if (!isAutomationPageUrl(currentUrl)) return
            // A stage is already running: the hand-off reads the live switches, so
            // a newly enabled stage is picked up automatically when it is reached.
            if (anyAutomationStageActive()) return
            // Resume, never restart: stages already finished for this account are
            // skipped by nextRunnableStage(); only the newly enabled one will run.
            automationCompletedForCurrentAccount = false
            automationHasRunInCurrentGoogleSession = false
            completedAccountKey = ""
            currentWebView()?.let { view ->
                view.postDelayed({
                    if (!automationMasterEnabled || automationStageHandoffPending || anyAutomationStageActive()) return@postDelayed
                    if (accountKeyForStages(view).isBlank() && view.url.orEmpty().contains("google.com")) {
                        detectGoogleAccountKey(view) { detected ->
                            val key = detected.trim().lowercase(Locale.US)
                            if (key.isNotBlank()) {
                                currentAccountKey = key
                                accountKeyByWebView[view] = key
                            }
                            if (automationMasterEnabled && !automationStageHandoffPending && !anyAutomationStageActive()) {
                                startConfiguredAutomationForCurrentAccount()
                            }
                        }
                    } else {
                        startConfiguredAutomationForCurrentAccount()
                    }
                }, 100L)
            }
        }

        addSettingRow("Creation Time", creationTimeAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END) }) { checked ->
            creationTimeAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean(KEY_CREATION_TIME_AUTOMATION_ENABLED, checked)
                .apply()
            if (!checked) {
                val wasActive = creationTimeAutomationActive
                clearStageCompleted("creation_time")
                stopCreationTimeAutomation()
                if (wasActive && automationMasterEnabled) {
                    continueAfterDisabledStage("creation_time")
                }
            } else {
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        addSettingRow("Password", passwordAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END); showPasswordChangeDialog() }) { checked ->
            passwordAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_PASSWORD_AUTOMATION_ENABLED, checked).apply()
            if (!checked) {
                val wasActive = passwordAutomationActive || passwordFlowStartedForCurrentAutomation
                val owner = passwordAutomationView
                val account = owner?.let { accountKeyByWebView[it].orEmpty().ifBlank { passwordAutomationAccount } }
                clearStageCompleted("password", account ?: accountKeyForStages())
                clearPasswordAutomationState()
                if (wasActive && automationMasterEnabled && owner != null) {
                    continueAfterDisabledStage("password", owner)
                } else if (!automationMasterEnabled) {
                    passwordChangeSubmitted = false
                }
            } else {
                // If Auto is already ON, changing this setting must take effect
                // immediately; the user must never have to toggle Auto twice.
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        addSettingRow("Authenticator", authenticatorAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END); showAuthenticatorDialog() }) { checked ->
            authenticatorAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_AUTHENTICATOR_AUTOMATION_ENABLED, checked).apply()
            if (!checked) {
                val wasActive = authenticatorAutomationActive
                val owner = authenticatorAutomationView
                val account = owner?.let { accountKeyByWebView[it].orEmpty().ifBlank { authenticatorAutomationAccount } }
                clearStageCompleted("authenticator", account ?: accountKeyForStages())
                stopAuthenticatorAutomation()
                if (wasActive && automationMasterEnabled && owner != null) {
                    continueAfterDisabledStage("authenticator", owner)
                }
            } else {
                // Same rule for Authenticator: if Auto is already enabled, the
                // new setting starts the configured stage without any off/on trick.
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        addSettingRow("2-Step", twoStepAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END) }) { checked ->
            if (backupAutomationView != null) {
                recoveryActionPermit = ""
                resetBackupAutomationCandidate()
            }
            twoStepAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_TWO_STEP_AUTOMATION_ENABLED, checked).apply()
            if (!checked) {
                val wasActive = twoStepAutomationActive
                val ownerAccount = if (wasActive) twoStepAutomationAccount else backupAutomationAccount
                clearStageCompleted("two_step", ownerAccount.ifBlank { accountKeyForStages() })
                stopTwoStepAutomation()
                if (wasActive && automationMasterEnabled) {
                    continueAfterDisabledStage("two_step")
                }
            } else {
                // Enabling this setting alone never starts automation while
                // Auto is OFF. If Auto is already ON, start the selected pipeline.
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        addSettingRow("Backup", backupAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END) }) { checked ->
            backupAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean(KEY_BACKUP_AUTOMATION_ENABLED, checked)
                .apply()
            if (!checked) {
                val owner = backupAutomationView
                val account = backupAutomationAccount.ifBlank { accountKeyForStages(owner) }
                clearStageCompleted("backup", account)
                stopBackupAutomation()
                if (automationMasterEnabled && owner != null) {
                    startNextConfiguredStage(owner, "backup", immediate = true, accountOverride = account)
                }
            } else {
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        addSettingRow("App password", appPasswordAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END) }) { checked ->
            appPasswordAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean(KEY_APP_PASSWORD_AUTOMATION_ENABLED, checked)
                .apply()
            if (!checked) {
                val wasActive = appPasswordAutomationActive
                clearStageCompleted("app_password")
                stopAppPasswordAutomation()
                if (wasActive && automationMasterEnabled) {
                    continueAfterDisabledStage("app_password")
                }
            } else {
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        addSettingRow("Ads", adsAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END) }) { checked ->
            adsAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean(KEY_ADS_AUTOMATION_ENABLED, checked).apply()
            if (!checked) {
                val wasActive = adsAutomationActive
                val owner = adsAutomationView
                val account = adsAutomationAccount.ifBlank { accountKeyForStages(owner) }
                clearStageCompleted("ads", account)
                stopAdsAutomation()
                if (wasActive && automationMasterEnabled && owner != null) continueAfterDisabledStage("ads", owner)
            } else {
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        addSettingRow("YouTube premium", youtubePremiumAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END) }) { checked ->
            youtubePremiumAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean(KEY_YOUTUBE_PREMIUM_AUTOMATION_ENABLED, checked)
                .apply()
            if (!checked) {
                val wasActive = youtubePremiumAutomationActive
                clearStageCompleted("youtube_premium")
                stopYoutubePremiumAutomation()
                if (wasActive && automationMasterEnabled) {
                    continueAfterDisabledStage("youtube_premium")
                }
            } else {
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        addSettingRow("Inspect", inspectModeEnabled,
            { drawerLayout.closeDrawer(Gravity.END) }) { checked ->
            inspectModeEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_INSPECT_MODE_ENABLED, checked).apply()
            currentWebView()?.let { view ->
                if (checked) {
                    installInspectMode(view)
                } else {
                    removeInspectMode(view)
                }
            }
        }

        container.addView(settingsLayout, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        sideMenu.addView(container, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun showAuthenticatorDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val status = TextView(this).apply {
            textSize = 14f
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
        }
        val code = TextView(this).apply {
            textSize = 34f
            typeface = android.graphics.Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
        }
        val countdown = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
        }
        val copyCode = Button(this).apply {
            text = "Copy code"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, dp(8), 0, dp(8))
            setOnClickListener {
                val value = code.text?.toString().orEmpty()
                if (value.matches(Regex("\\d{6,8}"))) {
                    copyToClipboard("Authenticator code", value)
                }
            }
        }
        val copyLink = Button(this).apply {
            text = "Copy Key"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, dp(4), 0, dp(8))
            setOnClickListener {
                val key = formatSavedAuthenticatorKey(authenticatorSecret)
                if (key.isNotBlank()) {
                    copyToClipboard("Authenticator key", key)
                }
            }
        }
        val savedListButton = Button(this).apply {
            text = "Accounts"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, dp(8), 0, dp(8))
            setOnClickListener { showSavedAuthenticatorAccountsDialog() }
        }
        container.addView(status)
        container.addView(code)
        container.addView(countdown)
        container.addView(copyCode)
        container.addView(copyLink)
        container.addView(savedListButton)

        fun refreshToken() {
            if (authenticatorSecret.isBlank()) {
                status.text = "No saved authenticator account."
                code.text = "------"
                countdown.text = ""
                return
            }
            runCatching {
                val value = generateTotp(authenticatorSecret, System.currentTimeMillis(), authenticatorAlgorithm, authenticatorDigits, authenticatorPeriod)
                code.text = value
                status.text = if (authenticatorLabel.isBlank()) "Authenticator code" else authenticatorLabel
                val remaining = authenticatorPeriod - ((System.currentTimeMillis() / 1000L) % authenticatorPeriod)
                countdown.text = "Refreshes in ${remaining}s"
            }.onFailure {
                code.text = "ERROR"
                status.text = "Unable to generate authenticator code"
                countdown.text = ""
            }
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Authenticator")
            .setView(container)
            .setPositiveButton("Scan QR from current page") { _, _ ->
                val qrView = currentWebView()
                if (qrView == null) {
                    Snackbar.make(drawerLayout, "No open tab", Snackbar.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                scanQrFromCurrentPage(qrView) { raw ->
                    if (raw != null) {
                        val parsed = parseOtpAuth(raw)
                        if (parsed != null) {
                            val setupAccount = if (qrView.url.orEmpty().contains("myaccount.google.com/two-step-verification/authenticator", true))
                                accountKeyByWebView[qrView].orEmpty() else ""
                            saveAuthenticator(parsed, accountOverride = setupAccount)
                            stagePendingAuthenticatorChange(parsed)
                            showAuthenticatorDialog()
                        } else {
                            AlertDialog.Builder(this).setTitle("Authenticator").setMessage("The QR code was read, but it is not a valid otpauth:// TOTP link.").setPositiveButton("OK", null).create().also { it.show(); applyRoundedDialogCorners(it) }
                        }
                    } else {
                        AlertDialog.Builder(this).setTitle("Authenticator").setMessage("No readable QR code was found on the current page.").setPositiveButton("OK", null).create().also { it.show(); applyRoundedDialogCorners(it) }
                    }
                }
            }
            .setNeutralButton("Clear") { _, _ -> clearAuthenticator() }
            .create()

        authenticatorTimer?.cancel()
        authenticatorTimer = object : android.os.CountDownTimer(24L * 60L * 60L * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) { refreshToken() }
            override fun onFinish() { }
        }.start()
        dialog.setOnDismissListener { authenticatorTimer?.cancel(); authenticatorTimer = null }
        dialog.show()
        applyRoundedDialogCorners(dialog)
        refreshToken()
    }

    private data class TotpConfig(
        val secret: String,
        val label: String,
        val issuer: String,
        val algorithm: String,
        val digits: Int,
        val period: Long,
        val uri: String
    )

    private fun parseOtpAuth(raw: String): TotpConfig? {
        val uri = raw.trim().let { if (it.startsWith("otpauth://", true)) it else return null }
        val parsed = android.net.Uri.parse(uri)
        if (!parsed.scheme.equals("otpauth", true) || !parsed.host.equals("totp", true)) return null
        val secret = parsed.getQueryParameter("secret")?.replace(" ", "")?.uppercase(Locale.US) ?: return null
        if (secret.length < 8) return null
        val label = parsed.path.orEmpty().removePrefix("/").let { java.net.URLDecoder.decode(it, "UTF-8") }
        val issuer = parsed.getQueryParameter("issuer").orEmpty()
        val algorithm = parsed.getQueryParameter("algorithm")?.uppercase(Locale.US)?.takeIf { it in setOf("SHA1", "SHA256", "SHA512") } ?: "SHA1"
        val digits = parsed.getQueryParameter("digits")?.toIntOrNull()?.takeIf { it == 6 || it == 8 } ?: 6
        val period = parsed.getQueryParameter("period")?.toLongOrNull()?.takeIf { it in 15L..120L } ?: 30L
        return TotpConfig(secret, label, issuer, algorithm, digits, period, uri)
    }

    private fun applyAuthenticatorRuntimeConfig(config: TotpConfig) {
        authenticatorSecret = config.secret
        authenticatorLabel = if (config.issuer.isBlank()) config.label else "${config.issuer}: ${config.label}"
        authenticatorAlgorithm = config.algorithm
        authenticatorDigits = config.digits
        authenticatorPeriod = config.period
        authenticatorOtpauthUri = config.uri
    }

    private fun saveAuthenticator(
        config: TotpConfig,
        recordChange: Boolean = false,
        accountOverride: String? = null
    ) {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val previousSecret = prefs.getString(KEY_TWO_FA_LINK, "").orEmpty()
            .ifBlank { prefs.getString(KEY_TOTP_SECRET, "").orEmpty() }
        val owner = accountOverride?.trim()?.lowercase(Locale.US)
            ?: if (previousSecret.equals(config.secret, true)) prefs.getString(KEY_TOTP_OWNER, null) else null
        applyAuthenticatorRuntimeConfig(config)

        val editor = prefs.edit()
            .putString(KEY_TOTP_SECRET, authenticatorSecret)
            .putString(KEY_TOTP_LABEL, authenticatorLabel)
            .putString(KEY_TOTP_ALGORITHM, authenticatorAlgorithm)
            .putInt(KEY_TOTP_DIGITS, authenticatorDigits)
            .putLong(KEY_TOTP_PERIOD, authenticatorPeriod)
            .putString("totp_uri", authenticatorOtpauthUri)
            // Keep 2FA Link synchronized with the latest Authenticator secret.
            // The visible 2FA Link field intentionally contains only Base32.
            .putString(KEY_TWO_FA_LINK, authenticatorSecret)
        if (owner == null) editor.remove(KEY_TOTP_OWNER) else editor.putString(KEY_TOTP_OWNER, owner)
        editor.apply()

        if (!recordChange) return

        // Prefer the Google account currently open in the WebView. The QR label can
        // contain an issuer/name instead of the actual Gmail, so using currentAccountKey
        // keeps the saved log explicitly mapped to the account being configured.
        val account = accountOverride?.takeIf { it.isNotBlank() }
            ?: accountKeyByWebView[currentWebView()]?.takeIf { it.isNotBlank() }
            ?: currentAccountKey.ifBlank {
                extractEmailFromText(config.label).ifBlank {
                    extractEmailFromText(config.issuer)
                }
            }
        if (account.isBlank()) return
        val array = loadAuthenticatorAccounts()
        val existingIndex = (0 until array.length()).firstOrNull { i ->
            val existing = array.optJSONObject(i) ?: return@firstOrNull false
            existing.optString("uri") == config.uri || (account.isNotBlank() && existing.optString("account") == account)
        }
        val stagedCredentials = stagedSignInCredentials(account)
        val existingItem = existingIndex?.let { array.optJSONObject(it) }
        val existingIsChanged = existingItem?.let { isAccountChangeRecord(it) } == true
        val existingSecret = existingIndex?.let { index ->
            val existing = array.optJSONObject(index) ?: return@let ""
            formatSavedAuthenticatorKey(existing.optString("twoFa").ifBlank { existing.optString("secret") })
        }.orEmpty()
        val newSecret = formatSavedAuthenticatorKey(config.secret)
        if (existingSecret == newSecret && existingSecret.isNotBlank()) return
        val changedAt = System.currentTimeMillis()
        val primaryPassword = if (existingIsChanged) existingItem?.optString("password").orEmpty()
            else stagedCredentials?.optString("password").orEmpty()
        val passwordToKeep = primaryPassword.ifBlank {
            if (existingIsChanged) stagedCredentials?.optString("password").orEmpty()
            else existingItem?.optString("password").orEmpty()
        }
        val baseItem = when {
            existingIsChanged -> existingItem
            stagedCredentials != null -> JSONObject(stagedCredentials.toString())
            else -> existingItem
        } ?: JSONObject()
        val obj = baseItem.apply {
            put("account", account)
            put("password", passwordToKeep)
            put("twoFa", config.secret)
            // When an authenticator is present, Accounts must not retain a recovery email.
            put("recoveryEmail", "")
            put("label", if (config.issuer.isBlank()) config.label else "${config.issuer}: ${config.label}")
            put("uri", config.uri)
            put("secret", config.secret)
            put("algorithm", config.algorithm)
            put("digits", config.digits)
            put("period", config.period)
            put("authenticatorChangedAt", changedAt)
            if (optLong("savedAt", 0L) == 0L) put("savedAt", System.currentTimeMillis())
        }
        if (existingIndex != null) array.put(existingIndex, obj) else array.put(obj)
        saveAuthenticatorAccounts(array)
        saveAuthenticatorLogFile(array)
        clearStagedSignInCredentials(account)
    }

    private fun stagePendingAuthenticatorChange(config: TotpConfig) {
        val view = currentWebView() ?: return
        if (!view.url.orEmpty().contains("/two-step-verification/authenticator", ignoreCase = true)) return
        pendingAuthenticatorChange = config
        pendingAuthenticatorChangeAccount = accountKeyByWebView[view].orEmpty()
        pendingAuthenticatorChangeStartedAt = System.currentTimeMillis()
        schedulePendingAuthenticatorCheck(view, config)
    }

    private fun schedulePendingAuthenticatorCheck(view: WebView, config: TotpConfig) {
        view.postDelayed({
            if (pendingAuthenticatorChange !== config) return@postDelayed
            if (System.currentTimeMillis() - pendingAuthenticatorChangeStartedAt > 10 * 60 * 1000L) {
                pendingAuthenticatorChange = null
                pendingAuthenticatorChangeAccount = ""
                pendingAuthenticatorChangeStartedAt = 0L
                return@postDelayed
            }
            detectPendingAuthenticatorChange(view)
            schedulePendingAuthenticatorCheck(view, config)
        }, 1500L)
    }

    private fun detectPendingAuthenticatorChange(view: WebView) {
        val config = pendingAuthenticatorChange ?: return
        if (authenticatorAutomationActive) return
        val pageUrl = view.url.orEmpty()
        if (!pageUrl.contains("myaccount.google.com", true) && !pageUrl.contains("accounts.google.com", true)) {
            pendingAuthenticatorChange = null
            pendingAuthenticatorChangeAccount = ""
            pendingAuthenticatorChangeStartedAt = 0L
            return
        }
        val script = """
            (function() {
              const text = (document.body?.innerText || '').replace(/\s+/g, ' ');
              return /authenticator app (?:(?:has been|was) )?(?:added|set up|updated|enabled)|(?:added|set up|updated|enabled) (?:an? )?authenticator app|تمت إضافة تطبيق المصادقة|تمت اضافة تطبيق المصادقة|تم إعداد تطبيق المصادقة بنجاح|تم تحديث تطبيق المصادقة|تم تفعيل تطبيق المصادقة/i.test(text)
                ? 'confirmed' : '';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (result?.trim('"') != "confirmed" || pendingAuthenticatorChange !== config) return@evaluateJavascript
            val account = pendingAuthenticatorChangeAccount.ifBlank { accountKeyByWebView[view].orEmpty() }
            pendingAuthenticatorChange = null
            pendingAuthenticatorChangeAccount = ""
            pendingAuthenticatorChangeStartedAt = 0L
            saveAuthenticator(config, recordChange = true, accountOverride = account)
        }
    }

    private fun isAccountChangeRecord(item: JSONObject): Boolean =
        item.optLong("passwordChangedAt", 0L) > 0L ||
            item.optLong("authenticatorChangedAt", 0L) > 0L ||
            item.optLong("appPasswordCreatedAt", 0L) > 0L ||
            item.optLong("adsAt", 0L) > 0L ||
            item.optLong("youtubePremiumAt", 0L) > 0L ||
            item.optLong("creationYearChangedAt", 0L) > 0L ||
            item.optLong("backupCodesChangedAt", 0L) > 0L

    private fun changedAccountRecords(array: JSONArray): JSONArray {
        val changed = JSONArray()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            if (isAccountChangeRecord(item)) changed.put(item)
        }
        return changed
    }

    /**
     * Keeps a real local log file in the app's private files directory in addition
     * to the in-app JSON list. Rows include the account, sign-in password, 2FA/recovery, app password, and creation time.
     * The otpauth link contains the TOTP secret, so this file is intentionally kept
     * private to the app rather than uploaded anywhere.
     */
    private fun saveAuthenticatorLogFile(array: JSONArray = loadAuthenticatorAccounts()) {
        runCatching {
            val file = File(filesDir, "authenticator_accounts.csv")
            val out = StringBuilder()
            out.append("Gmail\tPassword\t2FA Link / Recovery\tApp Password\tCreation Time\tAds\tYouTube Premium\n")
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                if (!isAccountChangeRecord(item)) continue
                val account = item.optString("account")
                val password = item.optString("password")
                val twoFa = formatSavedAuthenticatorKey(item.optString("twoFa").ifBlank { item.optString("secret") })
                val recovery = item.optString("recoveryEmail")
                val appPassword = item.optString("appPassword")
                val creationTime = accountCreationTime(item)
                val ads = item.optString("ads")
                val youtubePremium = item.optString("youtubePremium")
                val third = if (twoFa.isNotBlank()) twoFa else recovery
                if (account.isNotBlank()) {
                    out.append(account).append('\t').append(password).append('\t').append(third)
                        .append('\t').append(appPassword).append('\t').append(creationTime)
                        .append('\t').append(ads).append('\t').append(youtubePremium).append('\n')
                }
            }
            file.writeText(out.toString(), Charsets.UTF_8)
        }
    }

    private fun accountCreationTime(item: JSONObject): String = item.optString("creationYear")

    private fun saveAccountCreationTime(account: String, year: String) {
        val normalizedAccount = account.trim().lowercase(Locale.US)
        if (normalizedAccount.isBlank() || !year.matches(Regex("(?:19|20)\\d{2}"))) return

        val accounts = loadAuthenticatorAccounts()
        val index = (0 until accounts.length()).firstOrNull {
            accounts.optJSONObject(it)?.optString("account").orEmpty().equals(normalizedAccount, true)
        }
        val existing = index?.let { accounts.optJSONObject(it) }
        val staged = stagedSignInCredentials(normalizedAccount)
        val item = when {
            existing != null -> JSONObject(existing.toString())
            staged != null -> JSONObject(staged.toString())
            else -> JSONObject()
        }
        if (existing != null && staged != null && !isAccountChangeRecord(existing)) {
            // Creation Time now runs first; preserve staged credentials before marking the record changed.
            for (key in listOf("password", "twoFa", "secret", "appPassword")) {
                if (staged.optString(key).isNotBlank()) item.put(key, staged.optString(key))
            }
        }
        val savedAt = System.currentTimeMillis()
        item.put("account", normalizedAccount)
        item.put("creationYear", year)
        item.remove("creationMonth")
        item.put("creationYearChangedAt", savedAt)
        if (item.optLong("savedAt", 0L) == 0L) item.put("savedAt", savedAt)
        if (index != null) accounts.put(index, item) else accounts.put(item)
        saveAuthenticatorAccounts(accounts)
        saveAuthenticatorLogFile(accounts)
    }

    private fun backupCodesKey(): javax.crypto.SecretKey {
        val store = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val alias = "em_browser_backup_codes"
        val existing = store.getKey(alias, null) as? javax.crypto.SecretKey
        if (existing != null) return existing
        val generator = javax.crypto.KeyGenerator.getInstance(android.security.keystore.KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(android.security.keystore.KeyGenParameterSpec.Builder(
            alias,
            android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .build())
        return generator.generateKey()
    }

    private fun saveAccountBackupCodes(accountKey: String, codes: List<String>): Boolean {
        val account = accountKey.trim().lowercase(Locale.US)
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(account).matches() || codes.isEmpty() || codes.size > 10 ||
            codes.distinct().size != codes.size || codes.any { !it.matches(Regex("[0-9]{8}")) }) return false
        return runCatching {
            val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, backupCodesKey())
            cipher.updateAAD(account.toByteArray(Charsets.UTF_8))
            val ciphertext = cipher.doFinal(JSONArray(codes).toString().toByteArray(Charsets.UTF_8))
            val encrypted = android.util.Base64.encodeToString(cipher.iv + ciphertext, android.util.Base64.NO_WRAP)
            val accounts = loadAuthenticatorAccounts()
            val index = (0 until accounts.length()).firstOrNull {
                accounts.optJSONObject(it)?.optString("account").orEmpty().equals(account, true)
            }
            val existing = index?.let { accounts.optJSONObject(it) }
            val staged = stagedSignInCredentials(account)
            val item = when {
                existing != null -> JSONObject(existing.toString())
                staged != null -> JSONObject(staged.toString())
                else -> JSONObject()
            }
            val savedAt = System.currentTimeMillis()
            item.put("account", account)
            item.put("backupCodesEncrypted", encrypted)
            item.put("backupCodesChangedAt", savedAt)
            if (item.optLong("savedAt", 0L) == 0L) item.put("savedAt", savedAt)
            if (index != null) accounts.put(index, item) else accounts.put(item)
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_TOTP_ACCOUNTS, accounts.toString()).commit().also {
                if (it) saveAuthenticatorLogFile(accounts)
            }
        }.getOrDefault(false)
    }

    private fun readAccountBackupCodes(item: JSONObject): List<String> {
        val account = item.optString("account").trim().lowercase(Locale.US)
        val encrypted = item.optString("backupCodesEncrypted")
        if (account.isBlank() || encrypted.isBlank()) return emptyList()
        return runCatching {
            val bytes = android.util.Base64.decode(encrypted, android.util.Base64.NO_WRAP)
            require(bytes.size > 28)
            val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(javax.crypto.Cipher.DECRYPT_MODE, backupCodesKey(), javax.crypto.spec.GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
            cipher.updateAAD(account.toByteArray(Charsets.UTF_8))
            val values = JSONArray(String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8))
            (0 until values.length()).map { index ->
                val value = values.opt(index) as? String ?: error("Invalid backup code")
                require(value.matches(Regex("[0-9]{8}")))
                value
            }
        }.getOrDefault(emptyList())
    }

    private fun clearAuthenticator() {
        authenticatorTimer?.cancel()
        authenticatorTimer = null
        pendingAuthenticatorChange = null
        pendingAuthenticatorChangeAccount = ""
        pendingAuthenticatorChangeStartedAt = 0L
        authenticatorSecret = ""
        authenticatorLabel = ""
        authenticatorOtpauthUri = ""
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .remove(KEY_TOTP_SECRET).remove(KEY_TOTP_LABEL).remove(KEY_TOTP_ALGORITHM)
            .remove(KEY_TOTP_DIGITS).remove(KEY_TOTP_PERIOD).remove("totp_uri").apply()
    }

    private fun showTwoFaLinkDialog() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val savedLink = prefs.getString(KEY_TWO_FA_LINK, "").orEmpty()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }

        val input = EditText(this).apply {
            hint = "Enter 2FA key"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setHintTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            if (savedLink.isNotBlank()) setText(savedLink)
        }

        val code = TextView(this).apply {
            text = "------"
            textSize = 34f
            typeface = android.graphics.Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(2))
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
        }

        val timerText = TextView(this).apply {
            text = ""
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
        }

        val copyCode = Button(this).apply {
            text = "Copy Code"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setOnClickListener {
                val value = code.text?.toString().orEmpty()
                if (value.matches(Regex("\\d{6,8}"))) {
                    copyToClipboard("2FA code", value)
                }
            }
        }

        // The saved 2FA link is intentionally persistent. Closing the dialog (OK,
        // back, or tapping outside) must not clear it; only the explicit Clear
        // action below is allowed to remove it.
        var activeConfig: TotpConfig? = null
        var refreshTimer: android.os.CountDownTimer? = null

        fun renderCode(config: TotpConfig) {
            activeConfig = config
            refreshTimer?.cancel()
            val now = System.currentTimeMillis()
            runCatching {
                generateTotp(config.secret, now, config.algorithm, config.digits, config.period)
            }.onSuccess { value ->
                code.text = value
                val periodMillis = config.period * 1000L
                val elapsed = now % periodMillis
                val remaining = (periodMillis - elapsed).coerceAtLeast(1000L)
                refreshTimer = object : android.os.CountDownTimer(remaining, 1000L) {
                    override fun onTick(millisUntilFinished: Long) {
                        val seconds = ((millisUntilFinished + 999L) / 1000L).toInt()
                        timerText.text = "${seconds}s"
                    }

                    override fun onFinish() {
                        activeConfig?.let { renderCode(it) }
                    }
                }.start()
            }.onFailure {
                code.text = "ERROR"
                timerText.text = ""
            }
        }

        fun handleLink(rawInput: String, userEdited: Boolean = false) {
            val raw = rawInput.trim()
            if (raw.isBlank()) {
                activeConfig = null
                refreshTimer?.cancel()
                code.text = "------"
                timerText.text = ""
                return
            }

            val config = parseOtpAuth(raw) ?: run {
                val secret = raw
                    .replace(Regex("[^A-Za-z2-7]"), "")
                    .uppercase(Locale.US)
                if (secret.length >= 8 && secret.all { it in "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567" }) {
                    TotpConfig(secret, "2FA", "", "SHA1", 6, 30L, "")
                } else null
            }

            if (config != null) {
                if (userEdited) saveAuthenticator(config, accountOverride = "")
                renderCode(config)
            } else {
                activeConfig = null
                refreshTimer?.cancel()
                code.text = "------"
                timerText.text = ""
            }
        }

        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                handleLink(s?.toString().orEmpty(), userEdited = true)
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        container.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        container.addView(code, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62)))
        container.addView(timerText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)))
        container.addView(copyCode, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val dialog = AlertDialog.Builder(this)
            .setTitle("2FA Link")
            .setView(container)
            .setNegativeButton("OK") { _, _ ->
                // Keep manually entered keys available for login autofill. They become an
                // Accounts entry only if Google confirms a setup on the authenticator page.
                activeConfig?.let {
                    saveAuthenticator(it)
                    stagePendingAuthenticatorChange(it)
                }
            }
            .setPositiveButton("Clear", null)
            .create()
        dialog.setOnDismissListener {
            // Keep the saved link and current TOTP state across dialog closes.
            // The timer is stopped only while the dialog is hidden; reopening it
            // reconstructs the code from the persisted link.
            refreshTimer?.cancel()
            refreshTimer = null
            activeConfig = null
        }
        dialog.show()
        applyRoundedDialogCorners(dialog)
        // Clear resets only the current 2FA link/code while keeping this page open,
        // so another key can be entered immediately. The dialog can still be closed
        // normally with OK, back, or by tapping outside.
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            prefs.edit().remove(KEY_TWO_FA_LINK).remove(KEY_TOTP_OWNER).apply()
            clearAuthenticator()
            refreshTimer?.cancel()
            refreshTimer = null
            activeConfig = null
            code.text = "------"
            timerText.text = ""
            input.setText("")
            input.requestFocus()
        }

        if (savedLink.isNotBlank()) {
            handleLink(savedLink)
        }
    }

    private fun copyToClipboard(label: String, value: String) {
        val clipboard = getSystemService(android.content.ClipboardManager::class.java)
        clipboard?.setPrimaryClip(android.content.ClipData.newPlainText(label, value))
    }

    private fun extractEmailFromText(value: String): String {
        val match = Regex("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", RegexOption.IGNORE_CASE).find(value)
        return match?.value?.lowercase(Locale.US).orEmpty()
    }

    private fun loadAuthenticatorAccounts(): JSONArray {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val raw = prefs.getString(KEY_TOTP_ACCOUNTS, "[]") ?: "[]"
        val accounts = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        val migrateChangeLog = prefs.getInt(KEY_ACCOUNT_CHANGE_LOG_VERSION, 0) < 1
        // Normalize old entries too: an account with an authenticator must never retain
        // a recovery email in the saved Accounts data.
        var changed = false
        for (i in 0 until accounts.length()) {
            val item = accounts.optJSONObject(i) ?: continue
            val hasTwoFa = formatSavedAuthenticatorKey(item.optString("twoFa").ifBlank { item.optString("secret") }).isNotBlank()
            if (hasTwoFa && item.optString("recoveryEmail").isNotBlank()) {
                item.put("recoveryEmail", "")
                changed = true
            }
        }
        if (changed || migrateChangeLog) {
            prefs.edit()
                .putString(KEY_TOTP_ACCOUNTS, accounts.toString())
                .putInt(KEY_ACCOUNT_CHANGE_LOG_VERSION, 1)
                .apply()
        }
        if (migrateChangeLog) saveAuthenticatorLogFile(accounts)
        return accounts
    }

    private fun saveAuthenticatorAccounts(array: JSONArray) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_TOTP_ACCOUNTS, array.toString())
            .apply()
    }

    // Saved-account records use the raw Base32 key with no visual separators.
    private fun formatSavedAuthenticatorKey(secret: String): String {
        return secret.replace("\\s".toRegex(), "").uppercase(Locale.US)
    }

    private fun showSavedAuthenticatorAccountsDialog() {
        val allAccounts = loadAuthenticatorAccounts()
        val accounts = changedAccountRecords(allAccounts)
        val scroll = android.widget.ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }

        fun rebuild() {
            list.removeAllViews()
            if (accounts.length() == 0) {
                list.addView(TextView(this@MainActivity).apply {
                    text = "No changed accounts yet."
                    textSize = 15f
                    setPadding(dp(16), dp(18), dp(16), dp(18))
                    setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
                })
                return
            }
            for (i in 0 until accounts.length()) {
                val item = accounts.optJSONObject(i) ?: continue
                val account = item.optString("account")
                val password = item.optString("password")
                val twoFa = formatSavedAuthenticatorKey(item.optString("twoFa").ifBlank { item.optString("secret") })
                val recovery = item.optString("recoveryEmail")
                val appPassword = item.optString("appPassword")
                val creationTime = accountCreationTime(item)
                val ads = item.optString("ads")
                val youtubePremium = item.optString("youtubePremium")
                val backupCodes = readAccountBackupCodes(item)
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_LTR
                    setPadding(dp(12), dp(10), dp(6), dp(10))
                }
                val info = TextView(this@MainActivity).apply {
                    text = buildString {
                        if (account.isNotBlank()) append(account)
                        if (password.isNotBlank()) append("\t").append(password)
                        if (twoFa.isNotBlank()) append("\t").append(twoFa)
                        else if (recovery.isNotBlank()) append("\t").append(recovery)
                        if (backupCodes.isNotEmpty()) append("\nBackup Codes: ").append(backupCodes.joinToString(" "))
                        if (creationTime.isNotBlank()) append("\tCreation Time: ").append(creationTime)
                        if (ads.isNotBlank()) append("\t").append(ads)
                        if (youtubePremium.isNotBlank()) append("\t").append(youtubePremium)
                        if (appPassword.isNotBlank()) append("\t").append(appPassword)
                    }
                    textSize = 14f
                    setTextIsSelectable(true)
                    setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
                    setPadding(0, 0, dp(8), 0)
                }
                val valueToCopy = buildString {
                    append(account).append('\t').append(password).append('\t')
                        .append(twoFa.ifBlank { recovery }).append("\t\t").append(backupCodes.joinToString("\t"))
                        .append('\t').append(creationTime).append('\t').append(ads).append('\t').append(youtubePremium)
                        .append('\t').append(appPassword)
                }
                val copy = ImageButton(this@MainActivity).apply {
                    setImageResource(com.em.browser.R.drawable.ic_copy)
                    scaleType = ImageView.ScaleType.CENTER
                    contentDescription = "Copy $account"
                    isClickable = true
                    isFocusable = true
                    setPadding(0, 0, 0, 0)
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)
                    setOnClickListener {
                        if (valueToCopy.isNotBlank()) copyToClipboard("Account", valueToCopy)
                    }
                }
                val delete = TextView(this@MainActivity).apply {
                    text = "×"
                    textSize = 26f
                    gravity = Gravity.CENTER
                    setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
                    contentDescription = "Delete $account"
                    isClickable = true
                    isFocusable = true
                    setPadding(dp(8), 0, dp(8), 0)
                    setOnClickListener {
                        val accountToDelete = accounts.optJSONObject(i)?.optString("account").orEmpty()
                        if (backupAutomationCandidateAccount.equals(accountToDelete, true)) {
                            backupAutomationIgnoredAccount = backupAutomationCandidateAccount
                            backupAutomationIgnoredCodes = backupAutomationCandidateCodes
                        }
                        val latestAccounts = loadAuthenticatorAccounts()
                        for (sourceIndex in latestAccounts.length() - 1 downTo 0) {
                            if (latestAccounts.optJSONObject(sourceIndex)?.optString("account").orEmpty().equals(accountToDelete, true)) {
                                latestAccounts.remove(sourceIndex)
                            }
                        }
                        accounts.remove(i)
                        saveAuthenticatorAccounts(latestAccounts)
                        saveAuthenticatorLogFile(latestAccounts)
                        clearStagedSignInCredentials(accountToDelete)
                        clearAllStagesForAccount(accountToDelete)
                        rebuild()
                    }
                }
                row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(copy, LinearLayout.LayoutParams(dp(40), dp(40)))
                row.addView(delete, LinearLayout.LayoutParams(dp(40), dp(40)))
                list.addView(row, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
                if (i < accounts.length() - 1) {
                    list.addView(View(this@MainActivity).apply {
                        setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorOutlineVariant))
                    }, LinearLayout.LayoutParams(-1, dp(1)))
                }
            }
        }

        rebuild()
        scroll.addView(list)
        AlertDialog.Builder(this)
            .setTitle("Accounts")
            .setView(scroll)
            .setNegativeButton("Copy All", null)
            .setPositiveButton("OK", null)
            .create().also { dialog ->
                dialog.show()
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                    val all = buildString {
                        for (i in 0 until accounts.length()) {
                            val item = accounts.optJSONObject(i) ?: continue
                            val account = item.optString("account")
                            val password = item.optString("password")
                            val twoFa = formatSavedAuthenticatorKey(item.optString("twoFa").ifBlank { item.optString("secret") })
                            val recovery = item.optString("recoveryEmail")
                            val appPassword = item.optString("appPassword")
                            val creationTime = accountCreationTime(item)
                            val ads = item.optString("ads")
                            val youtubePremium = item.optString("youtubePremium")
                            val backupCodes = readAccountBackupCodes(item).joinToString("\t")
                            if (account.isNotBlank()) {
                                append(account).append('\t').append(password).append('\t')
                                    .append(twoFa.ifBlank { recovery }).append("\t\t").append(backupCodes)
                                    .append('\t').append(creationTime).append('\t').append(ads).append('\t').append(youtubePremium)
                                    .append('\t').append(appPassword).append('\n')
                            }
                        }
                    }.trimEnd('\n')
                    if (all.isNotBlank()) copyToClipboard("Accounts", all)
                }
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTypeface(null, android.graphics.Typeface.BOLD)
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTypeface(null, android.graphics.Typeface.BOLD)
                applyRoundedDialogCorners(dialog)
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            }
    }
    private fun showRecoveryEmailInfoDialog() {
        AlertDialog.Builder(this)
            .setTitle("Recovery")
            .setMessage("Press On to remove the recovery email from the currently open Google account. If Google asks for additional verification, complete it manually.")
            .setPositiveButton("OK", null)
            .create().also { it.show(); applyRoundedDialogCorners(it) }
    }

    private fun showPasswordChangeDialog() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val savedCurrent = prefs.getString(KEY_PASSWORD_CURRENT, passwordAutomationCurrent) ?: ""
        val savedNew = prefs.getString(KEY_PASSWORD_NEW, passwordAutomationNew) ?: ""

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), 0, dp(8), 0)
        }

        fun passwordField(hint: String, value: String): EditText = EditText(this).apply {
            this.hint = hint
            setText(value)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            isSingleLine = true
        }

        val savedRecovery = prefs.getString(KEY_RECOVERY_EMAIL_VALUE, recoveryEmailValue) ?: ""
        val current = passwordField("Current password", savedCurrent)
        val newPassword = passwordField("New password", savedNew)
        val currentRecovery = EditText(this).apply {
            hint = "Current Recovery"
            setText(savedRecovery)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            isSingleLine = true
        }
        fun addSuggestions(field: EditText, suggestions: List<String>) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(field, LinearLayout.LayoutParams(0, dp(56), 1f))
            val button = android.widget.Button(this).apply {
                text = "..."
                contentDescription = "Show suggestions for ${field.hint}"
                setOnClickListener { anchor ->
                    val popup = android.widget.PopupMenu(this@MainActivity, anchor)
                    suggestions.forEach { value -> popup.menu.add(value) }
                    popup.setOnMenuItemClickListener { item ->
                        field.setText(item.title)
                        field.setSelection(field.length())
                        true
                    }
                    popup.show()
                }
            }
            row.addView(button, LinearLayout.LayoutParams(dp(52), dp(56)))
            container.addView(row, LinearLayout.LayoutParams(-1, dp(56)))
        }
        container.addView(current, LinearLayout.LayoutParams(-1, dp(56)))
        addSuggestions(newPassword, listOf("horiyamo12", "Homjdjfhghd", "Teghdjdjkdj646"))
        container.addView(android.widget.Button(this).apply {
            text = "Backup codes (Import / Export)"
            setOnClickListener { showBackupCodesDialog() }
        }, LinearLayout.LayoutParams(-1, dp(56)))
        addSuggestions(currentRecovery, listOf("alexalex15x21@gmail.com", "so4173j9@gmail.com"))

        val dialog = AlertDialog.Builder(this)
            .setTitle("Password")
            .setView(container)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val oldPassword = current.text?.toString().orEmpty()
                val newValue = newPassword.text?.toString().orEmpty()
                passwordAutomationCurrent = oldPassword
                passwordAutomationNew = newValue
                val recoveryValue = currentRecovery.text?.toString()?.trim().orEmpty()
                recoveryEmailValue = recoveryValue
                prefs.edit()
                    .putString(KEY_PASSWORD_CURRENT, oldPassword)
                    .putString(KEY_PASSWORD_NEW, newValue)
                    .putString(KEY_RECOVERY_EMAIL_VALUE, recoveryValue)
                    .apply()
                if (recoveryValue != savedRecovery || (devicesAutomationActive && recoveryTargetForRun.isBlank())) {
                    saveRecoveryTarget(currentWebView()?.let { accountKeyByWebView[it] }.orEmpty(), recoveryValue)
                }

                dialog.dismiss()
                Snackbar.make(drawerLayout, "Password data saved", Snackbar.LENGTH_SHORT).show()
            }
        }
        dialog.show()
        applyRoundedDialogCorners(dialog)
    }

    private fun showBackupCodesDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), 0, dp(20), 0)
        }
        val account = EditText(this).apply {
            hint = "Google account email"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            isSingleLine = true
            setText(accountKeyForStages())
        }
        val codes = EditText(this).apply {
            hint = "Backup codes: one 8-digit code per line"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            maxLines = 6
        }
        container.addView(account, LinearLayout.LayoutParams(-1, dp(56)))
        container.addView(codes, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(android.widget.Button(this).apply {
            text = "Paste"
            setOnClickListener {
                val clipboard = getSystemService(android.content.ClipboardManager::class.java)
                val text = clipboard?.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString().orEmpty()
                if (text.isNotBlank()) codes.setText(text)
            }
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(android.widget.Button(this).apply {
            text = "Export"
            setOnClickListener {
                val key = account.text.toString().trim().lowercase(Locale.US)
                val accounts = loadAuthenticatorAccounts()
                val matches = (0 until accounts.length()).mapNotNull { accounts.optJSONObject(it) }
                    .filter { it.optString("account").trim().equals(key, true) }
                val saved = matches.singleOrNull()?.let { readAccountBackupCodes(it) }.orEmpty()
                if (saved.isEmpty()) {
                    codes.error = "No saved codes for this account"
                } else {
                    val text = saved.joinToString("\n")
                    codes.setText(text)
                    getSystemService(android.content.ClipboardManager::class.java)
                        ?.setPrimaryClip(android.content.ClipData.newPlainText("Backup codes", text))
                    Snackbar.make(drawerLayout, "Backup codes copied to clipboard", Snackbar.LENGTH_LONG).show()
                }
            }
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        container.addView(actions)
        val dialog = AlertDialog.Builder(this).setTitle("Backup codes")
            .setView(container).setNegativeButton("Cancel", null).setPositiveButton("Save", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val key = account.text.toString().trim().lowercase(Locale.US)
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(key).matches()) {
                    account.error = "Enter the Google account email"
                    return@setOnClickListener
                }
                val values = codes.text.toString().split(Regex("[\\n,;\\t]+"))
                    .map { it.trim().replace(Regex("\\s+"), "") }.filter { it.isNotEmpty() }
                if (values.size !in 2..10 || values.distinct().size != values.size || values.any { !it.matches(Regex("[0-9]{8}")) }) {
                    codes.error = "Enter 2 to 10 different codes, 8 digits each"
                    return@setOnClickListener
                }
                val accounts = loadAuthenticatorAccounts()
                if ((0 until accounts.length()).count { accounts.optJSONObject(it)?.optString("account").orEmpty().trim().equals(key, true) } > 1) {
                    account.error = "Duplicate account records; cannot save safely"
                    return@setOnClickListener
                }
                if (!saveAccountBackupCodes(key, values)) {
                    codes.error = "Could not save backup codes"
                    return@setOnClickListener
                }
                dialog.dismiss()
                Snackbar.make(drawerLayout, "Backup codes saved", Snackbar.LENGTH_SHORT).show()
            }
        }
        dialog.show()
        applyRoundedDialogCorners(dialog)
    }

    private fun isSecurityStageOwner(view: WebView): Boolean =
        (!passwordAutomationActive || passwordAutomationView === view) &&
            (!authenticatorAutomationActive || authenticatorAutomationView === view) &&
            (!twoStepAutomationActive || twoStepAutomationView === view) &&
            (backupAutomationView == null || backupAutomationView === view) &&
            (!adsAutomationActive || adsAutomationView === view) &&
            (!devicesAutomationActive || devicesAutomationView === view) &&
            (!automationStageHandoffPending || securityStageHandoffView == null || securityStageHandoffView === view)

    private fun isPasswordRun(view: WebView, token: String): Boolean =
        passwordAutomationActive && passwordAutomationView === view && token.isNotBlank() && token == passwordConfirmationToken

    private fun isAuthenticatorRun(view: WebView, token: String): Boolean =
        authenticatorAutomationActive && authenticatorAutomationView === view && token.isNotBlank() && token == authenticatorAutomationRemovalToken

    private fun canDriveAuthenticator(view: WebView, token: String): Boolean =
        isAuthenticatorRun(view, token) && view === currentWebView() && automationMasterEnabled &&
            authenticatorAutomationEnabled && !automationActivityStopped && !googleVerificationActive && !googleVerificationCheckPending &&
            credentialHost(android.net.Uri.parse(view.url.orEmpty())) != null

    private fun cancelSecurityAutomationForView(view: WebView) {
        val cancelPassword = passwordAutomationActive && passwordAutomationView === view
        val cancelAuthenticator = authenticatorAutomationActive && authenticatorAutomationView === view
        val cancelTwoStep = twoStepAutomationActive && twoStepAutomationView === view
        val cancelDevices = devicesAutomationActive && devicesAutomationView === view
        val cancelBackup = backupAutomationView === view
        val cancelHandoff = automationStageHandoffPending && securityStageHandoffView === view
        if (!cancelPassword && !cancelAuthenticator && !cancelTwoStep && !cancelDevices && !cancelBackup && !cancelHandoff) return
        if (cancelPassword) clearPasswordAutomationState()
        if (cancelAuthenticator) stopAuthenticatorAutomation()
        if (cancelTwoStep) stopTwoStepAutomation()
        if (cancelDevices) stopDevicesAutomation()
        if (cancelBackup) stopBackupAutomation()
        if (cancelHandoff) {
            automationHandoffGeneration++
            automationStageHandoffPending = false
            automationLastHandoffStage = ""
            securityStageHandoffView = null
            securityStageHandoffAccount = ""
        }
        googleVerificationGeneration++
        googleVerificationProbeInFlight = false
        googleVerificationActive = false
        googleVerificationCheckPending = false
        googleVerificationSubmitIssued = false
        googleVerificationNoticeShown = false
        automationHasRunInCurrentGoogleSession = true
    }

    private fun resumeSecurityAutomation(view: WebView) {
        if (!automationMasterEnabled || automationActivityStopped || view !== currentWebView() || !isSecurityStageOwner(view)) return
        val ownsPassword = passwordAutomationActive && passwordAutomationView === view
        val ownsAuthenticator = authenticatorAutomationActive && authenticatorAutomationView === view
        val ownsBackup = backupAutomationView === view
        val ownsAds = adsAutomationActive && adsAutomationView === view
        val ownsDevices = devicesAutomationActive && devicesAutomationView === view
        val ownsDevicesHandoff = automationStageHandoffPending && automationLastHandoffStage == "recovery_set" &&
            securityStageHandoffView === view
        if (!ownsPassword && !ownsAuthenticator && !ownsBackup && !ownsAds && !ownsDevices && !ownsDevicesHandoff) return
        if (ownsDevices && devicesAutomationInitialPending) return
        if (ownsPassword && passwordAutomationSuccessPending) {
            completePasswordAutomationFromSuccess(view)
            return
        }
        if (ownsAuthenticator && authenticatorAutomationSuccessPending) {
            finishAuthenticatorAutomation(view, true)
            return
        }
        val uri = runCatching { android.net.Uri.parse(view.url.orEmpty()) }.getOrNull()
        if (uri?.scheme.equals("https", true) && uri?.port in listOf(-1, 443) &&
            uri?.host?.lowercase(Locale.US) in setOf("myaccount.google.com", "accounts.google.com")) {
            if (googleVerificationProbeInFlight) return
            googleVerificationGeneration++
            googleVerificationActive = false
            googleVerificationCheckPending = true
            injectGoogleVerification(view)
        }
    }

    private fun startPasswordChange(view: WebView? = currentWebView()) {
        // A password flow may only be started once for the current cycle.
        // onPageFinished and recovery callbacks can arrive close together.
        if (passwordAutomationActive || passwordFlowStartedForCurrentAutomation) return
        val webView = view ?: run {
            Snackbar.make(drawerLayout, "No open tab", Snackbar.LENGTH_SHORT).show()
            return
        }
        if (webView !== currentWebView() || tabs.none { it.webView === webView }) return

        passwordAutomationActive = true
        passwordAutomationView = webView
        passwordAutomationAccount = accountKeyByWebView[webView].orEmpty().ifBlank { currentAccountKey }
        passwordAutomationSuccessPending = false
        passwordFlowStartedForCurrentAutomation = true
        passwordChangeSubmitted = false
        passwordReauthSubmitted = false
        passwordConfirmationClickIssued = false
        passwordConfirmationToken = java.util.UUID.randomUUID().toString()
        recoveryEmailAutomationActive = false
        combinedAutomationWaitingForPassword = false
        // Clear only the previous password-flow lock before opening a fresh flow.
        // The lock itself is stored in sessionStorage by the page script so it
        // survives Google's navigation/reload between the submit and its result.
        webView.evaluateJavascript("try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); sessionStorage.removeItem('__emPasswordFlowReauth'); sessionStorage.removeItem('__emPasswordManualSubmit'); } catch(e) {}", null)
        webView.loadUrl(withSelectedLanguage(accountRecoveryPasswordUrl(webView)))
    }

    /**
     * Continue the current Auto pipeline after a child automation switch is
     * turned OFF while that stage is active.  A disabled stage must never run
     * again, and disabling it must not require toggling Auto OFF/ON.
     */
    private fun continueAfterDisabledStage(completedStage: String, view: WebView? = currentWebView()) {
        if (!automationMasterEnabled || automationCompletedForCurrentAccount) return
        val target = view ?: currentWebView() ?: return

        clearPasswordAutomationState()
        recoveryEmailAutomationActive = false
        phoneNumbersAutomationActive = false
        phoneNumbersDeletePending = false
        phoneNumbersDeleteConfirmIssued = false
        phoneNumbersDeleteCountBeforeClick = 0
        phoneNumbersNoDeleteSince = 0L
        recoveryRemovalAwaitingVerification = false
        combinedAutomationWaitingForPassword = false
        googleVerificationGeneration++
        googleVerificationProbeInFlight = false
        googleVerificationActive = false
        googleVerificationSubmitIssued = false
        googleVerificationNoticeShown = false
        googleVerificationCheckPending = false
        stopAppPasswordAutomation()
        stopAdsAutomation()
        stopYoutubePremiumAutomation()
        stopCreationTimeAutomation()
        stopDevicesAutomation()
        stopAuthenticatorAutomation()
        stopBackupAutomation()
        twoStepAutomationActive = false
        twoStepAutomationStage = "idle"

        startNextConfiguredStage(target, completedStage, immediate = true)
    }

    private fun injectPhoneNumbersAutomation(view: WebView) {
        if (!phoneNumbersAutomationActive || googleVerificationActive || googleVerificationCheckPending) return
        val script = """
            (function() {
              const normalize = value => String(value || '').replace(/\s+/g, ' ').trim();
              const visible = el => {
                if (!el) return false;
                const rect = el.getBoundingClientRect();
                const style = getComputedStyle(el);
                return rect.width > 0 && rect.height > 0 && style.display !== 'none' &&
                       style.visibility !== 'hidden' && style.opacity !== '0';
              };
              if (!location.pathname.includes('/two-step-verification/phone-numbers')) return 'waiting';
              const deletePending = %s;
              const confirmIssued = %s;

              const deleteButtons = Array.from(document.querySelectorAll('button,[role="button"]'))
                .filter(visible)
                .filter(el => /(?:delete|remove)\s+phone\s+number|(?:حذف|إزالة)\s+(?:رقم\s+)?الهاتف/i.test(
                  [el.getAttribute('aria-label'), el.getAttribute('title'), el.getAttribute('data-tooltip')]
                    .filter(Boolean).join(' ')
                ));

              const dialogs = Array.from(document.querySelectorAll('[role="dialog"],[aria-modal="true"]')).filter(visible);
              for (const dialog of dialogs) {
                const dialogText = normalize(dialog.innerText || dialog.textContent || '');
                if (!/(phone|number|الهاتف|رقم)/i.test(dialogText) || !/(remove|delete|حذف|إزالة)/i.test(dialogText)) continue;
                const confirm = Array.from(dialog.querySelectorAll('button,[role="button"]'))
                  .filter(visible)
                  .find(el => /^(remove|delete|yes|remove phone number|delete phone number|حذف|إزالة|نعم)$/i.test(
                    normalize(el.innerText || el.textContent || el.getAttribute('aria-label') || '')
                  ));
                if (confirm && !confirmIssued) {
                  confirm.click();
                  return 'confirm_clicked';
                }
              }

              const okButton = Array.from(document.querySelectorAll('button[data-mdc-dialog-action="ok"]'))
                .filter(visible)
                .find(el => /^ok$/i.test(normalize(el.innerText || el.textContent || '')));
              if (deletePending && !confirmIssued && okButton) {
                okButton.click();
                return 'confirm_clicked';
              }

              if (deletePending) {
                if (deleteButtons.length < %d) return 'deleted';
                return 'waiting';
              }
              if (deleteButtons.length > 0) {
                deleteButtons[0].click();
                return 'trash_clicked:' + deleteButtons.length;
              }

              const bodyText = normalize(document.body?.innerText || '');
              return /phone numbers?|add phone|الهاتف|رقم الهاتف/i.test(bodyText) ? 'no_numbers' : 'waiting';
            })();
        """.trimIndent().format(
            if (phoneNumbersDeletePending) "true" else "false",
            if (phoneNumbersDeleteConfirmIssued) "true" else "false",
            phoneNumbersDeleteCountBeforeClick
        )

        view.evaluateJavascript(script) { result ->
            if (!phoneNumbersAutomationActive) return@evaluateJavascript
            when {
                result?.startsWith("\"trash_clicked:") == true -> {
                    phoneNumbersDeletePending = true
                    phoneNumbersDeleteConfirmIssued = false
                    phoneNumbersDeleteCountBeforeClick = result.substringAfter(':').trimEnd('"').toIntOrNull() ?: 1
                    phoneNumbersNoDeleteSince = 0L
                    view.postDelayed({ injectPhoneNumbersAutomation(view) }, 350L)
                }
                result?.trim('"') == "confirm_clicked" -> {
                    phoneNumbersDeleteConfirmIssued = true
                    view.postDelayed({ injectPhoneNumbersAutomation(view) }, 500L)
                }
                result?.trim('"') == "deleted" -> {
                    phoneNumbersDeletePending = false
                    phoneNumbersDeleteConfirmIssued = false
                    phoneNumbersDeleteCountBeforeClick = 0
                    phoneNumbersNoDeleteSince = 0L
                    view.postDelayed({ injectPhoneNumbersAutomation(view) }, 350L)
                }
                result?.trim('"') == "no_numbers" -> {
                    val now = android.os.SystemClock.elapsedRealtime()
                    if (phoneNumbersNoDeleteSince == 0L) phoneNumbersNoDeleteSince = now
                    if (now - phoneNumbersNoDeleteSince >= 2000L) finishPhoneNumbersAutomation(view)
                    else view.postDelayed({ injectPhoneNumbersAutomation(view) }, 500L)
                }
                else -> {
                    phoneNumbersNoDeleteSince = 0L
                    view.postDelayed({ injectPhoneNumbersAutomation(view) }, 500L)
                }
            }
        }
    }

    private fun finishPhoneNumbersAutomation(view: WebView) {
        if (!phoneNumbersAutomationActive) return
        phoneNumbersAutomationActive = false
        phoneNumbersDeletePending = false
        phoneNumbersDeleteConfirmIssued = false
        phoneNumbersDeleteCountBeforeClick = 0
        phoneNumbersNoDeleteSince = 0L
        startNextConfiguredStage(view, "phone_numbers", extraDelay = 250L)
    }

    private fun startConfiguredAutomationForCurrentAccount() {
        if (!automationMasterEnabled || automationActivityStopped || automationStageHandoffPending) return
        if (automationCompletedForCurrentAccount || automationHasRunInCurrentGoogleSession) return
        if (combinedAutomationWaitingForPassword || passwordFlowStartedForCurrentAutomation || anyAutomationStageActive()) return

        // The child switches are the actual stage permissions. Auto only starts
        // the selected stages; it must never implicitly enable any child stage.
        automationHasRunInCurrentGoogleSession = true
        automationStageHandoffPending = false
        automationLastHandoffStage = ""
        securityStageHandoffView = null
        securityStageHandoffAccount = ""
        val view = currentWebView() ?: run {
            automationHasRunInCurrentGoogleSession = false
            return
        }

        // Start from the first enabled stage that has NOT already finished for this account.
        val first = nextRunnableStage(null, view)
        if (first == null) {
            // Nothing left to execute (nothing selected, or everything already done).
            finishAutomationPipelineIfNoNextStage()
        } else {
            launchStage(first, view)
        }
    }

    private fun anyAutomationStageActive(): Boolean =
        passwordAutomationActive || appPasswordAutomationActive || adsAutomationActive || youtubePremiumAutomationActive ||
            recoveryEmailAutomationActive || creationTimeAutomationActive || devicesAutomationActive || phoneNumbersAutomationActive ||
            authenticatorAutomationActive || twoStepAutomationActive || backupAutomationView != null

    private fun isAutomationPageUrl(url: String): Boolean =
        url.contains("google.com") || url.contains("youtube.com")

    private fun isStageEnabled(stage: String): Boolean = when (stage) {
        "creation_time" -> creationTimeAutomationEnabled
        "password" -> passwordAutomationEnabled
        "authenticator" -> authenticatorAutomationEnabled
        "two_step" -> twoStepAutomationEnabled
        "backup" -> backupAutomationEnabled
        "app_password" -> appPasswordAutomationEnabled
        "ads" -> adsAutomationEnabled
        "youtube_premium" -> youtubePremiumAutomationEnabled
        else -> false
    }

    /** First enabled stage after [after] (or from the start) that is not already finished for this account. */
    private fun nextRunnableStage(after: String?, view: WebView?): String? {
        val start = if (after == null) 0 else AUTOMATION_PIPELINE.indexOf(after) + 1
        for (i in start until AUTOMATION_PIPELINE.size) {
            val stage = AUTOMATION_PIPELINE[i]
            if (isStageEnabled(stage) && !isStageCompleted(stage, view)) return stage
        }
        return null
    }

    private fun launchStage(stage: String, view: WebView) {
        when (stage) {
            "creation_time" -> startCreationTimeAutomation(view)
            "password" -> startPasswordChange(view)
            "authenticator" -> startAuthenticatorAutomation(view)
            "two_step" -> startTwoStepAutomation(view)
            "backup" -> startBackupAutomation(view)
            "app_password" -> startAppPasswordAutomation(view)
            "ads" -> startAdsAutomation(view)
            "youtube_premium" -> startYoutubePremiumAutomation(view)
            else -> finishAutomationPipelineIfNoNextStage()
        }
    }

    // ---- Per-account stage completion record -------------------------------------------------

    private fun accountKeyForStages(view: WebView? = currentWebView()): String =
        (view?.let { accountKeyByWebView[it] }.orEmpty().ifBlank { currentAccountKey }).trim().lowercase(Locale.US)

    private fun loadCompletedStages() {
        completedStagesByAccount.clear()
        val raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_COMPLETED_STAGES, "") ?: ""
        if (raw.isBlank()) return
        runCatching {
            val obj = JSONObject(raw)
            for (account in obj.keys()) {
                val arr = obj.optJSONArray(account) ?: continue
                val set = mutableSetOf<String>()
                for (i in 0 until arr.length()) set.add(arr.optString(i))
                if (set.isNotEmpty()) completedStagesByAccount[account] = set
            }
        }
    }

    private fun saveCompletedStages() {
        val obj = JSONObject()
        for ((account, stages) in completedStagesByAccount) {
            if (stages.isNotEmpty()) obj.put(account, JSONArray(stages.toList()))
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_COMPLETED_STAGES, obj.toString()).apply()
    }

    private fun isStageCompleted(stage: String, view: WebView? = currentWebView()): Boolean {
        // Recovery rechecks the actual account during preflight before consulting its completion record.
        if (stage == "recovery_set") return false
        val account = accountKeyForStages(view)
        return account.isNotBlank() && completedStagesByAccount[account]?.contains(stage) == true
    }

    private fun markStageCompleted(stage: String, view: WebView? = currentWebView(), accountOverride: String = "") {
        val account = accountOverride.trim().lowercase(Locale.US).ifBlank { accountKeyForStages(view) }
        if (account.isBlank()) return
        completedStagesByAccount.getOrPut(account) { mutableSetOf() }.add(stage)
        saveCompletedStages()
    }

    private fun clearStageCompleted(stage: String, account: String = accountKeyForStages()) {
        if (account.isBlank()) return
        if (stage == "two_step" && account.equals(backupAutomationAccount, true)) {
            recoveryActionPermit = ""
            resetBackupAutomationCandidate()
        }
        if (completedStagesByAccount[account]?.remove(stage) == true) saveCompletedStages()
    }

    private fun clearAllStagesForAccount(account: String) {
        val key = account.trim().lowercase(Locale.US)
        if (key.isNotBlank() && key.equals(backupAutomationAccount, true)) {
            recoveryActionPermit = ""
            resetBackupAutomationCandidate()
        }
        if (key.isNotBlank() && completedStagesByAccount.remove(key) != null) saveCompletedStages()
    }

    // Single hand-off point for Auto stages. Disabled stages are skipped.
    private fun startNextConfiguredStage(view: WebView, completedStage: String, immediate: Boolean = false, extraDelay: Long = 0L, accountOverride: String = "") {
        if (!automationMasterEnabled || automationCompletedForCurrentAccount) return

        // A successful stage keeps its fixed 3s boundary; a disabled stage can
        // bypass it. Never queue the same hand-off twice.
        if (automationStageHandoffPending) return
        if (automationLastHandoffStage == completedStage) return
        automationLastHandoffStage = completedStage
        automationStageHandoffPending = true
        securityStageHandoffView = if (completedStage in setOf("password", "authenticator", "two_step", "backup", "creation_time", "ads", "recovery_set")) view else null
        securityStageHandoffAccount = if (securityStageHandoffView != null) accountOverride.ifBlank { accountKeyForStages(view) } else ""
        val handoffGeneration = ++automationHandoffGeneration
        val handoffDelay = (if (immediate) 0L else AUTOMATION_STAGE_GAP_MS) + extraDelay

        lateinit var handoff: Runnable
        handoff = Runnable {
            if (handoffGeneration != automationHandoffGeneration) return@Runnable
            if (view !== currentWebView() && completedStage in setOf("password", "authenticator", "two_step", "backup", "creation_time", "ads", "recovery_set") &&
                automationMasterEnabled && !automationCompletedForCurrentAccount && tabs.any { it.webView === view }) {
                view.postDelayed(handoff, 500L)
                return@Runnable
            }
            if (!automationMasterEnabled || automationCompletedForCurrentAccount || view !== currentWebView()) {
                automationStageHandoffPending = false
                securityStageHandoffView = null
                securityStageHandoffAccount = ""
                return@Runnable
            }
            if (automationActivityStopped || devicesAutomationPaused || googleVerificationActive || googleVerificationCheckPending) {
                view.postDelayed(handoff, 500L)
                return@Runnable
            }
            if (securityStageHandoffView === view && securityStageHandoffAccount.isNotBlank() &&
                accountKeyForStages(view).isNotBlank() &&
                !securityStageHandoffAccount.equals(accountKeyForStages(view), true)) {
                cancelSecurityAutomationForView(view)
                Snackbar.make(drawerLayout, "Automation stopped: Google account changed", Snackbar.LENGTH_LONG).show()
                return@Runnable
            }

            // Release the hand-off lock immediately before starting exactly one
            // next configured stage.  Any duplicate completion signal that
            // arrives during the 3s boundary was already ignored above.
            automationStageHandoffPending = false
            securityStageHandoffView = null
            securityStageHandoffAccount = ""

            // Skip every stage that is disabled OR already finished for this account.
            val next = if (completedStage in AUTOMATION_PIPELINE) nextRunnableStage(completedStage, view) else null
            if (next == null) finishAutomationPipelineIfNoNextStage() else launchStage(next, view)
        }
        view.postDelayed(handoff, handoffDelay)
    }

    private fun finishAutomationPipelineIfNoNextStage() {
        automationCompletedForCurrentAccount = true
        completedAccountKey = currentAccountKey
    }

    private fun injectGoogleVerification(view: WebView) {
        val uri = runCatching { android.net.Uri.parse(view.url.orEmpty()) }.getOrNull()
        if (!automationMasterEnabled || automationActivityStopped || view !== currentWebView() || !isSecurityStageOwner(view) ||
            googleVerificationProbeInFlight || !uri?.scheme.equals("https", true) ||
            uri?.host?.lowercase(Locale.US) !in setOf("myaccount.google.com", "accounts.google.com") ||
            uri?.port !in listOf(-1, 443)) return
        googleVerificationProbeInFlight = true
        val verificationGeneration = googleVerificationGeneration
        val devicesRun = if (devicesAutomationActive && devicesAutomationView === view) devicesAutomationGeneration else null
        val devicesDocument = devicesAutomationDocumentGeneration
        val devicesUrl = view.url.orEmpty()
        val current = JSONObject.quote(passwordAutomationCurrent)
        val script = """
            (function() {
              if (location.protocol !== 'https:' || !['accounts.google.com', 'myaccount.google.com'].includes(location.hostname) ||
                  (location.port && location.port !== '443')) return 'waiting';
              const currentPassword = $current;
              if (document.readyState !== 'complete') return 'waiting';
              const visible = el => {
                if (!el) return false;
                const r = el.getBoundingClientRect();
                if (r.width <= 1 || r.height <= 1) return false;
                for (let node = el; node; node = node.parentElement) {
                  const s = getComputedStyle(node);
                  if (node.hidden || s.display === 'none' || s.visibility === 'hidden' || Number(s.opacity) === 0) return false;
                }
                return true;
              };
              const textOf = el => String(el?.innerText || el?.textContent || '').replace(/\s+/g,' ').trim();
              const bodyText = textOf(document.body);
              const verificationText = /to continue,? first verify it'?s you|first verify it'?s you|تحقق من هويتك|للتمكن من المتابعة.*تحقق/i.test(bodyText);
              if (${devicesRun != null} && !bodyText) return 'waiting';
              if (${devicesRun != null} && (/verify it.?s you|confirm it.?s you|verify your identity|verify your account|complete (?:the )?verification|sign in to (?:continue|your google account)|checking your browser|unusual traffic|i.m not a robot|تحقق من هويتك|للتمكن من المتابعة.*تحقق/i.test(bodyText) ||
                  Array.from(document.querySelectorAll('input[type="password"],iframe[src*="recaptcha"],iframe[src*="captcha"]')).some(visible))) return 'devices_verification';
              // A backup-code challenge must never be mistaken for the password field.
              if (Array.from(document.querySelectorAll('input')).some(el => visible(el) &&
                  (el.id === 'backupCodePin' || (el.getAttribute('aria-label') || '').trim().toLowerCase() === 'enter a backup code'))) return 'waiting';
              const isPasswordInput = el => {
                if (!el || el.type !== 'password' || !visible(el) || el.readOnly || el.matches(':disabled') ||
                    el.closest('[inert], [aria-disabled="true"], [aria-readonly="true"]')) return false;
                let {left, right, top, bottom} = el.getBoundingClientRect();
                if (right <= 0 || bottom <= 0 || left >= innerWidth || top >= innerHeight) return false;
                for (let node = el; node; node = node.parentElement) {
                  const style = getComputedStyle(node);
                  if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse' ||
                      Number(style.opacity) === 0 || style.contentVisibility === 'hidden' ||
                      (style.clipPath && style.clipPath !== 'none') || (style.clip && style.clip !== 'auto') ||
                      (style.maskImage && style.maskImage !== 'none') || /opacity\s*\(/i.test(style.filter)) return false;
                  if (node !== el) {
                    const bounds = node.getBoundingClientRect();
                    if (/^(hidden|clip|scroll|auto)$/.test(style.overflowX)) { left = Math.max(left, bounds.left); right = Math.min(right, bounds.right); }
                    if (/^(hidden|clip|scroll|auto)$/.test(style.overflowY)) { top = Math.max(top, bounds.top); bottom = Math.min(bottom, bounds.bottom); }
                    if (right - left <= 1 || bottom - top <= 1) return false;
                  }
                }
                const label = el.getAttribute('aria-label') || '';
                const references = ((el.getAttribute('aria-labelledby') || '') + ' ' + (el.getAttribute('aria-describedby') || '')).trim().split(/\s+/);
                const hints = [el.name, el.id, label, el.placeholder, el.title, el.autocomplete, references.join(' '),
                  ...Array.from(el.labels || [], textOf), ...references.map(id => textOf(document.getElementById(id)))].join(' ');
                return (el.name === 'Passwd' || label.toLowerCase().includes('enter your password')) &&
                  !/code|backup|sms|otp|pin|authenticator|one[\s-]*time|digit|numeric|phone|text message|رمز|احتياط|رسالة نصية/i.test(hints) &&
                  !/^(numeric|decimal|tel)$/i.test((el.getAttribute('inputmode') || '').trim()) && !(el.maxLength > 0 && el.maxLength <= 8) && !el.hasAttribute('pattern');
              };
              const exactInput = document.querySelector('div.El1b7b > div.klRug > div.UVOlK > div.rFrNMe.jBZgWe.zKHdkd > div.aCsJod.oJeWuf > div.aXBtI.Wic03c > div.Xb9hP > input.whsOnd.zHQkBf');
              const input = isPasswordInput(exactInput) ? exactInput :
                Array.from(document.querySelectorAll('input[type="password"], input[name="Passwd"]')).find(el =>
                  isPasswordInput(el)
                );
              if (!verificationText && !input) return 'none';
              if (${devicesRun != null}) return 'devices_verification';
              if (!input) return 'waiting';
              if (!currentPassword) return 'missing_password';
              if (input.value && input.value !== currentPassword) return 'waiting';

              const setValue = (el, value) => {
                const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
                if (setter) setter.call(el, value); else el.value = value;
                el.dispatchEvent(new Event('input', {bubbles:true}));
                el.dispatchEvent(new Event('change', {bubbles:true}));
              };
              const buttonText = el => String(el?.innerText || el?.value || el?.getAttribute('aria-label') || '').trim().toLowerCase();
              const buttons = Array.from(document.querySelectorAll('button, input[type="submit"]')).filter(visible);
              const exactNext = document.querySelector('c-wiz.A77ntc > main.Svhjgc > div.JYXaTc.lUWEgd:nth-of-type(3) > div.O1Slxf > div.TNTaPb > div.XjS9D.TrZEUc > div.VfPpkd-dgl2Hf-ppHlrf-sM5MNb > button.VfPpkd-LgbsSe.VfPpkd-LgbsSe-OWXEXe-k8QpJ.VfPpkd-LgbsSe-OWXEXe-dgl2Hf');
              const next = (exactNext && visible(exactNext)) ? exactNext :
                           buttons.find(el => /^next$/i.test(buttonText(el))) ||
                           buttons.find(el => /^(next|continue|verify|التالي|متابعة|تأكيد)$/i.test(buttonText(el)));
              if (!next || next.disabled) return 'waiting';
              if (input.__emVerificationSubmitted === true) return 'waiting';
              input.__emVerificationSubmitted = true;
              setValue(input, currentPassword);
              try { input.focus({preventScroll:true}); } catch(e) {}
              try { next.click(); return 'submitted'; } catch(e) {
                try {
                  for (const type of ['pointerdown','mousedown','pointerup','mouseup','click']) {
                    next.dispatchEvent(new MouseEvent(type,{bubbles:true,cancelable:true,view:window}));
                  }
                  return 'submitted';
                } catch(e2) { return 'waiting'; }
              }
            })();
        """.trimIndent()

        view.evaluateJavascript(script) { result ->
            if (!automationMasterEnabled || automationActivityStopped || view !== currentWebView() || !isSecurityStageOwner(view) ||
                verificationGeneration != googleVerificationGeneration) return@evaluateJavascript
            if (devicesRun != null && (!devicesAutomationActive || !devicesAutomationEnabled || devicesAutomationView !== view ||
                    devicesRun != devicesAutomationGeneration || devicesDocument != devicesAutomationDocumentGeneration ||
                    devicesUrl != view.url.orEmpty() || devicesAutomationPaused)) return@evaluateJavascript
            googleVerificationProbeInFlight = false
            googleVerificationCheckPending = false
            fun retryVerification(delay: Long) {
                view.postDelayed({
                    if (verificationGeneration == googleVerificationGeneration && googleVerificationActive) injectGoogleVerification(view)
                }, delay)
            }
            when (result?.trim('"')) {
                "devices_verification" -> {
                    noteDevicesVerification(view)
                    googleVerificationActive = true
                    googleVerificationSubmitIssued = false
                    retryVerification(700L)
                }
                "submitted" -> {
                    if (devicesRun != null) noteDevicesVerification(view)
                    googleVerificationActive = true
                    googleVerificationSubmitIssued = true
                    googleVerificationNoticeShown = false
                    retryVerification(1200L)
                }
                "waiting" -> {
                    if (devicesRun != null && (devicesAutomationAwaitingVerification ||
                            android.net.Uri.parse(devicesUrl).path.orEmpty().contains("/challenge", true))) noteDevicesVerification(view)
                    googleVerificationActive = true
                    googleVerificationSubmitIssued = false
                    retryVerification(700L)
                }
                "missing_password" -> {
                    if (devicesRun != null) noteDevicesVerification(view)
                    googleVerificationActive = true
                    if (!googleVerificationNoticeShown) {
                        googleVerificationNoticeShown = true
                        Snackbar.make(drawerLayout, "Enter your password on Google, or save it in Password to continue", Snackbar.LENGTH_LONG).show()
                    }
                    retryVerification(700L)
                }
                "none" -> {
                    val currentUri = runCatching { android.net.Uri.parse(view.url.orEmpty()) }.getOrNull()
                    val onChallenge = currentUri?.host.equals("accounts.google.com", true) &&
                        currentUri?.path.orEmpty().contains("/challenge", true)
                    if (onChallenge) {
                        if (devicesRun != null) noteDevicesVerification(view)
                        googleVerificationActive = true
                        if (!googleVerificationNoticeShown) {
                            googleVerificationNoticeShown = true
                            Snackbar.make(drawerLayout, "Complete Google verification to continue", Snackbar.LENGTH_LONG).show()
                        }
                        retryVerification(700L)
                        return@evaluateJavascript
                    }
                    googleVerificationActive = false
                    googleVerificationSubmitIssued = false
                    googleVerificationNoticeShown = false
                    if (devicesRun != null && !isDevicesDestination(devicesUrl)) {
                        val account = accountKeyByWebView[view].orEmpty()
                        if (devicesAutomationAccount.isNotBlank() && account.isNotBlank() &&
                            !devicesAutomationAccount.equals(account, true)) {
                            cancelSecurityAutomationForView(view)
                            Snackbar.make(drawerLayout, "Automation stopped: Google account changed", Snackbar.LENGTH_LONG).show()
                        } else if (recoveryDoneIssued && currentUri?.host.equals("myaccount.google.com", true) &&
                            currentUri?.path?.trimEnd('/') == "/security-checkup/1" && devicesAutomationCommitted && devicesAutomationFinishedAt > 0L) {
                            if (recoveryDoneAcknowledged) finishRecoverySet(view) else view.postDelayed({
                                if (devicesAutomationActive && devicesAutomationView === view && view === currentWebView()) injectGoogleVerification(view)
                            }, 500L)
                        } else if (devicesAutomationAwaitingVerification && !devicesAutomationFailed &&
                            currentUri?.host.equals("myaccount.google.com", true)) {
                            // Google must return to the Recovery page itself after verification.
                            // Reopening the original URL here can restart the flow repeatedly.
                        } else {
                            failDevicesDocument(view, devicesAutomationStartedUrl)
                        }
                        return@evaluateJavascript
                    }
                    view.evaluateJavascript("try { delete document.querySelector('input[name=Passwd]').__emVerificationSubmitted; } catch(e) {}", null)
                    // Resume only the automation stage that is actually active.
                    view.postDelayed({
                        if (verificationGeneration != googleVerificationGeneration || automationActivityStopped || view !== currentWebView() || !isSecurityStageOwner(view) ||
                            googleVerificationActive || googleVerificationCheckPending) return@postDelayed
                        if (devicesRun != null && (!devicesAutomationActive || devicesRun != devicesAutomationGeneration ||
                                devicesDocument != devicesAutomationDocumentGeneration || devicesUrl != view.url.orEmpty())) return@postDelayed
                        when {
                            passwordAutomationActive -> injectPasswordChangeScript(view)
                            appPasswordAutomationActive -> injectAppPasswordAutomation(view)
                            recoveryEmailAutomationActive -> injectRecoveryEmailRemovalScript(view)
                            devicesAutomationActive && recoveryDoneAcknowledged -> finishRecoverySet(view)
                            devicesAutomationActive -> {
                                devicesAutomationScheduledDocument = 0L
                                scheduleDevicesAutomation(view)
                            }
                            phoneNumbersAutomationActive -> injectPhoneNumbersAutomation(view)
                            authenticatorAutomationActive -> injectAuthenticatorAutomation(view)
                            twoStepAutomationActive -> injectTwoStepAutomation(view)
                        }
                    }, 350L)
                }
                else -> {
                    googleVerificationActive = true
                    retryVerification(700L)
                }
            }
        }
    }

    private fun installInspectMode(view: WebView) {
        if (!inspectModeEnabled) return
        val script = """
            (function() {
              try {
                if (window.__emInspectInstalled) return true;
                window.__emInspectInstalled = true;

                const esc = s => String(s || '').replace(/\s+/g,' ').trim();
                const visible = x => {
                  if (!x || x.nodeType !== 1) return false;
                  const r=x.getBoundingClientRect(), st=getComputedStyle(x);
                  return r.width>0 && r.height>0 && st.display!=='none' && st.visibility!=='hidden' && st.opacity!=='0';
                };
                const interactive = x => !!(x && x.nodeType===1 && (
                  x.matches?.('button,a,[role="button"],input,select,textarea,[tabindex]') ||
                  typeof x.onclick === 'function'
                ));
                const closestInteractive = x => {
                  let n=x;
                  for(let i=0;n&&i<12;i++,n=n.parentElement) if(interactive(n)) return n;
                  return x;
                };
                const cssSelector = x => {
                  if (!x || x.nodeType!==1) return '';
                  try {
                    if (x.id) return '#'+CSS.escape(x.id);
                  } catch(_) {}
                  const parts=[]; let cur=x;
                  while(cur && cur.nodeType===1 && cur !== document.body && parts.length<8){
                    let part=cur.tagName.toLowerCase();
                    try {
                      if(cur.classList?.length) part += '.'+Array.from(cur.classList).slice(0,3).map(CSS.escape).join('.');
                    } catch(_) {}
                    let n=1, sib=cur.previousElementSibling;
                    while(sib){ if(sib.tagName===cur.tagName) n++; sib=sib.previousElementSibling; }
                    if(n>1) part += ':nth-of-type('+n+')';
                    parts.unshift(part); cur=cur.parentElement;
                  }
                  return parts.join(' > ');
                };
                const xpath = x => {
                  if(!x || x.nodeType!==1) return '';
                  if(x.id) return '//*[@id='+JSON.stringify(x.id)+']';
                  const parts=[]; let cur=x;
                  while(cur && cur.nodeType===1){
                    let i=1, sib=cur.previousElementSibling;
                    while(sib){ if(sib.tagName===cur.tagName) i++; sib=sib.previousElementSibling; }
                    parts.unshift(cur.tagName.toLowerCase()+'['+i+']');
                    cur=cur.parentElement;
                  }
                  return '/'+parts.join('/');
                };
                const shadowPath = x => {
                  const path=[]; let cur=x;
                  while(cur){
                    const root=cur.getRootNode?.();
                    if(root && root.host){
                      path.unshift(cssSelector(cur));
                      cur=root.host;
                    } else {
                      path.unshift(cssSelector(cur)); break;
                    }
                  }
                  return path.filter(Boolean).join(' >>> ');
                };
                const attrs = x => {
                  const out={};
                  try { for(const a of Array.from(x.attributes||[])) out[a.name]=a.value; } catch(_) {}
                  return out;
                };
                const handler = function(e) {
                  if(!e || !e.isTrusted) return;
                  let el=(e.composedPath && e.composedPath()[0]) || e.target;
                  if(!el || el.nodeType!==1) return;
                  el=closestInteractive(el);
                  if(!visible(el)) return;
                  const r=el.getBoundingClientRect();
                  const data={
                    tag: el.tagName.toLowerCase(),
                    text: esc(el.innerText || el.textContent || '').slice(0,1000),
                    aria: esc(el.getAttribute('aria-label')),
                    ariaLabelledby: esc(el.getAttribute('aria-labelledby')),
                    title: esc(el.getAttribute('title')),
                    id: el.id || '',
                    classes: typeof el.className==='string' ? el.className : '',
                    href: el.href || el.getAttribute('href') || '',
                    value: el.value || '',
                    type: el.getAttribute('type') || '',
                    role: el.getAttribute('role') || '',
                    name: el.getAttribute('name') || '',
                    disabled: !!el.disabled || el.getAttribute('aria-disabled')==='true',
                    selector: cssSelector(el),
                    xpath: xpath(el),
                    shadowPath: shadowPath(el),
                    rect: {left:Math.round(r.left),top:Math.round(r.top),width:Math.round(r.width),height:Math.round(r.height)},
                    attributes: attrs(el),
                    outerHTML: String(el.outerHTML||'').slice(0,8000)
                  };
                  e.preventDefault(); e.stopPropagation();
                  try { window.EMInspect.report(JSON.stringify(data)); } catch(ignore) {}
                };
                window.__emInspectHandler=handler;
                document.addEventListener('click', handler, true);
                return true;
              } catch(err) { return false; }
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }

    private fun removeInspectMode(view: WebView) {
        view.evaluateJavascript("""
            (function(){
              try {
                if(window.__emInspectHandler) document.removeEventListener('click', window.__emInspectHandler, true);
                window.__emInspectHandler=null;
                window.__emInspectInstalled=false;
              } catch(e) {}
            })();
        """.trimIndent(), null)
    }

    private fun showInspectDetails(payload: String) {
        if (!inspectModeEnabled) return
        val obj = try { JSONObject(payload) } catch (_: Exception) { return }
        val tag=obj.optString("tag")
        val text=obj.optString("text")
        val aria=obj.optString("aria")
        val ariaLabelledby=obj.optString("ariaLabelledby")
        val title=obj.optString("title")
        val id=obj.optString("id")
        val classes=obj.optString("classes")
        val href=obj.optString("href")
        val value=obj.optString("value")
        val type=obj.optString("type")
        val role=obj.optString("role")
        val name=obj.optString("name")
        val selector=obj.optString("selector")
        val xpath=obj.optString("xpath")
        val shadowPath=obj.optString("shadowPath")
        val outer=obj.optString("outerHTML")
        val rect=obj.optJSONObject("rect")
        val attrs=obj.optJSONObject("attributes")
        val details=buildString {
            append("TAG: ").append(tag).append('\n')
            if(text.isNotBlank()) append("TEXT: ").append(text).append('\n')
            if(aria.isNotBlank()) append("ARIA: ").append(aria).append('\n')
            if(ariaLabelledby.isNotBlank()) append("ARIA-LABELLEDBY: ").append(ariaLabelledby).append('\n')
            if(title.isNotBlank()) append("TITLE: ").append(title).append('\n')
            if(id.isNotBlank()) append("ID: ").append(id).append('\n')
            if(classes.isNotBlank()) append("CLASS: ").append(classes).append('\n')
            if(role.isNotBlank()) append("ROLE: ").append(role).append('\n')
            if(type.isNotBlank()) append("TYPE: ").append(type).append('\n')
            if(name.isNotBlank()) append("NAME: ").append(name).append('\n')
            if(value.isNotBlank()) append("VALUE: ").append(value).append('\n')
            if(href.isNotBlank()) append("HREF: ").append(href).append('\n')
            if(selector.isNotBlank()) append("CSS SELECTOR: ").append(selector).append('\n')
            if(xpath.isNotBlank()) append("XPATH: ").append(xpath).append('\n')
            if(shadowPath.isNotBlank()) append("SHADOW PATH: ").append(shadowPath).append('\n')
            if(rect!=null) append("RECT: ").append(rect.toString()).append('\n')
            if(attrs!=null) append("ATTRIBUTES: ").append(attrs.toString()).append('\n')
            if(outer.isNotBlank()) append("\nOUTER HTML:\n").append(outer)
        }
        val body=TextView(this).apply { setText(details); textSize=12f; setTextIsSelectable(true); setPadding(dp(20),dp(8),dp(20),dp(8)) }
        val dialog=AlertDialog.Builder(this).setTitle("Inspect Element").setView(body)
            .setPositiveButton("Copy all", null).setNegativeButton("Close", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val cm=getSystemService(android.content.ClipboardManager::class.java)
                cm?.setPrimaryClip(android.content.ClipData.newPlainText("Inspect Element", details))
            }
        }
        dialog.show()
        applyRoundedDialogCorners(dialog)
    }

    private fun currentGoogleRapt(view: WebView): String? {
        val currentUri = android.net.Uri.parse(view.url.orEmpty())
        return currentUri.getQueryParameter("rapt")
            ?: currentUri.getQueryParameter("continue")
                ?.let { android.net.Uri.parse(it).getQueryParameter("rapt") }
    }

    private fun accountRecoverySetupUrl(view: WebView, setupUrl: String, campaign: String): String {
        val rapt = currentGoogleRapt(view)
        val continueUrl = android.net.Uri.parse("https://myaccount.google.com/security").buildUpon()
            .appendQueryParameter("hl", "en")
            .apply {
                if (!rapt.isNullOrBlank()) appendQueryParameter("rapt", rapt)
                appendQueryParameter("utm_source", "sign_in_no_continue")
            }
            .build()
            .toString()

        return android.net.Uri.parse(setupUrl).buildUpon().apply {
            if (!rapt.isNullOrBlank()) appendQueryParameter("rapt", rapt)
            appendQueryParameter("utm_source", "google-account")
            appendQueryParameter("utm_medium", "web")
            appendQueryParameter("utm_campaign", campaign)
            appendQueryParameter("continue", continueUrl)
            appendQueryParameter("hl", "en")
        }.build().toString()
    }

    private fun accountRecoveryPasswordUrl(view: WebView): String {
        val continueUrl = android.net.Uri.parse("https://myaccount.google.com/").buildUpon()
            .appendQueryParameter("utm_source", "sign_in_no_continue")
            .appendQueryParameter("authuser", "0")
            .build()
            .toString()

        return android.net.Uri.parse(PASSWORD_SETUP_URL).buildUpon().apply {
            appendQueryParameter("hl", "en")
            appendQueryParameter("continue", continueUrl)
            currentGoogleRapt(view)?.takeIf { it.isNotBlank() }?.let {
                appendQueryParameter("rapt", it)
            }
        }.build().toString()
    }

    private fun startAuthenticatorAutomation(view: WebView? = currentWebView()) {
        if (!automationMasterEnabled || !authenticatorAutomationEnabled) return
        if (authenticatorAutomationActive) return
        val targetView = view ?: return
        if (targetView !== currentWebView() || tabs.none { it.webView === targetView }) return
        if (authenticatorSecret.isBlank() && authenticatorOtpauthUri.isNotBlank()) {
            parseOtpAuth(authenticatorOtpauthUri)?.let { saveAuthenticator(it) }
        }
        authenticatorAutomationActive = true
        authenticatorAutomationView = targetView
        authenticatorAutomationAccount = accountKeyByWebView[targetView].orEmpty().ifBlank { currentAccountKey }
        authenticatorAutomationSuccessPending = false
        authenticatorAutomationStage = "open_setup"
        authenticatorAutomationQrScanned = false
        authenticatorAutomationCodeSubmitted = false
        authenticatorAutomationTurnOnClicked = false
        authenticatorAutomationFinalTurnOnClicked = false
        authenticatorAutomationFinalRefreshDone = false
        authenticatorAutomationSuccessSeen = false
        authenticatorAutomationLoadStarted = true
        authenticatorAutomationTrashClickIssued = false
        authenticatorAutomationRemoveAnywayClickIssued = false
        authenticatorAutomationRemoveOkClickIssued = false
        authenticatorAutomationRemovalToken = java.util.UUID.randomUUID().toString()
        authenticatorAutomationRemovalFlow = false
        authenticatorAutomationQrScanInFlight = false
        authenticatorAutomationSetupClickIssued = false
        // Continue on the exact WebView that just reported Password success.
        // Do not resolve currentWebView() again here: another tab becoming active
        // between the success callback and this hand-off must never steal the
        // Authenticator step.
        targetView.loadUrl(withSelectedLanguage(
            accountRecoverySetupUrl(targetView, AUTHENTICATOR_SETUP_URL, "authenticator-screen")
        ))
    }

    private fun stopAuthenticatorAutomation() {
        authenticatorAutomationView?.evaluateJavascript("window.__emAuthenticatorSetupClickIssued = false;", null)
        authenticatorAutomationActive = false
        authenticatorAutomationView = null
        authenticatorAutomationAccount = ""
        authenticatorAutomationSuccessPending = false
        authenticatorAutomationStage = "idle"
        authenticatorAutomationQrScanned = false
        authenticatorAutomationCodeSubmitted = false
        authenticatorAutomationTurnOnClicked = false
        authenticatorAutomationFinalTurnOnClicked = false
        authenticatorAutomationFinalRefreshDone = false
        authenticatorAutomationSuccessSeen = false
        authenticatorAutomationLoadStarted = false
        authenticatorAutomationTrashClickIssued = false
        authenticatorAutomationRemoveAnywayClickIssued = false
        authenticatorAutomationRemoveOkClickIssued = false
        authenticatorAutomationRemovalToken = ""
        authenticatorAutomationRemovalFlow = false
        authenticatorAutomationQrScanInFlight = false
        authenticatorAutomationSetupClickIssued = false
    }

    private fun startTwoStepAutomation(view: WebView? = currentWebView()) {
        if (!twoStepAutomationEnabled) return
        if (twoStepAutomationActive) return
        val target = view ?: return
        twoStepAutomationActive = true
        twoStepAutomationView = target
        twoStepAutomationAccount = accountKeyForStages(target)
        // Open the 2-Step overview, not its Authenticator subpage, then click
        // the visible "Turn on 2-Step Verification" action as soon as it loads.
        twoStepAutomationStage = "direct_click"
        twoStepAutomationRefreshDone = false
        twoStepAutomationTurnOnClicked = false
        twoStepAutomationSkipClicked = false
        twoStepAutomationFallbackRefreshDone = false
        target.loadUrl(withSelectedLanguage(
            accountRecoverySetupUrl(target, TWO_STEP_SETUP_URL, "two-step-verification")
        ))
    }

    private fun stopTwoStepAutomation() {
        twoStepAutomationActive = false
        twoStepAutomationView = null
        twoStepAutomationAccount = ""
        twoStepAutomationStage = "idle"
        twoStepAutomationRefreshDone = false
        twoStepAutomationTurnOnClicked = false
        twoStepAutomationSkipClicked = false
        twoStepAutomationFallbackRefreshDone = false
    }

    private fun finishTwoStepAutomation(view: WebView, success: Boolean) {
        if (!twoStepAutomationActive) return
        val account = twoStepAutomationAccount
        stopTwoStepAutomation()
        if (success) {
            Snackbar.make(drawerLayout, "2-Step Verification enabled — moving to the next stage", Snackbar.LENGTH_SHORT).show()
            markStageCompleted("two_step", view, account)
            startNextConfiguredStage(view, "two_step", extraDelay = 250L, accountOverride = account)
        }
    }

    private fun injectTwoStepAutomation(view: WebView) {
        if (!twoStepAutomationActive || !twoStepAutomationEnabled || !automationMasterEnabled) return
        if (view !== twoStepAutomationView || view !== currentWebView() || !view.isAttachedToWindow || automationActivityStopped ||
            credentialHost(android.net.Uri.parse(view.url.orEmpty())) == null) return
        val detectedAccount = accountKeyByWebView[view].orEmpty().trim().lowercase(Locale.US)
        if (twoStepAutomationAccount.isBlank()) twoStepAutomationAccount = detectedAccount
        if (twoStepAutomationAccount.isNotBlank() && detectedAccount.isNotBlank() && twoStepAutomationAccount != detectedAccount) {
            cancelSecurityAutomationForView(view)
            return
        }
        val successAccount = twoStepAutomationAccount
        val successUrl = view.url.orEmpty()
        // The 2-Step page is its own automation stage. A verification check
        // left over from the preceding Authenticator stage must never block
        // this stage from looking for Turn on / Skip. If Google actually shows
        // a re-verification page, the Turn on control simply will not be found,
        // while the normal verification handler can continue independently.
        val twoStepPath = android.net.Uri.parse(view.url.orEmpty()).path.orEmpty().lowercase(Locale.US)
        val onTwoStepPage = twoStepPath.startsWith("/signinoptions/twosv") ||
            twoStepPath.startsWith("/two-step-verification")
        if (!onTwoStepPage && (googleVerificationActive || googleVerificationCheckPending)) return

        val script = """
            (function() {
              if (window.top !== window || !['https://accounts.google.com', 'https://myaccount.google.com'].includes(location.origin)) return 'untrusted';
              const readyCode = typeof window.__emReadyAutofilledTotp === 'function' ? window.__emReadyAutofilledTotp() : null;
              if (readyCode) {
                const codeVisible = el => {
                  if (!el) return false;
                  const r = el.getBoundingClientRect();
                  const st = getComputedStyle(el);
                  return r.width > 1 && r.height > 1 && st.display !== 'none' && st.visibility !== 'hidden';
                };
                const codeText = el => ((el.innerText || el.textContent || el.value || el.getAttribute('aria-label') || el.getAttribute('title') || '') + '').replace(/\s+/g,' ').trim().toLowerCase();
                const codeButtons = Array.from(document.querySelectorAll('button,input[type=submit],[role=button]')).filter(codeVisible);
                const codeSubmit = codeButtons.find(e => /^(next|verify|confirm|continue|submit|done|التالي|تأكيد|تحقق|متابعة|تم)$/i.test(codeText(e)))
                  || codeButtons.find(e => /verify|confirm|continue|next|تحقق|تأكيد|متابعة/.test(codeText(e)));
                if (codeSubmit && !codeSubmit.disabled && window.__emTwoStepSubmittedUntil !== readyCode.expiresAt) {
                  window.__emTwoStepSubmittedUntil = readyCode.expiresAt;
                  codeSubmit.click();
                  return 'code_submitted';
                }
                return 'code_filled';
              }

              const norm = s => ((s || '') + '')
                .replace(/[«»\"“”‘’'`]/g, ' ')
                .replace(/[：:؛;،,!?؟()\[\]{}]/g, ' ')
                .replace(/\s+/g, ' ').trim().toLowerCase();
              const visible = e => {
                if (!e) return false;
                const r = e.getBoundingClientRect();
                const st = window.getComputedStyle(e);
                return r.width > 1 && r.height > 1 &&
                       st.visibility !== 'hidden' && st.display !== 'none' &&
                       st.opacity !== '0';
              };
              const text = e => norm([
                e.innerText, e.textContent, e.value,
                e.getAttribute('aria-label'), e.getAttribute('title'),
                e.getAttribute('data-tooltip'), e.getAttribute('data-tooltip-text')
              ].filter(Boolean).join(' '));
              const page = norm(document.body ? document.body.innerText : '');
              const isTwoStepPage = (() => {
                try {
                  const h1 = document.querySelector('h1.cdaFgf') ||
                             Array.from(document.querySelectorAll('h1')).find(e => norm(e.textContent) === '2-step verification');
                  return !!h1 && norm(h1.textContent) === '2-step verification';
                } catch (_) {
                  return /(^|\s)2[- ]?step verification(\s|$)/i.test(page);
                }
              })();

              // Google is forced to English by the Android app. Keep the matching
              // English-first and only retain Arabic as a harmless fallback.
              const turnOnRe = /(turn\s+on(?:\s+2[- ]?step\s+verification)?|enable\s+2[- ]?step(?:\s+verification)?|turn\s+on\s+2[- ]?step\s+verification|تفعيل\s+(?:ميزة\s+)?التحقق\s+بخطوتين)/i;
              const skipRe = /^(skip|not\s+now|later|تخطي|تخطى|تخطّي|التخطي|لاحقًا|لاحقا|ليس الآن|ليس الان)$/i;
              const successRe = /(2[- ]?step verification (?:is|has been) (?:on|enabled)|two[- ]?step verification (?:is|has been) (?:on|enabled)|2[- ]?step verification turned on|turned on successfully|turn off 2[- ]?step verification|disable 2[- ]?step verification|تم تفعيل التحقق بخطوتين|تم تفعيل ميزة التحقق بخطوتين)/i;

              const successAccounts = new Set();
              for (const el of document.querySelectorAll('[aria-label],[title]')) {
                if (!visible(el)) continue;
                const label = (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '');
                if (/google account/i.test(label)) for (const email of label.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig) || []) successAccounts.add(email.toLowerCase());
              }
              if (successRe.test(page) && ${JSONObject.quote(successAccount)} && successAccounts.size === 1 && successAccounts.has(${JSONObject.quote(successAccount)}) &&
                  location.href === ${JSONObject.quote(successUrl)} && location.origin === 'https://myaccount.google.com' &&
                  /^(?:\/u\/\d+)?\/(?:signinoptions\/twosv|two-step-verification)\/?${'$'}/.test(location.pathname) &&
                  document.visibilityState === 'visible' && document.readyState === 'complete') return 'success';

              // Prefer real controls. Do NOT treat a generic tabindex/container as
              // the button itself: Google's confirmation dialog can wrap BOTH
              // Cancel and Skip in one focusable container. Using that container's
              // center was the reason the old code could touch Cancel.
              const realControlSelector = 'button,a,[role="button"],input[type="button"],input[type="submit"]';
              const clickableSelector = realControlSelector + ',[tabindex]';
              const clickable = Array.from(document.querySelectorAll(clickableSelector)).filter(e => {
                return e.getAttribute('aria-disabled') !== 'true' && e.disabled !== true;
              });

              const nearestClickable = (e, forceDom) => {
                let n = e;
                for (let i = 0; n && i < 10; i++, n = n.parentElement) {
                  if (n.matches && n.matches(realControlSelector) && (forceDom || visible(n))) return n;
                }
                // Only use a generic tabindex element if there is no real button
                // ancestor at all.
                n = e;
                for (let i = 0; n && i < 10; i++, n = n.parentElement) {
                  if (n.matches && n.matches('[tabindex]') && (forceDom || visible(n))) return n;
                }
                return e;
              };

              const matchesTurnOn = e => turnOnRe.test(text(e));
              const matchesSkip = e => skipRe.test(text(e));

              // 1) First use the exact Google button identity supplied by Inspect.
              // This is intentionally independent of viewport visibility: the
              // element only needs to exist in the DOM.
              let turnOn = null;
              let turnOnIssued = false;
              try { turnOnIssued = window.__emTwoStepTurnOnIssued === true; } catch (_) {}
              try {
                turnOn = document.querySelector('button[jsname="Pr7Yme"][aria-label="Turn on 2-Step Verification"]');
                if (!turnOn) turnOn = document.querySelector('button[aria-label="Turn on 2-Step Verification"]');
                if (!turnOn) {
                  turnOn = document.querySelector('div:nth-of-type(2) > div:nth-of-type(3) > c-wiz > div > div.Hm1X5.JH1xTd > div.qsqhnc:nth-of-type(5) > div.VfPpkd-dgl2Hf-ppHlrf-sM5MNb > button.UywwFc-LgbsSe.UywwFc-LgbsSe-OWXEXe-dgl2Hf.UywwFc-StrnGf-YYd4I-VtOx3e');
                }
              } catch (_) {}
              if (!turnOn || !matchesTurnOn(turnOn)) turnOn = clickable.find(e => matchesTurnOn(e));

              // 2) Google sometimes puts the visible label in a nested span/div
              // without putting the label on the button itself. Find the exact
              // text node/element, then climb to its real clickable ancestor.
              if (!turnOn) {
                const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
                let node;
                while ((node = walker.nextNode())) {
                  const owner = node.parentElement;
                  if (!owner) continue;
                  if (turnOnRe.test(norm(node.nodeValue))) {
                    const candidate = nearestClickable(owner, true);
                    if (candidate) { turnOn = candidate; break; }
                  }
                }
              }

              // 3) Last DOM fallback: any visible element containing the exact
              // English phrase, then climb to its clickable ancestor.
              if (!turnOn) {
                const nodes = Array.from(document.querySelectorAll('body *'));
                for (const e of nodes) {
                  const t = text(e);
                  if (turnOnRe.test(t) && t.length < 180) {
                    const candidate = nearestClickable(e, true);
                    if (candidate) { turnOn = candidate; break; }
                  }
                }
              }

              const fireDomClick = e => {
                if (!e) return false;
                try { e.focus({preventScroll:true}); } catch (_) {}
                // Exactly one activation. Do not synthesize pointer/mouse events in
                // addition to click: Google's jsaction layer can treat those as
                // separate activations and reopen/close the same dialog.
                try { HTMLElement.prototype.click.call(e); return true; } catch (_) {
                  try { if (typeof e.click === 'function') { e.click(); return true; } } catch (_) {}
                }
                return false;
              };

              // The flow is deliberately stage-aware. Once Turn On has been
              // clicked, NEVER click it again while waiting for Google's sheet.
              // This prevents the automation from looping on the same page.
              // Confirmation sheet/dialog: only search for Skip after the real
              // Turn On click has happened. This keeps the two actions separate.
              const stage = "${twoStepAutomationStage}";
              const hasSkipControl = clickable.some(e => matchesSkip(e));
              if (stage === "confirm" || stage === "waiting_success") {
                let skip = clickable.find(e => matchesSkip(e));
                if (!skip) {
                  const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
                  let node;
                  while ((node = walker.nextNode())) {
                    const owner = node.parentElement;
                    if (!owner || !visible(owner)) continue;
                    if (skipRe.test(norm(node.nodeValue))) {
                      const candidate = nearestClickable(owner);
                      if (candidate && visible(candidate)) { skip = candidate; break; }
                    }
                  }
                }

                // The inspected Google dialog has a real button with aria-label="Skip"
                // and data-mdc-dialog-action="d7k1Xe". Prefer that exact button and
                // issue ONE DOM activation only. This avoids coordinate/touch races on
                // the dialog and, importantly, prevents a second activation while the
                // dialog is transitioning away.
                if (stage === "confirm") {
                  let skipIssued = false;
                  try { skipIssued = window.__emTwoStepSkipIssued === true; } catch (_) {}
                  if (skipIssued) return 'wait';
                  let exactSkip = null;
                  try {
                    exactSkip = document.querySelector('div.uW2Fw-Sx9Kwc.uW2Fw-Sx9Kwc-OWXEXe-n2to0e.uW2Fw-qON5Qe-FoKg4d-Sx9Kwc-fZiSAe:nth-of-type(13) > div.uW2Fw-wzTsW:nth-of-type(2) > div.uW2Fw-P5QLlc > div.uW2Fw-T0kwCb:nth-of-type(2) > div.VfPpkd-dgl2Hf-ppHlrf-sM5MNb:nth-of-type(3) > button.UywwFc-LgbsSe.UywwFc-LgbsSe-OWXEXe-dgl2Hf.UywwFc-StrnGf-YYd4I-VtOx3e');
                  } catch (_) {}
                  if (exactSkip && matchesSkip(exactSkip)) {
                    return 'skip_dom_exact';
                  }
                  if (skip) {
                    return 'skip_dom';
                  }
                }
                return 'wait';
              }

              // Activate Google's real Turn On control even when it is below the
              // WebView viewport; waiting for scroll coordinates can stall on mobile.
              if (stage === "direct_click" && turnOn && !turnOnIssued) {
                if (!visible(turnOn)) return 'wait';
                try { turnOn.scrollIntoView({behavior:'auto', block:'center', inline:'nearest'}); } catch (_) {}

                // One DOM activation only. The old native touch used CSS coordinates
                // as WebView pixels and marked the action issued before confirming it;
                // a missed touch therefore prevented every later attempt.
                try {
                  window.__emTwoStepTurnOnIssued = true;
                  const activated = fireDomClick(turnOn);
                  if (!activated) {
                    try { window.__emTwoStepTurnOnIssued = false; } catch (_) {}
                    return 'wait';
                  }
                  return activated ? 'turn_on_dom' : 'wait';
                } catch (_) {
                  try { window.__emTwoStepTurnOnIssued = false; } catch (_) {}
                  return 'wait';
                }
              }

              return 'wait';
            })();
        """.trimIndent()

        view.evaluateJavascript(script) { result ->
            if (!twoStepAutomationActive || view !== twoStepAutomationView || view !== currentWebView() || !view.isAttachedToWindow ||
                automationActivityStopped || credentialHost(android.net.Uri.parse(view.url.orEmpty())) == null) return@evaluateJavascript
            val value = result?.trim('"')?.replace("\\\"", "\"") ?: ""
            when {
                value == "code_submitted" -> view.postDelayed({ if (twoStepAutomationActive) injectTwoStepAutomation(view) }, 1000L)
                value == "code_filled" -> view.postDelayed({ if (twoStepAutomationActive) injectTwoStepAutomation(view) }, 1000L)
                value == "success" && view.url.orEmpty() == successUrl && twoStepAutomationAccount == successAccount &&
                    accountKeyByWebView[view].orEmpty().trim().lowercase(Locale.US) == successAccount &&
                    !googleVerificationActive && !googleVerificationCheckPending -> finishTwoStepAutomation(view, true)
                value == "turn_on_dom" -> {
                    // One DOM activation only.
                    twoStepAutomationTurnOnClicked = true
                    twoStepAutomationStage = "confirm"
                    view.postDelayed({ if (twoStepAutomationActive) injectTwoStepAutomation(view) }, 1400L)
                }
                value == "skip_dom_exact" || value == "skip_dom" -> {
                    // Exactly ONE Skip activation. The flag is set before the click so
                    // a fast JS/DOM mutation cannot cause the polling loop to issue it
                    // again. Do not send a native touch as a second activation.
                    twoStepAutomationSkipClicked = true
                    twoStepAutomationStage = "waiting_success"
                    val skipClickScript = """
                        (function(){
                          if (window.top !== window || !['https://accounts.google.com', 'https://myaccount.google.com'].includes(location.origin)) return 'untrusted';
                          try {
                            const selector = 'div.uW2Fw-Sx9Kwc.uW2Fw-Sx9Kwc-OWXEXe-n2to0e.uW2Fw-qON5Qe-FoKg4d-Sx9Kwc-fZiSAe:nth-of-type(13) > div.uW2Fw-wzTsW:nth-of-type(2) > div.uW2Fw-P5QLlc > div.uW2Fw-T0kwCb:nth-of-type(2) > div.VfPpkd-dgl2Hf-ppHlrf-sM5MNb:nth-of-type(3) > button.UywwFc-LgbsSe.UywwFc-LgbsSe-OWXEXe-dgl2Hf.UywwFc-StrnGf-YYd4I-VtOx3e';
                            let el = document.querySelector(selector);
                            if (!el) el = Array.from(document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit]')).find(e => ((e.getAttribute('aria-label') || e.textContent || '').trim() === 'Skip'));
                            if (el) { window.__emTwoStepSkipIssued = true; HTMLElement.prototype.click.call(el); return 'clicked'; }
                          } catch (_) {}
                          return 'missing';
                        })();
                    """.trimIndent()
                    view.evaluateJavascript(skipClickScript, null)
                    view.postDelayed({ if (twoStepAutomationActive) injectTwoStepAutomation(view) }, 1400L)
                }
                else -> view.postDelayed({ if (twoStepAutomationActive) injectTwoStepAutomation(view) }, 900L)
            }
        }
    }

    /** Send a short real touch sequence to the WebView. */
    private fun performNativeWebClick(view: WebView, x: Float, y: Float) {
        if (view.width <= 1 || view.height <= 1) return
        val safeX = x.coerceIn(1f, view.width - 1f)
        val safeY = y.coerceIn(1f, view.height - 1f)
        val downTime = android.os.SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, safeX, safeY, 0).apply {
            source = android.view.InputDevice.SOURCE_TOUCHSCREEN
        }
        view.dispatchTouchEvent(down)
        down.recycle()
        view.postDelayed({
            if (!view.isAttachedToWindow) return@postDelayed
            val upTime = android.os.SystemClock.uptimeMillis()
            val up = MotionEvent.obtain(downTime, upTime, MotionEvent.ACTION_UP, safeX, safeY, 0).apply {
                source = android.view.InputDevice.SOURCE_TOUCHSCREEN
            }
            view.dispatchTouchEvent(up)
            up.recycle()
        }, 80L)
    }

    private fun finishAuthenticatorAutomation(view: WebView, success: Boolean) {
        if (!isAuthenticatorRun(view, authenticatorAutomationRemovalToken) || view !== currentWebView() || automationActivityStopped) return
        val observedAccount = accountKeyByWebView[view].orEmpty()
        if (authenticatorAutomationAccount.isNotBlank() && observedAccount.isNotBlank() &&
            !authenticatorAutomationAccount.equals(observedAccount, true)) return
        val account = authenticatorAutomationAccount.ifBlank { observedAccount }
        currentAccountKey = account
        if (account.isNotBlank()) accountKeyByWebView[view] = account
        if (success) {
            parseOtpAuth(authenticatorOtpauthUri)?.let { config ->
                // Persist at Authenticator-stage success, before the separate 2-Step handoff.
                saveAuthenticator(config, recordChange = account.isNotBlank(), accountOverride = account.takeIf { it.isNotBlank() })
            }
            pendingAuthenticatorChange = null
            pendingAuthenticatorChangeAccount = ""
            pendingAuthenticatorChangeStartedAt = 0L
        }
        stopAuthenticatorAutomation()
        if (success) {
            Snackbar.make(drawerLayout, "Authenticator set up — moving to the next stage", Snackbar.LENGTH_SHORT).show()
            if (account.isNotBlank()) markStageCompleted("authenticator", view, account)
            if (automationMasterEnabled && !automationCompletedForCurrentAccount) {
                startNextConfiguredStage(view, "authenticator")
            }
        }
    }

    private fun injectAuthenticatorAutomation(view: WebView) {
        val runToken = authenticatorAutomationRemovalToken
        if (!canDriveAuthenticator(view, runToken)) return

        // Only the Authenticator-specific "Added just now" DOM marker completes
        // this stage; toast and generic page-success text are not reliable triggers.
        val successCheckStage = authenticatorAutomationStage
        if (successCheckStage == "waiting_success" || successCheckStage == "turn_on") {
            val successScript = """
                (function() {
                  const norm = s => ((s || '') + '').replace(/\s+/g, ' ').trim().toLowerCase();
                  const visible = el => !!el && el.offsetParent !== null;
                  const text = el => norm((el.innerText || el.textContent || el.value || el.getAttribute('aria-label') || el.getAttribute('title') || ''));
                  const markers = document.querySelectorAll('div.OZ7tnf > div.edUmvf.iUwXVd > ul.u7hyyf > li.K6ZZTd.iUwXVd.bs2km > div.iAwpk.lY6Rwe > div.GqRghe.tXqPBe.hv7wl:nth-of-type(2) > div.xsr7od:nth-of-type(2) > span[jsname="ZZJRD"]');
                  if (Array.from(markers).some(el => {
                    const style = window.getComputedStyle(el);
                    return el.getClientRects().length > 0 && style.visibility === 'visible' && style.display !== 'none' &&
                      ((el.innerText || el.textContent || '') + '').replace(/\s+/g, ' ').trim() === 'Added just now';
                  })) return 'success';

                  // Google can put a final "Skip"/"Done" action in a confirmation
                  // dialog after the last Turn On. Handle Skip while waiting for the
                  // Authenticator-specific confirmation marker.
                  if (${successCheckStage == "turn_on"}) return 'wait';
                  const skip = Array.from(document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit]'))
                    .filter(visible)
                    .find(el => /^(skip|تخطى|تخطي|تخطّي|لاحقًا|ليس الآن|not now)$/i.test(text(el)));
                  if (skip && !skip.disabled) {
                    skip.click();
                    return 'skip';
                  }
                  return 'wait';
                })();
            """.trimIndent()
            view.evaluateJavascript(successScript) { result ->
                if (!isAuthenticatorRun(view, runToken) || authenticatorAutomationStage != successCheckStage) return@evaluateJavascript
                when (result?.trim('"')) {
                    "success" -> {
                        if (view === currentWebView() && !automationActivityStopped) finishAuthenticatorAutomation(view, true)
                        else authenticatorAutomationSuccessPending = true
                    }
                    "skip" -> view.postDelayed({
                        if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view)
                    }, 250L)
                    else -> if (successCheckStage == "turn_on") clickAuthenticatorTurnOn(view) else view.postDelayed({
                        if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view)
                    }, 300L)
                }
            }
            return
        }

        when (authenticatorAutomationStage) {
            "open_setup" -> clickAuthenticatorSetupButton(view)
            "remove_authenticator_confirm" -> clickAuthenticatorRemoveAnyway(view)
            "qr" -> {
                if (!authenticatorAutomationQrScanned && !authenticatorAutomationQrScanInFlight) {
                    authenticatorAutomationQrScanInFlight = true
                    waitForAuthenticatorQrReady(view) { ready ->
                        if (!isAuthenticatorRun(view, runToken) || authenticatorAutomationStage != "qr") return@waitForAuthenticatorQrReady
                        if (!canDriveAuthenticator(view, runToken)) {
                            authenticatorAutomationQrScanInFlight = false
                            return@waitForAuthenticatorQrReady
                        }
                        if (!ready) {
                            authenticatorAutomationQrScanInFlight = false
                            view.postDelayed({ if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view) }, 1200L)
                            return@waitForAuthenticatorQrReady
                        }
                        scanQrFromCurrentPage(view, { canDriveAuthenticator(view, runToken) }) { raw ->
                            if (!isAuthenticatorRun(view, runToken)) return@scanQrFromCurrentPage
                            authenticatorAutomationQrScanInFlight = false
                            if (!canDriveAuthenticator(view, runToken) || authenticatorAutomationStage != "qr") return@scanQrFromCurrentPage
                            val parsed = raw?.let { parseOtpAuth(it) }
                            if (parsed == null) {
                                view.postDelayed({ if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view) }, 1500L)
                                return@scanQrFromCurrentPage
                            }
                            applyAuthenticatorRuntimeConfig(parsed)
                            authenticatorAutomationQrScanned = true
                            clickAuthenticatorNext(view)
                        }
                    }
                } else if (authenticatorAutomationQrScanned) {
                    clickAuthenticatorNext(view)
                }
            }
            "code" -> if (!authenticatorAutomationCodeSubmitted) fillAndSubmitAuthenticatorCode(view)
            "turn_on" -> clickAuthenticatorTurnOn(view)
            "final_refresh" -> {
                if (authenticatorAutomationFinalRefreshDone) {
                    authenticatorAutomationStage = "final_turn_on"
                    view.postDelayed({ if (isAuthenticatorRun(view, runToken)) clickAuthenticatorFinalTurnOn(view) }, 250L)
                } else {
                    // Give Google's first Turn On navigation time to settle, then
                    // perform the requested refresh exactly once. onPageFinished()
                    // will re-enter this stage after the refreshed page is ready.
                    view.postDelayed({
                        if (canDriveAuthenticator(view, runToken) && !authenticatorAutomationFinalRefreshDone) {
                            authenticatorAutomationFinalRefreshDone = true
                            view.reload()
                        }
                    }, 1200L)
                }
            }
            "final_turn_on" -> clickAuthenticatorFinalTurnOn(view)
            else -> view.postDelayed({ if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view) }, 300L)
        }
    }

    private fun clickAuthenticatorSetupButton(view: WebView) {
        val removalToken = authenticatorAutomationRemovalToken
        if (!canDriveAuthenticator(view, removalToken)) return
        val script = """
            (function() {
              const TRASH_CLICK_ALREADY_ISSUED = ${authenticatorAutomationTrashClickIssued};
              let domTrashIssued = false;
              try { domTrashIssued = window.__emAuthenticatorTrashIssued === true; } catch (_) {}
              // The trash and "Remove anyway" clicks each guard themselves with a
              // window.__em...Issued flag so an overlapping evaluateJavascript call
              // (e.g. this function re-running while a previous call's callback hasn't
              // updated the Kotlin-side stage yet) can't click the same thing twice.
              // The "Set up authenticator" click right after removal had no such guard,
              // so two overlapping calls could both see the still-present button and
              // both click it — the repeated-tap/jank the removal-then-setup step showed.
              let domSetupClickIssued = ${authenticatorAutomationSetupClickIssued};
              try { domSetupClickIssued = domSetupClickIssued || window.__emAuthenticatorSetupClickIssued === true; } catch (_) {}
              const visible = el => !!el && el.offsetParent !== null;
              const text = el => ((el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '') + '').replace(/\s+/g,' ').trim().toLowerCase();

              // Optional branch: if an existing Google Authenticator is already
              // present on the Authenticator page, remove it first. This branch
              // must never block the normal setup flow when the trash button is
              // absent. Use the exact selector supplied by Inspect and DOM click
              // so the element does not have to be in the viewport.
              let trash = null;
              try {
                trash = document.querySelector('div.OZ7tnf > div.edUmvf.iUwXVd > ul.u7hyyf > li.K6ZZTd.iUwXVd.bs2km > div.iAwpk.lY6Rwe > div.kvjuQc.biRLo:nth-of-type(3) > div.qsqhnc > button.pYTkkf-Bz112c-LgbsSe.wMI9H.Qd9OXe');
              } catch (_) {}
              // The trash action is a one-shot action for this automation run.
              // After Remove anyway closes the dialog, Google can leave the same
              // trash button in the DOM; never click it again.
              if (!TRASH_CLICK_ALREADY_ISSUED && !domTrashIssued && trash && /remove google authenticator/i.test(text(trash))) {
                if (!trash.disabled && trash.getAttribute('aria-disabled') !== 'true') {
                  try { window.__emAuthenticatorTrashIssued = true; trash.click(); return 'trash_clicked'; } catch (_) { try { window.__emAuthenticatorTrashIssued = false; } catch (_) {} }
                }
              }

              // The Remove anyway latch belongs only to the confirmation action.
              // It must NOT block the next setup stage: after the dialog is closed,
              // this same document can legitimately contain the Authenticator setup button.
              const dialogs = Array.from(document.querySelectorAll('[role="dialog"], dialog, [aria-modal="true"]')).filter(d => {
                const rect = d.getBoundingClientRect();
                if (rect.width <= 1 || rect.height <= 1) return false;
                for (let node = d; node; node = node.parentElement) {
                  const style = getComputedStyle(node);
                  if (node.hidden || node.getAttribute('aria-hidden') === 'true' || style.display === 'none' ||
                      style.visibility === 'hidden' || style.visibility === 'collapse' || Number(style.opacity) === 0) return false;
                }
                return true;
              });
              const removeDialog = dialogs.find(d => /you may lose access to your account|remove authenticator app\s*\?/i.test(text(d)));
              if (removeDialog) return 'remove_confirm';

              // After the old Authenticator has just been removed, Google renders a
              // specific setup button with a different class/DOM branch.  Handle that
              // branch explicitly so the successful no-trash path remains untouched.
              if (!domSetupClickIssued) {
                if (${authenticatorAutomationRemovalFlow}) {
                  let removedFlowTarget = null;
                  try {
                    removedFlowTarget = document.querySelector('div > div.Hm1X5.JH1xTd > div.ciRgbc.Ru61We:nth-of-type(3) > div.Mwd2Jc:nth-of-type(2) > div.xIcqYe > div.qsqhnc > div.VfPpkd-dgl2Hf-ppHlrf-sM5MNb > button.AeBiU-LgbsSe.AeBiU-LgbsSe-OWXEXe-Bz112c-M1Soyc.AeBiU-LgbsSe-OWXEXe-dgl2Hf');
                  } catch (_) {}
                  if (removedFlowTarget && !removedFlowTarget.disabled && removedFlowTarget.getAttribute('aria-disabled') !== 'true') {
                    try { window.__emAuthenticatorSetupClickIssued = true; try { delete window.__emAuthenticatorLastFilledCodeStep; } catch (_) { window.__emAuthenticatorLastFilledCodeStep = undefined; } removedFlowTarget.click(); return 'clicked'; } catch (_) { try { window.__emAuthenticatorSetupClickIssued = false; } catch (_) {} }
                  }
                  const removedFlowEls = Array.from(document.querySelectorAll('button,a,[role=button]')).filter(visible);
                  const removedFlowTextTarget = removedFlowEls.find(el => /^(set up authenticator|set up authenticator app|إعداد تطبيق المصادقة|إعداد المصادقة|إعداد تطبيق أداة المصادقة)$/i.test(text(el)));
                  // If Google has not rendered the new setup action yet, keep waiting;
                  // never mark this stage complete just because the old entry disappeared.
                  if (removedFlowTextTarget && !removedFlowTextTarget.disabled) {
                    try { window.__emAuthenticatorSetupClickIssued = true; try { delete window.__emAuthenticatorLastFilledCodeStep; } catch (_) { window.__emAuthenticatorLastFilledCodeStep = undefined; } removedFlowTextTarget.click(); return 'clicked'; } catch (_) { try { window.__emAuthenticatorSetupClickIssued = false; } catch (_) {} }
                  }
                } else {
                  const els = Array.from(document.querySelectorAll('button,a,[role=button]')).filter(visible);
                  const target = els.find(el => /إعداد تطبيق المصادقة|إعداد المصادقة|set up authenticator|set up authenticator app|setup authenticator/i.test(text(el)));
                  if (target) {
                    try { window.__emAuthenticatorSetupClickIssued = true; target.click(); return 'clicked'; } catch (_) { try { window.__emAuthenticatorSetupClickIssued = false; } catch (_) {} }
                  }
                }
              }
              const body = ((document.body && document.body.innerText) || '').replace(/\s+/g,' ');
              if (/QR|رمز QR|مسح رمز مصادقة/i.test(body)) {
                window.__emAuthenticatorSetupClickIssued = true;
                return 'qr';
              }
              return 'wait';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (!isAuthenticatorRun(view, removalToken) ||
                authenticatorAutomationStage != "open_setup") return@evaluateJavascript
            when (result?.trim('"')) {
                "trash_clicked" -> {
                    // Issue the trash click only once, then give Google's dialog
                    // enough time to animate/open before checking it.
                    authenticatorAutomationTrashClickIssued = true
                    authenticatorAutomationRemovalFlow = true
                    authenticatorAutomationStage = "remove_authenticator_confirm"
                    view.postDelayed({ if (isAuthenticatorRun(view, removalToken)) injectAuthenticatorAutomation(view) }, 700L)
                }
                "remove_confirm" -> {
                    authenticatorAutomationRemovalFlow = true
                    authenticatorAutomationStage = "remove_authenticator_confirm"
                    view.postDelayed({ if (isAuthenticatorRun(view, removalToken)) injectAuthenticatorAutomation(view) }, 450L)
                }
                "clicked" -> {
                    authenticatorAutomationSetupClickIssued = true
                    authenticatorAutomationStage = "qr"
                    view.postDelayed({ if (isAuthenticatorRun(view, removalToken)) injectAuthenticatorAutomation(view) }, 2000L)
                }
                "qr" -> {
                    authenticatorAutomationStage = "qr"
                    view.postDelayed({ if (isAuthenticatorRun(view, removalToken)) injectAuthenticatorAutomation(view) }, 1500L)
                }
                else -> view.postDelayed({ if (isAuthenticatorRun(view, removalToken)) injectAuthenticatorAutomation(view) }, 700L)
            }
        }
    }

    private fun clickAuthenticatorRemoveAnyway(view: WebView) {
        val removalToken = authenticatorAutomationRemovalToken
        if (!canDriveAuthenticator(view, removalToken)) return
        val script = """
            (function() {
              const norm = s => ((s || '') + '').replace(/\s+/g,' ').trim().toLowerCase();
              const token = ${JSONObject.quote(removalToken)};
              const issued = (key, kotlinIssued) => {
                if (kotlinIssued || window[key] === token) return true;
                try { return sessionStorage.getItem(key) === token; } catch (_) { return false; }
              };
              const visible = el => {
                if (!el) return false;
                const r = el.getBoundingClientRect();
                if (r.width <= 1 || r.height <= 1) return false;
                for (let node = el; node; node = node.parentElement) {
                  const s = getComputedStyle(node);
                  if (node.hidden || node.getAttribute('aria-hidden') === 'true' || s.display === 'none' ||
                      s.visibility === 'hidden' || s.visibility === 'collapse' || Number(s.opacity) === 0) return false;
                }
                return true;
              };
              const pageText = norm(document.body && document.body.innerText);
              const dialogSelector = '[role="dialog"],dialog,[aria-modal="true"]';
              const dialogs = Array.from(document.querySelectorAll(dialogSelector)).filter(visible);
              const confirmationOpen = dialogs.length > 0;
              const removedNotice = /authenticator app (?:has been )?removed|google authenticator (?:has been )?removed/i.test(pageText);
              const setupVisible = Array.from(document.querySelectorAll('button,a,[role=button]'))
                .filter(visible)
                .some(el => /^(set up authenticator|set up authenticator app|إعداد تطبيق المصادقة|إعداد المصادقة|إعداد تطبيق أداة المصادقة)$/i.test(norm(el.innerText || el.textContent || el.getAttribute('aria-label') || '')));
              const removalAttempted = issued('__emAuthenticatorRemoveOkIssued', ${authenticatorAutomationRemoveOkClickIssued}) ||
                issued('__emAuthenticatorRemoveAnywayIssued', ${authenticatorAutomationRemoveAnywayClickIssued});
              if (!confirmationOpen && (removedNotice || (removalAttempted && setupVisible))) {
                window.__emAuthenticatorSetupClickIssued = false;
                window.__emAuthenticatorLastFilledCodeStep = undefined;
                return 'already_removed';
              }
              for (const dialog of dialogs) {
                const walker = document.createTreeWalker(dialog, NodeFilter.SHOW_TEXT);
                const words = [];
                while (walker.nextNode()) {
                  const parent = walker.currentNode.parentElement;
                  if (parent && parent.closest(dialogSelector) === dialog && visible(parent)) words.push(walker.currentNode.nodeValue);
                }
                const dialogText = norm(words.join(' ') + ' ' + (dialog.getAttribute('aria-label') || ''));
                const isRemoveDialog = /\bremove authenticator app\s*\?/i.test(dialogText);
                const isWarning = /you may lose access to your account/i.test(dialogText);
                if (!isRemoveDialog && !isWarning) continue;
                const buttons = Array.from(dialog.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit]'))
                  .filter(el => el.closest(dialogSelector) === dialog && visible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true');
                const label = el => norm(el.innerText || el.value || el.getAttribute('aria-label') || '');
                const ok = isRemoveDialog && buttons.find(el => label(el) === 'ok');
                const removeAnyway = buttons.find(el => /^(remove anyway|إزالة على أي حال|إزالة على أية حال|متابعة الإزالة)$/i.test(label(el)));
                const target = ok || removeAnyway;
                const key = ok ? '__emAuthenticatorRemoveOkIssued' : '__emAuthenticatorRemoveAnywayIssued';
                const kotlinIssued = ok ? ${authenticatorAutomationRemoveOkClickIssued} : ${authenticatorAutomationRemoveAnywayClickIssued};
                if (!target || issued(key, kotlinIssued)) return 'wait';
                window[key] = token;
                try { sessionStorage.setItem(key, token); } catch (_) {}
                try { target.click(); return ok ? 'ok_clicked' : 'remove_anyway_clicked'; } catch (_) {
                  delete window[key];
                  try { sessionStorage.removeItem(key); } catch (_) {}
                  return 'wait';
                }
              }
              return 'wait';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (!isAuthenticatorRun(view, removalToken) ||
                authenticatorAutomationStage != "remove_authenticator_confirm") return@evaluateJavascript
            when (result?.trim('"')) {
                "remove_anyway_clicked", "ok_clicked" -> {
                    if (result?.trim('"') == "ok_clicked") authenticatorAutomationRemoveOkClickIssued = true
                    else authenticatorAutomationRemoveAnywayClickIssued = true
                    view.postDelayed({ if (isAuthenticatorRun(view, removalToken)) injectAuthenticatorAutomation(view) }, 700L)
                }
                "already_removed" -> {
                    // Only an observed removal outcome permits the new setup flow.
                    authenticatorAutomationSetupClickIssued = false
                    authenticatorAutomationQrScanned = false
                    authenticatorAutomationQrScanInFlight = false
                    authenticatorAutomationCodeSubmitted = false
                    authenticatorAutomationTurnOnClicked = false
                    authenticatorAutomationFinalTurnOnClicked = false
                    authenticatorAutomationFinalRefreshDone = false
                    authenticatorAutomationSuccessSeen = false
                    authenticatorAutomationStage = "open_setup"
                    view.postDelayed({ if (isAuthenticatorRun(view, removalToken)) injectAuthenticatorAutomation(view) }, 3000L)
                }
                else -> view.postDelayed({ if (isAuthenticatorRun(view, removalToken)) injectAuthenticatorAutomation(view) }, 1200L)
            }
        }
    }

    private fun clickAuthenticatorNext(view: WebView) {
        val runToken = authenticatorAutomationRemovalToken
        if (!canDriveAuthenticator(view, runToken)) return
        val script = """
            (function() {
              const visible = el => !!el && el.offsetParent !== null;
              const text = el => ((el.innerText || el.value || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '') + '').replace(/\s+/g,' ').trim().toLowerCase();
              const els = Array.from(document.querySelectorAll('button,a,input[type=submit],[role=button]')).filter(visible);
              const target = els.find(el => /^(التالي|next|continue|متابعة)$/i.test(text(el)) || /^(التالي|next|continue|متابعة)\\b/i.test(text(el)));
              if (target && !target.disabled) { target.click(); return 'clicked'; }
              const body = ((document.body && document.body.innerText) || '').replace(/\s+/g,' ');
              if (/إدخال الرمز|ادخل الرمز|enter the 6-digit|enter the code|6 digits/i.test(body)) return 'code';
              return 'wait';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (!isAuthenticatorRun(view, runToken) || authenticatorAutomationStage != "qr") return@evaluateJavascript
            when (result?.trim('"')) {
                "clicked" -> {
                    authenticatorAutomationStage = "code"
                    view.postDelayed({ if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view) }, 1200L)
                }
                "code" -> {
                    authenticatorAutomationStage = "code"
                    view.postDelayed({ if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view) }, 700L)
                }
                else -> view.postDelayed({ if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view) }, 700L)
            }
        }
    }

    private fun fillAndSubmitAuthenticatorCode(view: WebView) {
        val runToken = authenticatorAutomationRemovalToken
        if (!canDriveAuthenticator(view, runToken)) return
        val nowSeconds = System.currentTimeMillis() / 1000L
        val period = authenticatorPeriod.coerceAtLeast(1L)
        val codeStep = nowSeconds / period
        val code = runCatching {
            generateTotp(authenticatorSecret, System.currentTimeMillis(), authenticatorAlgorithm, authenticatorDigits, authenticatorPeriod)
        }.getOrNull() ?: return
        val codeJson = JSONObject.quote(code)
        val stepJson = codeStep.toString()
        val script = """
            (function() {
              if (location.protocol !== 'https:' || !['accounts.google.com', 'myaccount.google.com'].includes(location.hostname) ||
                  (location.port && location.port !== '443')) return 'wait';
              const code = $codeJson;
              const codeStep = $stepJson;
              // The verification code is allowed to be filled automatically ONCE per
              // TOTP period (normally 30 seconds). If the user deletes it manually,
              // do not put the same code back. A new fill is allowed only after the
              // TOTP period changes and Google has produced the next code.
              const lastFilledStep = window.__emAuthenticatorLastFilledCodeStep;
              if (lastFilledStep === codeStep) return 'same_code_wait';
              const visible = el => !!el && el.offsetParent !== null;
              const inputs = Array.from(document.querySelectorAll('input')).filter(visible);
              if (inputs.some(el => el.id === 'backupCodePin' ||
                  (el.getAttribute('aria-label') || '').trim().toLowerCase() === 'enter a backup code')) return 'wait';
              const candidates = inputs.filter(el => {
                const t = ((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('name') || '') + ' ' + (el.type || '')).toLowerCase();
                return /code|رمز|verification|otp|totp|authenticator/.test(t) || el.maxLength === 6;
              });
              const input = candidates[0] || inputs.find(el => el.type !== 'hidden');
              if (!input) return 'wait';
              // Do not overwrite anything the user has already entered. Treat the
              // current TOTP period as handled too, so deleting manual input does not
              // cause this same period to be auto-filled later.
              if ((input.value || '').trim() !== '') {
                window.__emAuthenticatorLastFilledCodeStep = codeStep;
                return 'user_input';
              }
              // Mark this TOTP time-step only after confirming that the field is empty.
              // This is the key guard that makes manual deletion safe until the next
              // 30-second code is generated.
              window.__emAuthenticatorLastFilledCodeStep = codeStep;
              const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set;
              if (setter) setter.call(input, code); else input.value = code;
              input.dispatchEvent(new Event('input',{bubbles:true}));
              input.dispatchEvent(new Event('change',{bubbles:true}));
              const buttons = Array.from(document.querySelectorAll('button,input[type=submit],[role=button]')).filter(visible);
              const text = el => ((el.innerText || el.value || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '') + '').replace(/\s+/g,' ').trim().toLowerCase();
              const target = buttons.find(el => /^(تأكيد|التالي|next|confirm|continue|متابعة|verify)$/i.test(text(el))) || buttons.find(el => /تأكيد|confirm|verify|next|التالي/.test(text(el)));
              if (target && !target.disabled) { target.click(); return 'submitted'; }
              return 'filled';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (!isAuthenticatorRun(view, runToken) || authenticatorAutomationStage != "code") return@evaluateJavascript
            when (result?.trim('"')) {
                "submitted" -> {
                    authenticatorAutomationCodeSubmitted = true
                    authenticatorAutomationStage = "turn_on"
                    view.postDelayed({ if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view) }, 300L)
                }
                "filled" -> {
                    // Keep the code stage alive. If the user deletes this code, the
                    // next checks see the same TOTP time-step and leave the field empty.
                    // When the 30-second period changes, the new step is accepted.
                    view.postDelayed({ if (isAuthenticatorRun(view, runToken)) fillAndSubmitAuthenticatorCode(view) }, 700L)
                }
                "same_code_wait", "user_input" -> {
                    // Same code period: never overwrite the user's field. Wait for the
                    // next TOTP period instead of writing the same code again.
                    view.postDelayed({ if (isAuthenticatorRun(view, runToken)) fillAndSubmitAuthenticatorCode(view) }, 700L)
                }
                else -> view.postDelayed({ if (isAuthenticatorRun(view, runToken)) fillAndSubmitAuthenticatorCode(view) }, 700L)
            }
        }
    }

    private fun clickAuthenticatorTurnOn(view: WebView) {
        val runToken = authenticatorAutomationRemovalToken
        if (!canDriveAuthenticator(view, runToken)) return
        val script = """
            (function() {
              const visible = el => !!el && el.offsetParent !== null;
              const text = el => ((el.innerText || el.value || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '') + '').replace(/\s+/g,' ').trim().toLowerCase();
              const els = Array.from(document.querySelectorAll('button,a,input[type=submit],[role=button]')).filter(visible);
              const target = els.find(el => /^(turn on|تشغيل ميزة التحقق بخطوتين|تفعيل ميزة التحقق بخطوتين|تفعيل التحقق بخطوتين|تفعيل المصادقة الثنائية)$/i.test(text(el))) ||
                             els.find(el => /(turn on|تفعيل ميزة التحقق بخطوتين|تشغيل ميزة التحقق بخطوتين|تفعيل التحقق بخطوتين|تفعيل المصادقة الثنائية)/i.test(text(el)) && !/(turn off|إيقاف|إيقاف التحقق)/i.test(text(el)));
              if (target && !target.disabled) { target.click(); return 'clicked'; }
              const body = ((document.body && document.body.innerText) || '').replace(/\s+/g,' ');
              if (/تخطي|skip|لاحقًا|not now|إلغاء|cancel|رجوع|back/i.test(body) && /التحقق بخطوتين|2-step verification|two-step verification/i.test(body)) return 'final';
              return 'wait';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (!isAuthenticatorRun(view, runToken) || authenticatorAutomationStage != "turn_on") return@evaluateJavascript
            when (result?.trim('"')) {
                "clicked" -> {
                    authenticatorAutomationTurnOnClicked = true
                    authenticatorAutomationStage = "waiting_success"
                    view.postDelayed({ if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view) }, 300L)
                }
                "final" -> {
                    // If Google is already on the post-authenticator page, treat
                    // this as a transition to the Authenticator-specific success poll.
                    authenticatorAutomationStage = "waiting_success"
                    view.postDelayed({ if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view) }, 250L)
                }
                else -> view.postDelayed({ if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view) }, 300L)
            }
        }
    }

    private fun clickAuthenticatorFinalTurnOn(view: WebView) {
        val runToken = authenticatorAutomationRemovalToken
        if (!canDriveAuthenticator(view, runToken)) return
        val script = """
            (function() {
              const visible = el => !!el && el.offsetParent !== null;
              const text = el => ((el.innerText || el.value || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '') + '').replace(/\s+/g,' ').trim().toLowerCase();
              const body = ((document.body && document.body.innerText) || '').replace(/\s+/g,' ').trim();
              try { window.scrollTo({top: document.documentElement.scrollHeight || document.body.scrollHeight, behavior: 'instant'}); } catch(e) { try { window.scrollTo(0, document.body.scrollHeight); } catch(_) {} }
              const els = Array.from(document.querySelectorAll('button,a,input[type=submit],[role=button]')).filter(visible);
              const candidates = els.filter(el => {
                  const t = text(el);
                  return /(turn on|تفعيل ميزة التحقق بخطوتين|تشغيل ميزة التحقق بخطوتين|تفعيل التحقق بخطوتين|تفعيل المصادقة الثنائية|تفعيل المصادقة)/i.test(t) &&
                         !/(turn off|إيقاف|إزالة|remove|delete)/i.test(t);
              });
              const target = candidates[0];
              if (target && !target.disabled) {
                  try { target.scrollIntoView({block:'center', behavior:'instant'}); } catch(e) {}
                  target.click();
                  return 'clicked';
              }
              // If Google already moved to the final confirmation state, let the
              // success poller detect it instead of clicking an unrelated control.
              if (/(2-step verification is on|two-step verification is on|تم تفعيل التحقق بخطوتين|تم تفعيل المصادقة الثنائية|تم التفعيل بنجاح)/i.test(body)) return 'success';
              return 'wait';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (!isAuthenticatorRun(view, runToken) || authenticatorAutomationStage != "final_turn_on") return@evaluateJavascript
            when (result?.trim('"')) {
                "clicked", "success" -> {
                    if (result?.trim('"') == "clicked") {
                        authenticatorAutomationFinalTurnOnClicked = true
                    }
                    authenticatorAutomationStage = "waiting_success"
                    view.postDelayed({ if (isAuthenticatorRun(view, runToken)) injectAuthenticatorAutomation(view) }, 350L)
                }
                else -> view.postDelayed({ if (isAuthenticatorRun(view, runToken)) clickAuthenticatorFinalTurnOn(view) }, 300L)
            }
        }
    }

    /**
     * Generates a RFC 6238 TOTP code from a Base32 secret.
     * This is local-only: the secret never leaves the app.
     */
    private fun generateTotp(
        secret: String,
        timestampMillis: Long,
        algorithm: String = "SHA1",
        digits: Int = 6,
        period: Long = 30L
    ): String {
        require(digits == 6 || digits == 8) { "Unsupported TOTP digits" }
        require(period > 0L) { "Invalid TOTP period" }

        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
        val normalized = secret
            .replace("\\s".toRegex(), "")
            .replace("=", "")
            .uppercase(Locale.US)
        require(normalized.isNotEmpty()) { "Empty TOTP secret" }

        val bits = StringBuilder(normalized.length * 5)
        for (ch in normalized) {
            val value = alphabet.indexOf(ch)
            require(value >= 0) { "Invalid Base32 TOTP secret" }
            for (bit in 4 downTo 0) {
                bits.append(if ((value and (1 shl bit)) != 0) '1' else '0')
            }
        }
        val byteCount = bits.length / 8
        require(byteCount > 0) { "Invalid TOTP secret" }
        val key = ByteArray(byteCount)
        for (i in 0 until byteCount) {
            var value = 0
            for (bit in 0 until 8) {
                value = (value shl 1) or if (bits[i * 8 + bit] == '1') 1 else 0
            }
            key[i] = value.toByte()
        }

        val counter = timestampMillis / 1000L / period
        val data = ByteArray(8)
        var counterValue = counter
        for (i in 7 downTo 0) {
            data[i] = (counterValue and 0xFFL).toByte()
            counterValue = counterValue ushr 8
        }

        val macAlgorithm = when (algorithm.uppercase(Locale.US)) {
            "SHA256" -> "HmacSHA256"
            "SHA512" -> "HmacSHA512"
            else -> "HmacSHA1"
        }
        val mac = Mac.getInstance(macAlgorithm)
        mac.init(SecretKeySpec(key, macAlgorithm))
        val hash = mac.doFinal(data)
        val offset = hash[hash.lastIndex].toInt() and 0x0F
        val binary = ((hash[offset].toInt() and 0x7F) shl 24) or
            ((hash[offset + 1].toInt() and 0xFF) shl 16) or
            ((hash[offset + 2].toInt() and 0xFF) shl 8) or
            (hash[offset + 3].toInt() and 0xFF)
        val modulus = if (digits == 8) 100_000_000 else 1_000_000
        val otp = binary % modulus
        return otp.toString().padStart(digits, '0')
    }

    /**
     * Decode the QR that Google renders inside the WebView.
     *
     * A single WebView.draw() + one ZXing pass is not reliable on some Android
     * devices: the QR can be rendered at a small scale, anti-aliased, or with
     * a different luminance distribution than the rest of the page.  The old
     * implementation therefore worked on some screens and reported "no QR" on
     * others even though the QR was visibly present.
     *
     * We now use several inexpensive decode passes: full page, a centered crop,
     * 2x upscaled versions, and both Hybrid/Global binarizers.  We also first ask
     * the page DOM whether Google has exposed an otpauth:// payload directly.
     * No coordinates are hard-coded, so this keeps working if Google moves the QR.
     */
    private fun waitForAuthenticatorQrReady(view: WebView, onReady: (Boolean) -> Unit) {
        val script = """
            (function() {
              const visible = el => {
                if (!el) return false;
                const r = el.getBoundingClientRect();
                const s = getComputedStyle(el);
                return r.width > 80 && r.height > 80 && r.width < window.innerWidth * 0.98 && r.height < window.innerHeight * 0.98 &&
                       s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0 &&
                       r.right > 0 && r.bottom > 0 && r.left < window.innerWidth && r.top < window.innerHeight;
              };
              const media = Array.from(document.querySelectorAll('canvas,img,svg')).some(el => {
                if (!visible(el)) return false;
                const r = el.getBoundingClientRect();
                return Math.max(r.width,r.height) / Math.max(1,Math.min(r.width,r.height)) < 1.45;
              });
              const body = ((document.body && document.body.innerText) || '').replace(/\s+/g,' ').toLowerCase();
              const qrWords = /scan a qr code|set up authenticator app|choose scan a qr code|رمز qr|تطبيق المصادقة/.test(body);
              return media && qrWords ? 'ready' : 'wait';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (result?.trim('"') == "ready") {
                onReady(true)
            } else {
                onReady(false)
            }
        }
    }

    private fun scanQrFromCurrentPage(view: WebView, canContinue: () -> Boolean = { true }, onDecoded: (String?) -> Unit) {
        view.post {
            var callbackCalled = false
            fun finish(value: String?) {
                if (callbackCalled) return
                callbackCalled = true
                onDecoded(value)
            }
            if (!canContinue()) {
                finish(null)
                return@post
            }

            // IMPORTANT: never trust an arbitrary "otpauth://" string found in
            // Google's HTML. The page can contain stale/hidden values that are
            // not the QR currently shown to the user. Decode the QR that is
            // actually rendered on screen first, then use DOM data only as a
            // fallback when it belongs to a visible QR element.
            try {
                val width = view.width.coerceAtLeast(1)
                val height = view.height.coerceAtLeast(1)
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                view.draw(canvas)

                val hints = mapOf(
                    DecodeHintType.TRY_HARDER to true,
                    DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
                    DecodeHintType.CHARACTER_SET to "UTF-8"
                )

                fun decodeOne(sourceBitmap: Bitmap, pure: Boolean = false): String? {
                    if (sourceBitmap.width < 40 || sourceBitmap.height < 40) return null
                    val pixels = IntArray(sourceBitmap.width * sourceBitmap.height)
                    sourceBitmap.getPixels(pixels, 0, sourceBitmap.width, 0, 0, sourceBitmap.width, sourceBitmap.height)
                    val source = RGBLuminanceSource(sourceBitmap.width, sourceBitmap.height, pixels)
                    val localHints = if (pure) hints + (DecodeHintType.PURE_BARCODE to true) else hints
                    val readers = listOf(
                        BinaryBitmap(com.google.zxing.common.HybridBinarizer(source)),
                        BinaryBitmap(com.google.zxing.common.GlobalHistogramBinarizer(source))
                    )
                    for (bb in readers) {
                        val value = runCatching {
                            MultiFormatReader().apply { setHints(localHints) }.decodeWithState(bb).text
                        }.getOrNull()
                        if (!value.isNullOrBlank()) return value
                    }
                    return null
                }

                fun tryBitmap(candidate: Bitmap): String? {
                    decodeOne(candidate)?.let { return it }
                    val scaled = Bitmap.createScaledBitmap(candidate, candidate.width * 2, candidate.height * 2, false)
                    try {
                        decodeOne(scaled)?.let { return it }
                        decodeOne(scaled, pure = true)?.let { return it }
                    } finally {
                        scaled.recycle()
                    }
                    return null
                }

                // First pass: the complete visible page. This is deliberately
                // before any DOM extraction so the returned secret comes from
                // the QR the user can actually see.
                tryBitmap(bitmap)?.let {
                    bitmap.recycle()
                    finish(it)
                    return@post
                }

                // Ask the page only for geometry of visible, square-ish media
                // elements. We then crop those exact on-screen regions from the
                // WebView bitmap. This handles Google's canvas/img QR without
                // trusting hidden/stale otpauth strings in the HTML.
                val candidateScript = """
                    (function() {
                      try {
                        const vw = Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1);
                        const vh = Math.max(1, window.innerHeight || document.documentElement.clientHeight || 1);
                        const out = [];
                        const els = Array.from(document.querySelectorAll('canvas,img,svg'));
                        for (const el of els) {
                          const r = el.getBoundingClientRect();
                          const style = getComputedStyle(el);
                          const w = r.width, h = r.height;
                          if (w < 80 || h < 80 || w > vw * 0.98 || h > vh * 0.98) continue;
                          if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity || 1) === 0) continue;
                          if (r.right <= 0 || r.bottom <= 0 || r.left >= vw || r.top >= vh) continue;
                          const ratio = Math.max(w, h) / Math.max(1, Math.min(w, h));
                          if (ratio > 1.45) continue;
                          out.push({left:r.left, top:r.top, width:w, height:h, area:w*h});
                        }
                        out.sort((a,b) => b.area - a.area);
                        return JSON.stringify({vw:vw, vh:vh, items:out.slice(0, 12)});
                      } catch (_) { return '[]'; }
                    })();
                """.trimIndent()

                view.evaluateJavascript(candidateScript) { raw ->
                    if (!canContinue()) {
                        if (!bitmap.isRecycled) bitmap.recycle()
                        finish(null)
                        return@evaluateJavascript
                    }
                    try {
                        val jsonText = raw?.let { decodeJsString(it) }.orEmpty()
                        val root = JSONObject(jsonText)
                        val candidates = root.optJSONArray("items") ?: JSONArray()
                        val cssWidth = root.optDouble("vw", view.width.toDouble()).coerceAtLeast(1.0)
                        val cssHeight = root.optDouble("vh", view.height.toDouble()).coerceAtLeast(1.0)
                        val scaleX = width.toFloat() / cssWidth.toFloat()
                        val scaleY = height.toFloat() / cssHeight.toFloat()
                        for (i in 0 until candidates.length()) {
                            val item = candidates.optJSONObject(i) ?: continue
                            val left = (item.optDouble("left") * scaleX).toInt()
                            val top = (item.optDouble("top") * scaleY).toInt()
                            val cw = (item.optDouble("width") * scaleX).toInt()
                            val ch = (item.optDouble("height") * scaleY).toInt()
                            if (cw <= 0 || ch <= 0) continue
                            val pad = (maxOf(cw, ch) * 0.12f).toInt().coerceAtLeast(12)
                            val l = (left - pad).coerceAtLeast(0)
                            val t = (top - pad).coerceAtLeast(0)
                            val r = (left + cw + pad).coerceAtMost(bitmap.width)
                            val b = (top + ch + pad).coerceAtMost(bitmap.height)
                            if (r <= l || b <= t) continue
                            val crop = Bitmap.createBitmap(bitmap, l, t, r - l, b - t)
                            try {
                                tryBitmap(crop)?.let {
                                    crop.recycle()
                                    bitmap.recycle()
                                    finish(it)
                                    return@evaluateJavascript
                                }
                            } finally {
                                if (!crop.isRecycled) crop.recycle()
                            }
                        }

                        // Last visual pass: a centered crop is useful when the
                        // QR is painted into a non-media container.
                        val left = (width * 0.10f).toInt().coerceAtLeast(0)
                        val top = (height * 0.08f).toInt().coerceAtLeast(0)
                        val right = (width * 0.90f).toInt().coerceAtMost(width)
                        val bottom = (height * 0.92f).toInt().coerceAtMost(height)
                        if (right > left && bottom > top) {
                            val crop = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
                            try {
                                tryBitmap(crop)?.let {
                                    crop.recycle()
                                    bitmap.recycle()
                                    finish(it)
                                    return@evaluateJavascript
                                }
                            } finally {
                                if (!crop.isRecycled) crop.recycle()
                            }
                        }

                        bitmap.recycle()
                        finish(null)
                    } catch (_: Throwable) {
                        if (!bitmap.isRecycled) bitmap.recycle()
                        finish(null)
                    }
                }
            } catch (_: Throwable) {
                finish(null)
            }
        }
    }

    private fun decodeJsString(raw: String): String {
        return runCatching {
            val value = org.json.JSONTokener(raw).nextValue()
            if (value is String) value else raw.trim('"')
        }.getOrElse { raw.trim('"')
            .replace("\\/", "/")
            .replace("\\u003d", "=")
            .replace("\\u0026", "&")
            .replace("\\u003A", ":")
            .replace("\\u003a", ":")
            .replace("\\u002F", "/")
            .replace("\\u002f", "/")
        }
    }


    private fun injectRecoveryEmailRemovalScript(view: WebView) {
        if (googleVerificationActive || googleVerificationCheckPending) return
        if (!recoveryEmailAutomationActive) return
        val script = """
            (function() {
              const visible = el => !!el && el.offsetParent !== null;
              const normalize = s => (s || '').replace(/\\s+/g, ' ').trim();
              const lower = s => normalize(s).toLowerCase();
              const attrs = el => [el?.getAttribute('aria-label'), el?.getAttribute('data-tooltip'), el?.getAttribute('title')]
                .filter(Boolean).join(' ').replace(/\\s+/g, ' ').trim();
              const recoveryHeaderRe = /البريد الإلكتروني المخصص لاسترداد الحساب|عنوان البريد الإلكتروني المخصص لاسترداد الحساب|recovery email/i;
              const addRecoveryRe = /إضافة بريد إلكتروني لاسترداد الحساب|add a recovery email|add recovery email/i;
              const deleteLabelRe = /^(حذف|delete|remove|إزالة)$/i;
              const successRe = /تمت إزالة البريد الإلكتروني المخصص لاسترداد الحساب|تم حذف البريد الإلكتروني المخصص لاسترداد الحساب|تمت إزالة بريد الاسترداد|تم حذف بريد الاسترداد|recovery email.*(?:removed|deleted)|recovery.*email.*(?:removed|deleted)/i;

              // 1) The dedicated Recovery Email page is opened directly by Kotlin.
              // If the email is already absent, report that only when Google explicitly
              // renders the "Add recovery email" action.
              const bodyText = normalize(document.body?.innerText || '');
              const isRecoveryPage = location.href.includes('/recovery/email') ||
                                     (recoveryHeaderRe.test(bodyText) && !location.href.includes('/security'));

              // 2) Confirmation dialog after pressing the trash icon.
              const dialogs = Array.from(document.querySelectorAll('[role="dialog"], [aria-modal="true"]')).filter(visible);
              for (const dialog of dialogs) {
                const confirm = Array.from(dialog.querySelectorAll('button,[role="button"],a'))
                  .filter(visible)
                  .find(el => deleteLabelRe.test(normalize(el.innerText || el.textContent || '')) || deleteLabelRe.test(attrs(el)));
                if (confirm) {
                  confirm.click();
                  return 'delete_confirmed';
                }
              }

              if (isRecoveryPage) {
                // Do not click the trash icon again after the confirmation flow has begun.
                const controls = Array.from(document.querySelectorAll('button,[role="button"],a,input[type="button"],input[type="submit"]')).filter(visible);
                const trash = controls.find(el => {
                  const a = lower(attrs(el));
                  const icon = lower(el.querySelector('svg')?.getAttribute('aria-label') || '');
                  const data = lower(el.getAttribute('data-tooltip-id') || '');
                  return /trash|delete|remove|حذف|إزالة|سلة|مهملات/.test(a) ||
                         /trash|delete|remove|حذف|إزالة|سلة|مهملات/.test(icon) ||
                         /trash|delete|remove/.test(data);
                });
                if (trash && !%s) {
                  trash.click();
                  return 'trash_clicked';
                }

                if (addRecoveryRe.test(bodyText)) return 'not_present';
                return 'waiting';
              }

              return 'waiting';
            })();
        """.trimIndent().format(if (recoveryTrashClicked) "true" else "false")

        if (recoveryRemovalAwaitingVerification) {
            verifyRecoveryRemoval(view)
            return
        }
        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "trash_clicked" -> {
                    recoveryTrashClicked = true
                    view.postDelayed({ if (recoveryEmailAutomationActive) injectRecoveryEmailRemovalScript(view) }, 250L)
                }
                "delete_confirmed" -> {
                    recoveryRemovalAwaitingVerification = true
                    view.postDelayed({ if (recoveryRemovalAwaitingVerification) verifyRecoveryRemoval(view) }, 250L)
                }
                "not_present" -> {
                    // Google explicitly shows the "Add recovery email" action, which
                    // means there is no recovery email configured. In that case there
                    // is nothing to delete, so Recovery is considered satisfied and
                    // the combined flow may continue directly to Password.
                    finishRecoveryStage(view, recoveryWasAlreadyAbsent = true)
                }
                "waiting" -> {
                    view.postDelayed({ if (recoveryEmailAutomationActive) injectRecoveryEmailRemovalScript(view) }, 250L)
                }
            }
        }
    }

    private fun verifyRecoveryRemoval(view: WebView) {
        if (!recoveryRemovalAwaitingVerification) return
        val script = """
            (function() {
              const visible = el => !!el && el.offsetParent !== null;
              const normalize = s => (s || '').replace(/\\s+/g, ' ').trim();
              const bodyText = normalize(document.body?.innerText || '');
              const recoveryHeaderRe = /البريد الإلكتروني المخصص لاسترداد الحساب|عنوان البريد الإلكتروني المخصص لاسترداد الحساب|recovery email/i;
              const addRecoveryRe = /إضافة بريد إلكتروني لاسترداد الحساب|add a recovery email|add recovery email/i;
              const successRe = /تمت إزالة البريد الإلكتروني المخصص لاسترداد الحساب|تم حذف البريد الإلكتروني المخصص لاسترداد الحساب|تمت إزالة بريد الاسترداد|تم حذف بريد الاسترداد|recovery email.*(?:removed|deleted)|recovery.*email.*(?:removed|deleted)/i;

              // This must be Google's dedicated Recovery Email destination, not the
              // Security & sign-in page. The screenshot shows the Recovery Email header
              // together with the Add Recovery Email action after deletion.
              const isRecoveryDestination =
                    (location.href.includes('/recovery/email') || recoveryHeaderRe.test(bodyText)) &&
                    !location.href.includes('/security');

              // Google may render the success message in a snackbar/alert that is
              // not part of the main page text. Check the whole visible document and
              // live/alert regions as well. The success notification itself is the
              // authoritative signal that the deletion completed.
              const liveText = Array.from(document.querySelectorAll('[role="alert"],[role="status"],[aria-live],.snackbar,.toast'))
                .filter(visible)
                .map(el => normalize(el.innerText || el.textContent || el.getAttribute('aria-label') || ''))
                .join(' ');
              const hasSuccessNotification = successRe.test(bodyText) || successRe.test(liveText);

              // Once Google shows the deletion confirmation, move immediately to
              // Password. Do not require the Add Recovery Email button because the
              // snackbar can appear while Google is still finishing its navigation.
              if (isRecoveryDestination && hasSuccessNotification) return 'success_seen';

              // No recovery email: this is the only case where we may continue without
              // a deletion notification. Google must explicitly show the add-recovery
              // action on the dedicated Recovery Email page.
              const hasAddButton = Array.from(document.querySelectorAll('button,a,[role="button"],[role="link"]'))
                .filter(visible)
                .some(el => addRecoveryRe.test(normalize(el.innerText || el.textContent || el.getAttribute('aria-label') || '')));
              if (isRecoveryDestination && hasAddButton) return 'destination_only';
              return 'waiting';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "removed_confirmed" -> {
                    recoverySuccessNotificationSeen = true
                    finishRecoveryStage(view)
                }
                "success_seen" -> {
                    // This is the exact hand-off point: Google's deletion notification
                    // has appeared. Stop Recovery immediately and start Password.
                    recoverySuccessNotificationSeen = true
                    finishRecoveryStage(view)
                }
                "destination_only" -> {
                    // Explicitly no recovery email exists. This is the only successful
                    // no-email path and does not require a deletion snackbar.
                    finishRecoveryStage(view, recoveryWasAlreadyAbsent = true)
                }
                else -> {
                    view.postDelayed({ if (recoveryRemovalAwaitingVerification) verifyRecoveryRemoval(view) }, 500L)
                }
            }
        }
    }

    private fun finishRecoveryStage(view: WebView, recoveryWasAlreadyAbsent: Boolean = false) {
        recoveryRemovalAwaitingVerification = false
        recoveryEmailPageOpened = false
        recoveryTrashClicked = false
        recoverySuccessNotificationSeen = false
        recoveryEmailAutomationActive = false

        combinedAutomationWaitingForPassword = false
        // Recovery hands off to Creation Time when that final stage is enabled.
        startNextConfiguredStage(view, "recovery", extraDelay = if (recoveryWasAlreadyAbsent) 150L else 220L)
    }

    private fun startCreationTimeAutomation(view: WebView) {
        if (!automationMasterEnabled || !creationTimeAutomationEnabled || creationTimeAutomationActive || automationActivityStopped || view !== currentWebView()) return
        creationTimeAutomationGeneration++
        creationTimeAutomationActive = true
        creationTimeAutomationProbeInFlight = false
        creationTimeAutomationWaitStartedAt = android.os.SystemClock.elapsedRealtime()
        creationTimeAutomationCompletionPending = false
        val generation = creationTimeAutomationGeneration
        view.loadUrl(withSelectedLanguage(CREATION_TIME_URL))
        view.postDelayed({ if (generation == creationTimeAutomationGeneration) injectCreationTimeAutomation(view) }, CREATION_TIME_PROBE_INTERVAL_MS)
    }

    private fun stopCreationTimeAutomation() {
        creationTimeAutomationGeneration++
        creationTimeAutomationActive = false
        creationTimeAutomationProbeInFlight = false
        creationTimeAutomationWaitStartedAt = 0L
        creationTimeAutomationCompletionPending = false
    }

    private fun finishCreationTimeAutomation(view: WebView, account: String = "", year: String = "") {
        if (!creationTimeAutomationActive) return
        if (account.isNotBlank() && year.matches(Regex("(?:19|20)\\d{2}"))) {
            val normalizedAccount = account.trim().lowercase(Locale.US)
            accountKeyByWebView[view] = normalizedAccount
            if (view === currentWebView()) currentAccountKey = normalizedAccount
            saveAccountCreationTime(normalizedAccount, year)
            markStageCompleted("creation_time", view, normalizedAccount)
        }
        stopCreationTimeAutomation()
        if (automationMasterEnabled && !automationCompletedForCurrentAccount) {
            startNextConfiguredStage(view, "creation_time", immediate = true, accountOverride = account)
        }
    }

    private fun finishCreationTimeWithoutYear(view: WebView, generation: Long) {
        val account = accountKeyByWebView[view].orEmpty().trim().lowercase(Locale.US)
        if (account.isBlank() || view !== currentWebView()) {
            finishCreationTimeAutomation(view)
            return
        }
        creationTimeAutomationProbeInFlight = true
        val script = """
            (function() {
              if (location.protocol !== 'https:' || location.hostname !== 'myactivity.google.com' ||
                  location.pathname !== '/product/youtube/controls' || document.readyState !== 'complete' || !document.body) return '';
              const text = (document.body.innerText || '').toLowerCase();
              if (!text || /verify your identity|sign in|something went wrong|page isn't available/.test(text)) return '';
              return 'ready';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (generation != creationTimeAutomationGeneration || !creationTimeAutomationActive || view !== currentWebView() ||
                accountKeyByWebView[view].orEmpty().trim().lowercase(Locale.US) != account) return@evaluateJavascript
            creationTimeAutomationProbeInFlight = false
            val url = android.net.Uri.parse(view.url.orEmpty())
            if (result?.trim('"') != "ready" || url.scheme != "https" || url.host != "myactivity.google.com" ||
                url.path != "/product/youtube/controls") {
                finishCreationTimeAutomation(view)
                return@evaluateJavascript
            }
            val accounts = loadAuthenticatorAccounts()
            val existing = (0 until accounts.length()).mapNotNull { accounts.optJSONObject(it) }
                .firstOrNull { it.optString("account").equals(account, true) }
                ?.let { accountCreationTime(it) }.orEmpty()
            finishCreationTimeAutomation(view, account, existing.takeIf { it.matches(Regex("(?:19|20)\\d{2}")) } ?: "2023")
        }
    }

    private fun injectCreationTimeAutomation(view: WebView) {
        if (!creationTimeAutomationEnabled || !creationTimeAutomationActive ||
            creationTimeAutomationProbeInFlight || creationTimeAutomationCompletionPending) return
        val generation = creationTimeAutomationGeneration
        if (!view.url.orEmpty().contains("myactivity.google.com/product/youtube/controls")) {
            val waitStartedAt = creationTimeAutomationWaitStartedAt
            if (waitStartedAt > 0L) {
                val elapsed = android.os.SystemClock.elapsedRealtime() - waitStartedAt
                if (elapsed >= CREATION_TIME_DETECTION_TIMEOUT_MS) {
                    finishCreationTimeAutomation(view)
                } else {
                    val remaining = CREATION_TIME_DETECTION_TIMEOUT_MS - elapsed
                    view.postDelayed({ if (generation == creationTimeAutomationGeneration) injectCreationTimeAutomation(view) }, minOf(CREATION_TIME_PROBE_INTERVAL_MS, remaining))
                }
            }
            return
        }
        val waitStartedAt = creationTimeAutomationWaitStartedAt.takeIf { it > 0L }
            ?: android.os.SystemClock.elapsedRealtime().also { creationTimeAutomationWaitStartedAt = it }
        val elapsed = android.os.SystemClock.elapsedRealtime() - waitStartedAt
        if (elapsed >= CREATION_TIME_DETECTION_TIMEOUT_MS) {
            finishCreationTimeWithoutYear(view, generation)
            return
        }

        creationTimeAutomationProbeInFlight = true
        val script = """
            (function() {
              const elements = Array.from(document.querySelectorAll('div.D1Yuzf'));
              const dated = elements.filter(element => /\b(?:on|off) since\s+(?:january|february|march|april|may|june|july|august|september|october|november|december)\s+(?:\d{1,2},?\s+)?(?:19|20)\d{2}\b/i.test((element.innerText || '').replace(/\s+/g, ' ')));
              if (dated.some(element => /when you created your account/i.test((element.closest('.UZRuue') || element).innerText || ''))) return 'found';
              return dated.length ? 'candidate' : '';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (generation != creationTimeAutomationGeneration || !creationTimeAutomationActive || creationTimeAutomationCompletionPending) return@evaluateJavascript
            creationTimeAutomationProbeInFlight = false
            val probeCompletedAt = android.os.SystemClock.elapsedRealtime()
            val status = result?.trim('"').orEmpty()
            if ((status == "found" || (status == "candidate" && probeCompletedAt - waitStartedAt >= 2_000L)) &&
                probeCompletedAt - waitStartedAt <= CREATION_TIME_DETECTION_TIMEOUT_MS) {
                creationTimeAutomationCompletionPending = true
                view.postDelayed({ if (generation == creationTimeAutomationGeneration) extractCreationTime(view) }, CREATION_TIME_SETTLE_DELAY_MS)
            } else {
                val currentElapsed = android.os.SystemClock.elapsedRealtime() - waitStartedAt
                if (currentElapsed >= CREATION_TIME_DETECTION_TIMEOUT_MS) {
                    finishCreationTimeWithoutYear(view, generation)
                } else {
                    val remaining = CREATION_TIME_DETECTION_TIMEOUT_MS - currentElapsed
                    view.postDelayed({ if (generation == creationTimeAutomationGeneration) injectCreationTimeAutomation(view) }, minOf(CREATION_TIME_PROBE_INTERVAL_MS, remaining))
                }
            }
        }
    }

    private fun extractCreationTime(view: WebView) {
        if (!creationTimeAutomationEnabled || !creationTimeAutomationActive ||
            !creationTimeAutomationCompletionPending) return
        val generation = creationTimeAutomationGeneration
        if (!view.url.orEmpty().contains("myactivity.google.com/product/youtube/controls")) {
            finishCreationTimeAutomation(view)
            return
        }
        val script = """
            (function() {
              const elements = Array.from(document.querySelectorAll('div.D1Yuzf'));
              const creationLabel = element => /when you created your account/i.test((element.closest('.UZRuue') || element).innerText || '');
              elements.sort((a, b) => Number(creationLabel(b)) - Number(creationLabel(a)));
              for (const element of elements) {
                const text = (element.innerText || '').replace(/\s+/g, ' ').trim();
                const match = text.match(/\b(?:on|off) since\s+(january|february|march|april|may|june|july|august|september|october|november|december)\s+(?:\d{1,2},?\s+)?((?:19|20)\d{2})\b/i);
                if (match) {
                  return match[2];
                }
              }
              return '';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (generation != creationTimeAutomationGeneration || !creationTimeAutomationActive) return@evaluateJavascript
            if (!view.url.orEmpty().contains("myactivity.google.com/product/youtube/controls")) {
                finishCreationTimeAutomation(view)
                return@evaluateJavascript
            }
            val year = result?.trim('"').orEmpty()
            if (!year.matches(Regex("(?:19|20)\\d{2}"))) {
                creationTimeAutomationCompletionPending = false
                injectCreationTimeAutomation(view)
                return@evaluateJavascript
            }
            val account = accountKeyByWebView[view].orEmpty()
            if (account.isNotBlank()) {
                finishCreationTimeAutomation(view, account, year)
            } else {
                detectGoogleAccountKey(view) { detectedAccount ->
                    if (generation != creationTimeAutomationGeneration || !creationTimeAutomationActive) return@detectGoogleAccountKey
                    if (!view.url.orEmpty().contains("myactivity.google.com/product/youtube/controls")) {
                        finishCreationTimeAutomation(view)
                        return@detectGoogleAccountKey
                    }
                    finishCreationTimeAutomation(view, detectedAccount, year)
                }
            }
        }
    }

    private fun startDevicesAutomation(view: WebView) {
        if (!automationMasterEnabled || !devicesAutomationEnabled || devicesAutomationActive ||
            automationActivityStopped || view !== currentWebView() || tabs.none { it.webView === view }) return
        devicesAutomationActive = true
        devicesAutomationView = view
        devicesAutomationAccount = ""
        devicesAutomationGeneration++
        devicesAutomationDocumentGeneration = 0L
        devicesAutomationStartedUrl = view.url.orEmpty()
        devicesAutomationDocumentOrigin = null
        devicesAutomationPreviousDocumentOrigin = null
        devicesAutomationCommitted = false
        devicesAutomationFinishedAt = 0L
        devicesAutomationReadyAt = 0L
        devicesAutomationFailed = false
        devicesAutomationScheduledDocument = 0L
        devicesAutomationAccountNoticeShown = false
        devicesAutomationAwaitingVerification = false
        devicesAutomationVerificationNoticeShown = false
        devicesAutomationInitialPending = true
        devicesAutomationInitialReadyAt = 0L
        devicesAutomationInitialReadyOrigin = 0.0
        recoveryTargetForRun = ""
        recoverySaveIssued = false
        recoveryDoneIssued = false
        recoveryDoneAcknowledged = false
        recoveryActionPending = false
        recoveryFinishProbeInFlight = false
        recoveryTargetNoticeShown = false
        // The preflight is passive; invalidate any shared verification probe
        // that was queued before this stage took ownership.
        googleVerificationGeneration++
        googleVerificationProbeInFlight = false
        googleVerificationActive = false
        googleVerificationCheckPending = false
        googleVerificationSubmitIssued = false
        googleVerificationNoticeShown = false
        pollDevicesInitialNavigation(view, devicesAutomationGeneration)
        scheduleDevicesWatchdog(view)
    }

    private fun pollDevicesInitialNavigation(view: WebView, generation: Long) {
        fun current(): Boolean = devicesAutomationActive && devicesAutomationEnabled && automationMasterEnabled &&
            devicesAutomationInitialPending && devicesAutomationView === view && generation == devicesAutomationGeneration &&
            !devicesAutomationFailed && isSecurityStageOwner(view) && tabs.any { it.webView === view }
        fun retry() { view.postDelayed({ pollDevicesInitialNavigation(view, generation) }, 700L) }
        if (!current()) return
        if (automationActivityStopped || devicesAutomationPaused || view !== currentWebView()) {
            devicesAutomationInitialReadyAt = 0L
            retry()
            return
        }
        val url = view.url.orEmpty()
        val uri = runCatching { android.net.Uri.parse(url) }.getOrNull()
        if (!uri?.scheme.equals("https", true) || uri?.port !in listOf(-1, 443) ||
            uri?.host?.lowercase(Locale.US) !in setOf("accounts.google.com", "myaccount.google.com", "myactivity.google.com",
                "mail.google.com", "google.com", "www.google.com", "youtube.com", "www.youtube.com", "m.youtube.com")) {
            failDevicesDocument(view, devicesAutomationStartedUrl)
            return
        }
        val document = devicesPageDocuments[view]
        if (document == null || !document.committed || !document.finished || document.url != url) {
            devicesAutomationInitialReadyAt = 0L
            retry()
            return
        }
        val revision = document.revision
        val documentGeneration = devicesAutomationDocumentGeneration
        val script = """
            (function() {
              if (location.href !== ${JSONObject.quote(url)} || document.readyState !== 'complete') return 'waiting';
              if (location.protocol !== 'https:' || (location.port && location.port !== '443') ||
                  !['accounts.google.com','myaccount.google.com','myactivity.google.com','mail.google.com',
                    'google.com','www.google.com','youtube.com','www.youtube.com','m.youtube.com'].includes(location.hostname)) return 'waiting';
              const visible = el => {
                if (!el) return false;
                const r = el.getBoundingClientRect();
                if (r.width <= 0 || r.height <= 0) return false;
                for (let node = el; node; node = node.parentElement) {
                  const s = getComputedStyle(node);
                  if (node.hidden || s.display === 'none' || s.visibility === 'hidden' || s.visibility === 'collapse' ||
                      s.contentVisibility === 'hidden' || Number(s.opacity) === 0) return false;
                }
                return true;
              };
              if (!visible(document.body) || !(document.body.innerText || '').trim()) return 'waiting';
              const challengeInput = el => {
                if (!visible(el)) return false;
                const hint = [el.id, el.name, el.autocomplete, el.getAttribute('aria-label'), el.placeholder].join(' ');
                return el.type === 'password' || (location.hostname === 'accounts.google.com' &&
                  (el.type === 'email' || /\b(?:username|code|pin|idvPin|smsUserPin)\b/i.test(hint))) ||
                  /identifierId|\bidentifier\b|totpPin|backupCodePin|one-time-code|\botp\b|enter (?:a |the |your )?(?:verification |backup )?code|رمز التحقق|رمز احتياطي/i.test(hint);
              };
              if (Array.from(document.querySelectorAll('input')).some(challengeInput) ||
                  Array.from(document.querySelectorAll('iframe[src*="recaptcha"],iframe[src*="captcha"]')).some(visible)) return 'challenge';
              const prompt = /verify it[’'‘]?s you|confirm it[’'‘]?s you|verify your identity|verify your account|complete (?:the )?verification|sign in to (?:continue|your google account)|enter your password|enter (?:a |the |your )?(?:verification |backup )?code|check your phone|tap yes on your phone|use your (?:google )?authenticator|تحقق من هويتك|للتمكن من المتابعة.*تحقق|أدخل (?:رمز|كلمة المرور)/i;
              const nodes = Array.from(document.querySelectorAll('h1,h2,h3,[role="heading"],p,label,div,span'));
              if (nodes.some(el => visible(el) && (el.children.length === 0 || el.matches('h1,h2,h3,[role="heading"],p,label')) &&
                  prompt.test(el.innerText || ''))) return 'challenge';
              if (location.hostname === 'accounts.google.com' && nodes.some(el => visible(el) &&
                  el.matches('h1,h2,h3,[role="heading"]') && /^(?:sign in|choose an account|use your google account|2.step verification|choose how (?:you want )?to sign in|تسجيل الدخول|اختيار حساب)$/i.test((el.innerText || '').trim()))) return 'challenge';
              if (location.hostname === 'accounts.google.com' && nodes.some(el => visible(el) &&
                  /^(?:just a sec|checking (?:your )?info|signing in|please wait)[.!…]*$/i.test((el.innerText || '').trim()))) return 'waiting';
              return 'ready:' + String(performance.timeOrigin || 0);
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (!current()) return@evaluateJavascript
            if (automationActivityStopped || devicesAutomationPaused || view !== currentWebView() ||
                devicesPageDocuments[view] !== document || document.revision != revision || !document.committed || !document.finished ||
                documentGeneration != devicesAutomationDocumentGeneration || document.url != url || view.url.orEmpty() != url) {
                devicesAutomationInitialReadyAt = 0L
                retry()
                return@evaluateJavascript
            }
            val status = result?.trim('"').orEmpty()
            if (status == "challenge") noteDevicesVerification(view)
            val origin = status.removePrefix("ready:").toDoubleOrNull()
            if (!status.startsWith("ready:") || origin == null || origin <= 0.0) {
                devicesAutomationInitialReadyAt = 0L
                retry()
                return@evaluateJavascript
            }
            val now = android.os.SystemClock.elapsedRealtime()
            if (devicesAutomationInitialReadyAt == 0L || devicesAutomationInitialReadyOrigin != origin) {
                devicesAutomationInitialReadyAt = now
                devicesAutomationInitialReadyOrigin = origin
                retry()
                return@evaluateJavascript
            }
            if (now - devicesAutomationInitialReadyAt < 700L) {
                retry()
                return@evaluateJavascript
            }
            detectGoogleAccountKey(view, true) { detected ->
                if (!current() || view.url.orEmpty() != url || view !== currentWebView() ||
                    devicesPageDocuments[view] !== document || document.revision != revision ||
                    documentGeneration != devicesAutomationDocumentGeneration) return@detectGoogleAccountKey
                if (automationActivityStopped || devicesAutomationPaused) {
                    devicesAutomationInitialReadyAt = 0L
                    retry()
                    return@detectGoogleAccountKey
                }
                val account = detected.trim().lowercase(Locale.US)
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(account).matches()) {
                    if (!devicesAutomationAccountNoticeShown) {
                        devicesAutomationAccountNoticeShown = true
                        Snackbar.make(drawerLayout, "Recovery is waiting to identify the Google account", Snackbar.LENGTH_LONG).show()
                    }
                    retry()
                    return@detectGoogleAccountKey
                }
                if (devicesAutomationAccount.isNotBlank() && !devicesAutomationAccount.equals(account, true)) {
                    cancelSecurityAutomationForView(view)
                    Snackbar.make(drawerLayout, "Automation stopped: Google account changed", Snackbar.LENGTH_LONG).show()
                    return@detectGoogleAccountKey
                }
                if (completedStagesByAccount[account]?.contains("recovery_set") == true) {
                    accountKeyByWebView[view] = account
                    currentAccountKey = account
                    stopDevicesAutomation()
                    startNextConfiguredStage(view, "recovery_set", immediate = true, accountOverride = account)
                    return@detectGoogleAccountKey
                }
                val target = recoveryTargetForAccount(account)
                devicesAutomationAccount = account
                accountKeyByWebView[view] = account
                currentAccountKey = account
                recoveryTargetForRun = if (android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches() && !target.equals(account, true)) target else ""
                devicesAutomationAwaitingVerification = false
                devicesAutomationVerificationNoticeShown = false
                devicesAutomationDocumentOrigin = origin
                devicesAutomationInitialPending = false
                view.loadUrl(DEVICES_URL)
            }
        }
    }

    private fun stopDevicesAutomation() {
        recoveryActionPermit = ""
        devicesAutomationGeneration++
        devicesAutomationActive = false
        devicesAutomationView = null
        devicesAutomationAccount = ""
        devicesAutomationStartedUrl = ""
        devicesAutomationDocumentOrigin = null
        devicesAutomationPreviousDocumentOrigin = null
        devicesAutomationCommitted = false
        devicesAutomationFinishedAt = 0L
        devicesAutomationReadyAt = 0L
        devicesAutomationFailed = false
        devicesAutomationScheduledDocument = 0L
        devicesAutomationAccountNoticeShown = false
        devicesAutomationAwaitingVerification = false
        devicesAutomationVerificationNoticeShown = false
        devicesAutomationInitialPending = false
        devicesAutomationInitialReadyAt = 0L
        devicesAutomationInitialReadyOrigin = 0.0
        recoveryTargetForRun = ""
        recoverySaveIssued = false
        recoveryDoneIssued = false
        recoveryDoneAcknowledged = false
        recoveryActionPending = false
        recoveryFinishProbeInFlight = false
        recoveryTargetNoticeShown = false
    }

    private fun isDevicesDestination(url: String): Boolean {
        val uri = runCatching { android.net.Uri.parse(url) }.getOrNull() ?: return false
        return uri.scheme.equals("https", true) && uri.host.equals("myaccount.google.com", true) &&
            uri.port in listOf(-1, 443) && uri.path?.trimEnd('/') == "/collection/recoveryemail"
    }

    private fun finishRecoverySet(view: WebView) {
        if (!devicesAutomationActive || devicesAutomationView !== view || !recoveryDoneAcknowledged ||
            !automationMasterEnabled || !devicesAutomationEnabled || automationActivityStopped || devicesAutomationPaused ||
            view !== currentWebView() || googleVerificationActive || googleVerificationCheckPending || recoveryFinishProbeInFlight) return
        val account = devicesAutomationAccount
        if (account.isBlank() || recoveryTargetForAccount(account) != recoveryTargetForRun) return
        val run = devicesAutomationGeneration
        val document = devicesAutomationDocumentGeneration
        val pageUrl = view.url.orEmpty()
        recoveryFinishProbeInFlight = true
        detectGoogleAccountKey(view, true) { detected ->
            if (!devicesAutomationActive || devicesAutomationView !== view || run != devicesAutomationGeneration ||
                document != devicesAutomationDocumentGeneration || view.url.orEmpty() != pageUrl) return@detectGoogleAccountKey
            recoveryFinishProbeInFlight = false
            if (!automationMasterEnabled || !devicesAutomationEnabled || automationActivityStopped || devicesAutomationPaused ||
                view !== currentWebView() || googleVerificationActive || googleVerificationCheckPending ||
                recoveryTargetForAccount(account) != recoveryTargetForRun) return@detectGoogleAccountKey
            if (detected.isBlank()) {
                if (!devicesAutomationAccountNoticeShown) {
                    devicesAutomationAccountNoticeShown = true
                    Snackbar.make(drawerLayout, "Recovery is waiting to identify the Google account", Snackbar.LENGTH_LONG).show()
                }
                view.postDelayed({ finishRecoverySet(view) }, 700L)
                return@detectGoogleAccountKey
            }
            if (!detected.equals(account, true)) {
                cancelSecurityAutomationForView(view)
                Snackbar.make(drawerLayout, "Automation stopped: Google account changed", Snackbar.LENGTH_LONG).show()
                return@detectGoogleAccountKey
            }
            updateSavedAccountRecovery(recoveryTargetForRun, account)
            markStageCompleted("recovery_set", view, account)
            stopDevicesAutomation()
            Snackbar.make(drawerLayout, "Recovery step completed", Snackbar.LENGTH_SHORT).show()
            startNextConfiguredStage(view, "recovery_set", accountOverride = account)
        }
    }

    private fun failDevicesDocument(view: WebView, url: String?) {
        if (devicesAutomationActive && devicesAutomationView === view && url == devicesAutomationStartedUrl && !devicesAutomationFailed) {
            devicesAutomationFailed = true
            devicesAutomationReadyAt = 0L
            Snackbar.make(drawerLayout, "Recovery could not load safely. Pull down to retry, or turn Recovery off.", Snackbar.LENGTH_LONG).show()
        }
    }

    private fun noteDevicesVerification(view: WebView) {
        if (!devicesAutomationActive || devicesAutomationView !== view) return
        recoveryActionPermit = ""
        devicesAutomationAwaitingVerification = true
        devicesAutomationReadyAt = 0L
        if (!devicesAutomationVerificationNoticeShown) {
            devicesAutomationVerificationNoticeShown = true
            Snackbar.make(drawerLayout, "Complete Google verification to continue Recovery", Snackbar.LENGTH_LONG).show()
        }
    }

    private fun scheduleDevicesWatchdog(view: WebView) {
        val run = devicesAutomationGeneration
        val document = devicesAutomationDocumentGeneration
        lateinit var watchdog: Runnable
        watchdog = Runnable {
            if (!devicesAutomationActive || devicesAutomationView !== view || run != devicesAutomationGeneration ||
                document != devicesAutomationDocumentGeneration || devicesAutomationFailed) return@Runnable
            if (automationActivityStopped || devicesAutomationPaused || view !== currentWebView() || devicesAutomationInitialPending || devicesAutomationAwaitingVerification) {
                view.postDelayed(watchdog, 30_000L)
            } else if (devicesAutomationReadyAt == 0L) {
                failDevicesDocument(view, devicesAutomationStartedUrl)
            }
        }
        view.postDelayed(watchdog, 30_000L)
    }

    private fun scheduleDevicesAutomation(view: WebView) {
        if (!devicesAutomationActive || devicesAutomationView !== view || devicesAutomationFailed || devicesAutomationInitialPending ||
            !devicesAutomationCommitted || devicesAutomationFinishedAt == 0L ||
            !isDevicesDestination(devicesAutomationStartedUrl) || view.url != devicesAutomationStartedUrl ||
            devicesAutomationScheduledDocument == devicesAutomationDocumentGeneration) return
        val generation = devicesAutomationGeneration
        val documentGeneration = devicesAutomationDocumentGeneration
        val url = devicesAutomationStartedUrl
        devicesAutomationScheduledDocument = documentGeneration
        view.post { pollDevicesAutomation(view, generation, documentGeneration, url) }
    }

    private fun pollDevicesAutomation(view: WebView, generation: Long, documentGeneration: Long, url: String) {
        fun current(): Boolean = devicesAutomationActive && devicesAutomationEnabled && automationMasterEnabled &&
            devicesAutomationView === view && generation == devicesAutomationGeneration &&
            documentGeneration == devicesAutomationDocumentGeneration && devicesAutomationStartedUrl == url &&
            devicesAutomationCommitted && devicesAutomationFinishedAt > 0L && !devicesAutomationFailed && !devicesAutomationInitialPending &&
            view.url == url && isDevicesDestination(url) && isSecurityStageOwner(view) && tabs.any { it.webView === view }
        fun retry() { view.postDelayed({ pollDevicesAutomation(view, generation, documentGeneration, url) }, 500L) }
        if (!current()) return
        if (automationActivityStopped || devicesAutomationPaused || view !== currentWebView() || googleVerificationActive || googleVerificationCheckPending) {
            devicesAutomationReadyAt = 0L
            retry()
            return
        }
        val script = """
            (function() {
              if (location.href !== ${JSONObject.quote(url)} || document.readyState !== 'complete') return 'waiting';
              if (${devicesAutomationPreviousDocumentOrigin ?: 0.0} > 0 && performance.timeOrigin === ${devicesAutomationPreviousDocumentOrigin ?: 0.0}) return 'waiting';
              const visible = el => {
                const r = el.getBoundingClientRect(), s = getComputedStyle(el);
                return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
              };
              const body = (document.body?.innerText || '').replace(/\s+/g, ' ').trim();
              if (/this site can.t be reached|no internet|failed to load|couldn.t load|something went wrong|service unavailable/i.test(body)) return 'failed';
              if (/to continue,? first verify it.?s you|verify it.?s you|confirm it.?s you|verify your identity|verify your account|complete (?:the )?verification|sign in to (?:continue|your google account)|checking your browser|unusual traffic|i.m not a robot|تحقق من هويتك|للتمكن من المتابعة.*تحقق/i.test(body) ||
                  Array.from(document.querySelectorAll('input[type="password"],iframe[src*="recaptcha"],iframe[src*="captcha"]')).some(visible)) return 'verification';
              if (!body) return 'waiting';
              return 'ready:' + String(performance.timeOrigin || 0);
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (!current()) return@evaluateJavascript
            val status = result?.trim('"').orEmpty()
            if (automationActivityStopped || devicesAutomationPaused || view !== currentWebView() || googleVerificationActive || googleVerificationCheckPending) {
                devicesAutomationReadyAt = 0L
                retry()
                return@evaluateJavascript
            }
            if (status == "failed") {
                failDevicesDocument(view, url)
                return@evaluateJavascript
            }
            if (status == "verification") noteDevicesVerification(view)
            val origin = status.removePrefix("ready:").toDoubleOrNull()
            if (!status.startsWith("ready:") || origin == null || origin <= 0.0) {
                devicesAutomationReadyAt = 0L
                retry()
                return@evaluateJavascript
            }
            devicesAutomationDocumentOrigin = origin
            devicesAutomationAwaitingVerification = false
            devicesAutomationVerificationNoticeShown = false
            val now = android.os.SystemClock.elapsedRealtime()
            if (devicesAutomationReadyAt == 0L) devicesAutomationReadyAt = now
            val remaining = AUTOMATION_STAGE_GAP_MS - (now - maxOf(devicesAutomationFinishedAt, devicesAutomationReadyAt))
            if (remaining > 0L) {
                view.postDelayed({ pollDevicesAutomation(view, generation, documentGeneration, url) }, minOf(500L, remaining))
                return@evaluateJavascript
            }
            val detectedAccount = accountKeyByWebView[view].orEmpty().trim().lowercase(Locale.US)
            if (devicesAutomationAccount.isNotBlank() && detectedAccount.isNotBlank() &&
                !devicesAutomationAccount.equals(detectedAccount, true)) {
                cancelSecurityAutomationForView(view)
                Snackbar.make(drawerLayout, "Automation stopped: Google account changed", Snackbar.LENGTH_LONG).show()
                return@evaluateJavascript
            }
            val account = devicesAutomationAccount.ifBlank { detectedAccount }
            if (account.isBlank()) {
                if (!devicesAutomationAccountNoticeShown) {
                    devicesAutomationAccountNoticeShown = true
                    Snackbar.make(drawerLayout, "Recovery is waiting for the Google account to be identified", Snackbar.LENGTH_LONG).show()
                }
                detectGoogleAccountKey(view) { detected ->
                    if (!current()) return@detectGoogleAccountKey
                    val key = detected.trim().lowercase(Locale.US)
                    if (view === currentWebView() && !automationActivityStopped && !devicesAutomationPaused &&
                        !googleVerificationActive && !googleVerificationCheckPending &&
                        android.util.Patterns.EMAIL_ADDRESS.matcher(key).matches()) {
                        accountKeyByWebView[view] = key
                        currentAccountKey = key
                    }
                    retry()
                }
                return@evaluateJavascript
            }
            if (recoveryTargetForRun.isBlank()) {
                val target = recoveryTargetForAccount(account)
                if (android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches() && !target.equals(account, true)) {
                    recoveryTargetForRun = target
                    recoveryTargetNoticeShown = false
                } else {
                    if (!recoveryTargetNoticeShown) {
                        recoveryTargetNoticeShown = true
                        Snackbar.make(drawerLayout, "Recovery is waiting for an email in Password settings", Snackbar.LENGTH_LONG).show()
                    }
                    retry()
                    return@evaluateJavascript
                }
            }
            if (recoveryTargetForAccount(account) != recoveryTargetForRun) {
                failDevicesDocument(view, url)
                return@evaluateJavascript
            }
            if (recoveryDoneAcknowledged) {
                finishRecoverySet(view)
                return@evaluateJavascript
            }
            if (recoveryActionPending || recoveryDoneIssued) {
                retry()
                return@evaluateJavascript
            }
            val actionScript = """
                (function() {
                  if (window.top !== window || location.href !== ${JSONObject.quote(url)} ||
                      location.origin !== 'https://myaccount.google.com' ||
                      location.pathname.replace(/\/$/, '') !== '/collection/recoveryemail' ||
                      document.readyState !== 'complete' || (document.visibilityState && document.visibilityState !== 'visible') ||
                      performance.timeOrigin !== ${devicesAutomationDocumentOrigin ?: 0.0}) return 'waiting';
                  const target = ${JSONObject.quote(recoveryTargetForRun)};
                  const account = ${JSONObject.quote(account)}.toLowerCase();
                  const command = __EM_COMMAND__;
                  const permitted = () => {
                    try { return !!window.EMRecoveryGuard && window.EMRecoveryGuard.permitted(__EM_TOKEN__) === true; }
                    catch (_) { return false; }
                  };
                  if (!permitted()) return 'waiting';
                  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(target)) return 'waiting';
                  const visible = el => {
                    if (!el || !el.isConnected) return false;
                    const r = el.getBoundingClientRect();
                    if (r.width <= 0 || r.height <= 0) return false;
                    for (let n = el; n; n = n.parentElement) {
                      const s = getComputedStyle(n);
                      if (n.hidden || s.display === 'none' || s.visibility === 'hidden' ||
                          s.visibility === 'collapse' || Number(s.opacity) === 0) return false;
                    }
                    return true;
                  };
                  const enabled = el => visible(el) && !el.disabled && !el.matches(':disabled') && el.getAttribute('aria-disabled') !== 'true';
                  const text = el => (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
                  let state = window.__emRecoveryCollectionState;
                  if (!state || state.run !== ${generation}) state = window.__emRecoveryCollectionState = {run: ${generation}, field: null, manual: false, writing: false, owned: false};
                  const body = document.body?.innerText || '';
                  if (/verify it[’'‘]?s you|confirm it[’'‘]?s you|verify your identity|verify your account|checking your browser|unusual traffic|i.m not a robot|تحقق من هويتك/i.test(body) ||
                      Array.from(document.querySelectorAll('input[type="password"],iframe[src*="recaptcha"],iframe[src*="captcha"]')).some(visible)) return 'verification';
                  const identities = new Set();
                  for (const el of document.querySelectorAll('#profileIdentifier,[aria-label],[title]')) {
                    if (!visible(el)) continue;
                    const label = [el.getAttribute('aria-label'), el.getAttribute('title')].filter(Boolean).join(' ');
                    const value = el.id === 'profileIdentifier' ? (el.innerText || el.textContent || '') :
                      (/google account|حساب google/i.test(label) ? label : '');
                    for (const email of value.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig) || []) identities.add(email.toLowerCase());
                  }
                  if (identities.size === 1 && identities.has(account)) state.accountVerified = true;
                  else if (identities.size === 1) return 'account_mismatch';
                  else if (!(identities.size === 0 && state.accountVerified && state.saveClicked &&
                      (command === 'check_done' || command === 'done'))) return 'account_unverified';
                  const fields = Array.from(document.querySelectorAll('input')).filter(el => visible(el) &&
                    el.id === 'i2' && el.type === 'email' && (el.getAttribute('aria-label') || '').trim().toLowerCase() === 'your recovery email');
                  if (command === 'prepare' || command === 'save') {
                    if (fields.length !== 1 || !enabled(fields[0]) || fields[0].readOnly) return 'waiting';
                    const field = fields[0];
                    if (state.field !== field) {
                      if (state.field && state.field.isConnected) return 'waiting';
                      if (field.value && field.value !== target) state.manual = true;
                      else if (field.value === target) state.owned = true;
                      state.field = field;
                      field.addEventListener('input', () => { if (state.field === field && !state.writing) state.manual = true; });
                    }
                    if (state.owned && field.value !== target) state.manual = true;
                    if (state.manual) return 'manual';
                    if (!field.value && command === 'prepare') {
                      if (!permitted()) return 'waiting';
                      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
                      state.writing = true;
                      try {
                        state.owned = true;
                        if (setter) setter.call(field, target); else field.value = target;
                        field.dispatchEvent(new Event('input', {bubbles:true}));
                        field.dispatchEvent(new Event('change', {bubbles:true}));
                      } finally { state.writing = false; }
                      return 'filled';
                    }
                    if (!state.owned || field.value !== target) return 'manual';
                    const form = field.closest('form');
                    if (!form) return 'waiting';
                    const buttons = Array.from(form.querySelectorAll('button')).filter(el => enabled(el) && el.type === 'submit' && text(el) === 'Save');
                    if (buttons.length !== 1) return 'waiting';
                    if (command === 'prepare') return 'ready_save';
                    if (state.saveClicked) return 'waiting';
                    if (!permitted()) return 'waiting';
                    state.saveClicked = true;
                    buttons[0].click();
                    return 'save_clicked';
                  }
                  if (fields.length) return 'waiting';
                  const displayedEmails = Array.from(document.querySelectorAll('[data-recovery-email],[aria-label],p,span,div')).filter(visible)
                    .flatMap(el => {
                      const data = el.getAttribute('data-recovery-email') || '';
                      const label = el.getAttribute('aria-label') || '';
                      const content = el.matches('p') || el.children.length === 0 ? (el.innerText || '') : '';
                      const evidence = data || (/recovery email/i.test(label + ' ' + content) ? label + ' ' + content : '');
                      return evidence.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig) || [];
                    }).map(value => value.toLowerCase()).filter(value => value !== account);
                  if (displayedEmails.length && !displayedEmails.includes(target.toLowerCase())) return 'unexpected_target';
                  const buttons = Array.from(document.querySelectorAll('button')).filter(el => enabled(el) && text(el) === 'Done');
                  if (buttons.length !== 1) return 'waiting';
                  if (command === 'check_done') return 'ready_done';
                  if (command !== 'done' || state.doneClicked) return 'waiting';
                  if (!permitted()) return 'waiting';
                  state.doneClicked = true;
                  buttons[0].click();
                  return 'done_clicked';
                })();
            """.trimIndent()
            fun execute(command: String, onResult: (String) -> Unit) {
                recoveryActionPending = true
                val permit = java.util.UUID.randomUUID().toString()
                recoveryActionPermit = permit
                val executable = actionScript.replace("__EM_COMMAND__", JSONObject.quote(command)).replace("__EM_TOKEN__", JSONObject.quote(permit))
                view.evaluateJavascript(executable) { actionResult ->
                    if (recoveryActionPermit == permit) recoveryActionPermit = ""
                    val value = actionResult?.trim('"').orEmpty()
                    val sameRun = devicesAutomationActive && devicesAutomationView === view && generation == devicesAutomationGeneration
                    if (sameRun) {
                        val definitelyNotClicked = value in setOf("waiting", "manual", "verification", "account_unverified", "account_mismatch", "unexpected_target")
                        if (command == "save" && definitelyNotClicked) recoverySaveIssued = false
                        if (command == "done" && definitelyNotClicked) recoveryDoneIssued = false
                        if (command == "done" && value == "done_clicked" && recoveryTargetForAccount(account) == recoveryTargetForRun) {
                            recoveryDoneAcknowledged = true
                        }
                    }
                    if (!current()) return@evaluateJavascript
                    recoveryActionPending = false
                    if (automationActivityStopped || devicesAutomationPaused || view !== currentWebView() ||
                        googleVerificationActive || googleVerificationCheckPending || recoveryTargetForAccount(account) != recoveryTargetForRun) {
                        retry()
                        return@evaluateJavascript
                    }
                    onResult(value)
                }
            }
            execute(if (recoverySaveIssued) "check_done" else "prepare") { action ->
                when (action) {
                    "ready_save" -> {
                        recoverySaveIssued = true
                        execute("save") { clicked ->
                            if (clicked != "save_clicked") recoverySaveIssued = false
                            retry()
                        }
                    }
                    "ready_done" -> {
                        recoveryDoneIssued = true
                        execute("done") { clicked ->
                            if (clicked == "done_clicked") finishRecoverySet(view) else {
                                recoveryDoneIssued = false
                                retry()
                            }
                        }
                    }
                    "manual" -> {
                        if (!recoveryTargetNoticeShown) {
                            recoveryTargetNoticeShown = true
                            Snackbar.make(drawerLayout, "Recovery field was edited; complete it manually", Snackbar.LENGTH_LONG).show()
                        }
                        retry()
                    }
                    "unexpected_target" -> {
                        if (!recoveryTargetNoticeShown) {
                            recoveryTargetNoticeShown = true
                            Snackbar.make(drawerLayout, "Recovery address does not match; review it on Google", Snackbar.LENGTH_LONG).show()
                        }
                        retry()
                    }
                    "verification" -> { noteDevicesVerification(view); retry() }
                    "account_mismatch" -> {
                        cancelSecurityAutomationForView(view)
                        Snackbar.make(drawerLayout, "Automation stopped: Google account changed", Snackbar.LENGTH_LONG).show()
                    }
                    "account_unverified" -> {
                        if (!devicesAutomationAccountNoticeShown) {
                            devicesAutomationAccountNoticeShown = true
                            Snackbar.make(drawerLayout, "Recovery is waiting to identify the Google account", Snackbar.LENGTH_LONG).show()
                        }
                        retry()
                    }
                    else -> retry()
                }
            }
        }
    }

    private fun startBackupAutomation(view: WebView) {
        if (!automationMasterEnabled || !backupAutomationEnabled || automationActivityStopped || backupAutomationView != null || view !== currentWebView()) return
        backupAutomationGeneration++
        backupAutomationView = view
        backupAutomationAccount = accountKeyForStages(view)
        backupAutomationDocumentGeneration = 0L
        backupAutomationProbeInFlight = false
        resetBackupAutomationCandidate()
        scheduleBackupAutomationProbe(view, backupAutomationGeneration, 0L)
    }

    private fun resetBackupAutomationCandidate() {
        backupAutomationCandidateAccount = ""
        backupAutomationCandidateCodes = emptyList()
        backupAutomationCandidateSince = 0L
    }

    private fun stopBackupAutomation() {
        suspendBackupAutomation()
        backupAutomationView = null
        backupAutomationAccount = ""
    }

    private fun suspendBackupAutomation() {
        recoveryActionPermit = ""
        val view = backupAutomationView
        backupAutomationRunnable?.let { view?.removeCallbacks(it) }
        backupAutomationRunnable = null
        backupAutomationGeneration++
        backupAutomationProbeInFlight = false
        resetBackupAutomationCandidate()
    }

    private fun cancelBackupAutomationForView(view: WebView) {
        if (backupAutomationView !== view) return
        stopBackupAutomation()
    }

    private fun isBackupAutomationCurrent(view: WebView, generation: Long): Boolean =
        automationMasterEnabled && backupAutomationEnabled && !automationActivityStopped && !devicesAutomationPaused && !isResettingBrowser && !isFinishing && !isDestroyed &&
            backupAutomationView === view && currentWebView() === view && backupAutomationGeneration == generation &&
            tabs.any { it.webView === view }

    private fun isBackupTwoStepConfirmed(view: WebView): Boolean {
        val account = backupAutomationAccount.trim().lowercase(Locale.US)
        val detected = accountKeyByWebView[view].orEmpty().trim().lowercase(Locale.US)
        return account.isNotBlank() && (detected.isBlank() || detected == account) &&
            completedStagesByAccount[account]?.contains("two_step") == true
    }

    private fun isBackupCodesUrl(url: String): Boolean {
        val uri = runCatching { android.net.Uri.parse(url) }.getOrNull() ?: return false
        return uri.scheme.equals("https", true) && uri.host.equals("myaccount.google.com", true) &&
            uri.port in listOf(-1, 443) && uri.path.orEmpty().matches(Regex("(?:/u/[0-9]+)?/two-step-verification/backup-codes/?"))
    }

    private fun scheduleBackupAutomationProbe(view: WebView, generation: Long, delay: Long) {
        if (!isBackupAutomationCurrent(view, generation)) return
        backupAutomationRunnable?.let { view.removeCallbacks(it) }
        val task = Runnable {
            backupAutomationRunnable = null
            probeBackupAutomation(view, generation)
        }
        backupAutomationRunnable = task
        view.postDelayed(task, delay)
    }

    private fun probeBackupAutomation(view: WebView, generation: Long) {
        if (!isBackupAutomationCurrent(view, generation)) return
        scheduleBackupAutomationProbe(view, generation, BACKUP_AUTOMATION_PROBE_INTERVAL_MS)
        if (googleVerificationActive || googleVerificationCheckPending) return
        if (!isBackupTwoStepConfirmed(view)) {
            resetBackupAutomationCandidate()
            return
        }
        if (!isBackupCodesUrl(view.url.orEmpty())) {
            resetBackupAutomationCandidate()
            probeBackupLink(view, generation)
            return
        }
        if (backupAutomationProbeInFlight) return
        backupAutomationProbeInFlight = true
        val documentGeneration = backupAutomationDocumentGeneration
        val permit = java.util.UUID.randomUUID().toString()
        recoveryActionPermit = permit
        val knownAccountJson = JSONObject.quote(backupAutomationAccount.ifBlank { accountKeyByWebView[view].orEmpty() }.trim().lowercase(Locale.US))
        val script = """
            (function() {
              const url = new URL(location.href);
              if (url.protocol !== 'https:' || url.hostname !== 'myaccount.google.com' ||
                  (url.port && url.port !== '443') || !/^(?:\/u\/\d+)?\/two-step-verification\/backup-codes\/?${'$'}/.test(url.pathname)) return null;
              if (window.top !== window || document.visibilityState !== 'visible' || document.readyState !== 'complete') return null;
              const visible = el => {
                if (!el || !el.getBoundingClientRect().width || !el.getBoundingClientRect().height) return false;
                for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
                  const style = getComputedStyle(node);
                  if (node.hidden || style.display === 'none' || style.visibility !== 'visible' || Number(style.opacity) === 0) return false;
                }
                return true;
              };
              const text = el => String(el.innerText || '').replace(/\s+/g, ' ').trim();
              const emailPattern = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig;
              const accountNodes = Array.from(document.querySelectorAll('[aria-label],[title]')).filter(el =>
                visible(el) && /google account/i.test((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '')));
              const avatarEmails = accountNodes.flatMap(el =>
                ((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '')).match(emailPattern) || []);
              for (const container of document.querySelectorAll('div.Hm1X5.JH1xTd')) {
                if (!visible(container)) continue;
                const printEmails = Array.from(container.querySelectorAll('.RElpNb .ELsSkc'))
                  .flatMap(el => (el.textContent || '').match(emailPattern) || []);
                const emails = Array.from(new Set([...avatarEmails, ...printEmails].map(value => value.toLowerCase())));
                if (emails.length !== 1) continue;
                const entries = Array.from(container.querySelectorAll('.SDMsce [dir="ltr"],table.Dtwgsb .ibJClf')).filter(visible);
                const codes = [];
                for (const entry of entries) {
                  const value = text(entry);
                  if (!/^[0-9]{4}(?:\s+)?[0-9]{4}${'$'}/.test(value)) continue;
                  const code = value.replace(/\s+/g, '');
                  if (!codes.includes(code)) codes.push(code);
                }
                const countMatch = text(container).match(/\b([0-9]{1,2})\s+backup codes? remaining\b/i);
                if (!codes.length || codes.length > 10 ||
                    (countMatch ? codes.length !== Number(countMatch[1]) : codes.length !== 10)) continue;
                return { url: location.href, account: emails[0], codes: codes,
                         avatarConfirmed: avatarEmails.some(value => value.toLowerCase() === emails[0]) };
              }
              // Only create codes for a clearly identified current account, once per document.
              const accounts = Array.from(new Set(avatarEmails.map(value => value.toLowerCase())));
              const knownAccount = $knownAccountJson;
              if (accounts.length !== 1 || !knownAccount || knownAccount !== accounts[0] || window.__emBackupGetIssued) return null;
              const containers = Array.from(document.querySelectorAll('div.Hm1X5.JH1xTd')).filter(visible);
              if (containers.some(container => Array.from(container.querySelectorAll('.SDMsce [dir="ltr"],table.Dtwgsb .ibJClf')).some(visible))) return null;
              const buttons = Array.from(document.querySelectorAll('div.Hm1X5.JH1xTd button.AeBiU-LgbsSe[jsname="Pr7Yme"]'))
                .filter(el => visible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true' && text(el) === 'Get backup codes');
              if (buttons.length === 1) {
                try { if (!window.EMRecoveryGuard || window.EMRecoveryGuard.permitted(${JSONObject.quote(permit)}) !== true) return null; }
                catch (_) { return null; }
                window.__emBackupGetIssued = true;
                buttons[0].click();
              }
              return null;
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            val permitValid = recoveryActionPermit == permit
            if (permitValid) recoveryActionPermit = ""
            if (!isBackupAutomationCurrent(view, generation) || backupAutomationDocumentGeneration != documentGeneration) return@evaluateJavascript
            backupAutomationProbeInFlight = false
            if (!permitValid || googleVerificationActive || googleVerificationCheckPending || !isBackupTwoStepConfirmed(view)) {
                resetBackupAutomationCandidate()
                return@evaluateJavascript
            }
            val data = runCatching { JSONObject(result.orEmpty()) }.getOrNull()
            val account = data?.optString("account").orEmpty().trim().lowercase(Locale.US)
            val values = data?.optJSONArray("codes")
            val codes = if (values == null) emptyList() else (0 until values.length()).mapNotNull { index ->
                (values.opt(index) as? String)?.takeIf { it.matches(Regex("[0-9]{8}")) }
            }
            val knownAccount = backupAutomationAccount.ifBlank { accountKeyByWebView[view].orEmpty() }.trim().lowercase(Locale.US)
            val detectedAccount = accountKeyByWebView[view].orEmpty().trim().lowercase(Locale.US)
            if (data == null || data.optString("url") != view.url.orEmpty() || !isBackupCodesUrl(view.url.orEmpty()) ||
                !android.util.Patterns.EMAIL_ADDRESS.matcher(account).matches() || codes.isEmpty() || codes.size > 10 ||
                codes.size != values?.length() || codes.distinct().size != codes.size ||
                (knownAccount.isNotBlank() && knownAccount != account) ||
                (detectedAccount.isNotBlank() && detectedAccount != account) ||
                (knownAccount.isBlank() && !data.optBoolean("avatarConfirmed"))) {
                resetBackupAutomationCandidate()
                return@evaluateJavascript
            }
            val now = android.os.SystemClock.elapsedRealtime()
            if (backupAutomationCandidateAccount != account || backupAutomationCandidateCodes != codes) {
                backupAutomationCandidateAccount = account
                backupAutomationCandidateCodes = codes
                backupAutomationCandidateSince = now
                return@evaluateJavascript
            }
            if (now - backupAutomationCandidateSince < BACKUP_AUTOMATION_SETTLE_MS) return@evaluateJavascript
            if (backupAutomationIgnoredAccount == account && backupAutomationIgnoredCodes == codes) return@evaluateJavascript
            backupAutomationIgnoredAccount = ""
            backupAutomationIgnoredCodes = emptyList()
            accountKeyByWebView[view] = account
            currentAccountKey = account
            val accounts = loadAuthenticatorAccounts()
            val existing = (0 until accounts.length()).mapNotNull { accounts.optJSONObject(it) }
                .firstOrNull { it.optString("account").equals(account, true) }
            // A failed SharedPreferences commit can still update its in-memory value.
            val matchesSaved = !backupAutomationSaveFailed && existing != null && readAccountBackupCodes(existing) == codes
            val saved = matchesSaved || runCatching { saveAccountBackupCodes(account, codes) }.getOrDefault(false)
            backupAutomationSaveFailed = !saved
            if (saved) {
                if (!matchesSaved) Snackbar.make(drawerLayout, "Backup codes saved to Accounts", Snackbar.LENGTH_SHORT).show()
                markStageCompleted("backup", view, account)
                stopBackupAutomation()
                startNextConfiguredStage(view, "backup", accountOverride = account)
            }
        }
    }

    private fun probeBackupLink(view: WebView, generation: Long) {
        if (backupAutomationProbeInFlight || !isBackupTwoStepConfirmed(view)) return
        val url = view.url.orEmpty()
        val uri = runCatching { android.net.Uri.parse(url) }.getOrNull() ?: return
        if (!uri.scheme.equals("https", true) || !uri.host.equals("myaccount.google.com", true) || uri.port !in listOf(-1, 443) ||
            !uri.path.orEmpty().matches(Regex("(?:/u/[0-9]+)?/(?:signinoptions/twosv|two-step-verification)/?"))) return
        val account = backupAutomationAccount.trim().lowercase(Locale.US)
        val detected = accountKeyByWebView[view].orEmpty().trim().lowercase(Locale.US)
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(account).matches() || (detected.isNotBlank() && detected != account)) return
        val documentGeneration = backupAutomationDocumentGeneration
        val permit = java.util.UUID.randomUUID().toString()
        recoveryActionPermit = permit
        backupAutomationProbeInFlight = true
        val script = """
            (function() {
              if (window.top !== window || location.href !== ${JSONObject.quote(url)} ||
                  location.origin !== 'https://myaccount.google.com' || document.readyState !== 'complete' ||
                  document.visibilityState !== 'visible') return 'waiting';
              const permitted = () => { try { return window.EMRecoveryGuard.permitted(${JSONObject.quote(permit)}) === true; } catch (_) { return false; } };
              const visible = el => {
                if (!el || !el.isConnected || !el.getBoundingClientRect().width || !el.getBoundingClientRect().height) return false;
                for (let n = el; n; n = n.parentElement) {
                  const s = getComputedStyle(n);
                  if (n.hidden || s.display === 'none' || s.visibility !== 'visible' || Number(s.opacity) === 0) return false;
                }
                return true;
              };
              const body = document.body?.innerText || '';
              if (/verify it[’'‘]?s you|confirm it[’'‘]?s you|verify your identity|verify your account|checking your browser|unusual traffic|i.m not a robot/i.test(body) ||
                  Array.from(document.querySelectorAll('input[type="password"],iframe[src*="recaptcha"],iframe[src*="captcha"]')).some(visible)) return 'waiting';
              const emails = new Set();
              for (const el of document.querySelectorAll('[aria-label],[title]')) {
                if (!visible(el)) continue;
                const label = (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '');
                if (/google account/i.test(label)) for (const email of label.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig) || []) emails.add(email.toLowerCase());
              }
              if (emails.size !== 1 || !emails.has(${JSONObject.quote(account)})) return 'waiting';
              const links = Array.from(document.querySelectorAll('a.RlFDUe.mlgsfe[href]')).filter(el => {
                if (!visible(el) || el.getAttribute('aria-disabled') === 'true' || (el.target && el.target !== '_self') || el.hasAttribute('download')) return false;
                const text = (el.innerText || '').replace(/\s+/g, ' ').trim();
                if (!/\bBackup codes\b/.test(text) || !/\bGet backup codes\b/.test(text)) return false;
                try {
                  const dest = new URL(el.getAttribute('href'), document.baseURI);
                  return dest.origin === 'https://myaccount.google.com' && !dest.username && !dest.password &&
                    /^(?:\/u\/\d+)?\/two-step-verification\/backup-codes\/?${'$'}/.test(dest.pathname);
                } catch (_) { return false; }
              });
              if (links.length !== 1 || window.__emBackupLinkIssued || !permitted()) return 'waiting';
              window.__emBackupLinkIssued = true;
              links[0].click();
              return 'clicked';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) {
            if (recoveryActionPermit == permit) recoveryActionPermit = ""
            if (!isBackupAutomationCurrent(view, generation) || backupAutomationDocumentGeneration != documentGeneration) return@evaluateJavascript
            backupAutomationProbeInFlight = false
        }
    }

    private fun clearPasswordAutomationState() {
        passwordAutomationView?.evaluateJavascript("try { sessionStorage.removeItem('__emPasswordManualSubmit'); } catch(e) {}", null)
        passwordAutomationActive = false
        passwordAutomationView = null
        passwordAutomationAccount = ""
        passwordAutomationSuccessPending = false
        passwordChangeSubmitted = false
        passwordReauthSubmitted = false
        passwordConfirmationClickIssued = false
        passwordConfirmationToken = ""
        passwordFlowStartedForCurrentAutomation = false
    }

    private fun startAppPasswordAutomation(view: WebView) {
        if (!automationMasterEnabled || !appPasswordAutomationEnabled || appPasswordAutomationActive) return
        appPasswordAutomationActive = true
        appPasswordAutomationCreateClicked = false
        appPasswordAutomationSavePending = false
        appPasswordAutomationSaved = false
        appPasswordAutomationStartedAt = System.currentTimeMillis()
        view.evaluateJavascript("try { delete window.__emAppPasswordCreateIssued; sessionStorage.removeItem('__emAppPasswordCreateIssued'); } catch(e) {}", null)
        view.loadUrl(withSelectedLanguage(APP_PASSWORDS_URL))
    }

    private fun stopAppPasswordAutomation() {
        appPasswordAutomationActive = false
        appPasswordAutomationCreateClicked = false
        appPasswordAutomationSavePending = false
        appPasswordAutomationSaved = false
        appPasswordAutomationStartedAt = 0L
    }

    private fun finishAppPasswordAutomation(view: WebView, saved: Boolean) {
        if (!appPasswordAutomationActive) return
        stopAppPasswordAutomation()
        if (saved) markStageCompleted("app_password", view)
        val message = if (saved) "App password saved to Accounts" else "App password was not created; check account eligibility"
        Snackbar.make(drawerLayout, message, Snackbar.LENGTH_LONG).show()
        startNextConfiguredStage(view, "app_password", extraDelay = 250L)
    }

    private fun saveGeneratedAppPassword(view: WebView, value: String) {
        if (!appPasswordAutomationActive || appPasswordAutomationSaved || appPasswordAutomationSavePending) return
        val knownAccount = accountKeyByWebView[view].orEmpty()
        if (knownAccount.isBlank()) {
            appPasswordAutomationSavePending = true
            detectGoogleAccountKey(view) { detectedAccount ->
                appPasswordAutomationSavePending = false
                if (!appPasswordAutomationActive) return@detectGoogleAccountKey
                val account = detectedAccount.trim().lowercase(Locale.US)
                if (account.isBlank()) return@detectGoogleAccountKey
                accountKeyByWebView[view] = account
                if (view === currentWebView()) currentAccountKey = account
                persistGeneratedAppPassword(view, account, value)
            }
            return
        }
        persistGeneratedAppPassword(view, knownAccount, value)
    }

    private fun persistGeneratedAppPassword(view: WebView, account: String, value: String) {
        if (!appPasswordAutomationActive || appPasswordAutomationSaved) return
        val accounts = loadAuthenticatorAccounts()
        val index = (0 until accounts.length()).firstOrNull {
            accounts.optJSONObject(it)?.optString("account").orEmpty().equals(account, true)
        }
        val staged = stagedSignInCredentials(account)
        val existing = index?.let { accounts.optJSONObject(it) }
        val item = when {
            existing != null -> JSONObject(existing.toString())
            staged != null -> JSONObject(staged.toString())
            else -> JSONObject()
        }
        val savedAt = System.currentTimeMillis()
        item.put("account", account)
        item.put("appPassword", value)
        item.put("appPasswordCreatedAt", savedAt)
        if (item.optLong("savedAt", 0L) == 0L) item.put("savedAt", savedAt)
        if (index != null) accounts.put(index, item) else accounts.put(item)
        saveAuthenticatorAccounts(accounts)
        saveAuthenticatorLogFile(accounts)
        clearStagedSignInCredentials(account)
        appPasswordAutomationSaved = true
        finishAppPasswordAutomation(view, saved = true)
    }

    private fun injectAppPasswordAutomation(view: WebView) {
        if (!automationMasterEnabled || !appPasswordAutomationEnabled || !appPasswordAutomationActive) return
        if (googleVerificationActive || googleVerificationCheckPending) return

        val createClicked = appPasswordAutomationCreateClicked
        val script = """
            (function() {
              const createClicked = $createClicked;
              const normalize = value => String(value || '')
                .replace(/[\u200e\u200f\u202a-\u202e]/g, '')
                .replace(/\s+/g, ' ').trim();
              const visible = el => {
                if (!el) return false;
                const r = el.getBoundingClientRect();
                const s = getComputedStyle(el);
                return r.width > 1 && r.height > 1 && s.display !== 'none' &&
                       s.visibility !== 'hidden' && s.opacity !== '0';
              };
              const textOf = el => normalize(el?.innerText || el?.textContent || el?.value || '');
              const passwordContext = /app\s+password|application\s+password|كلم(?:ة|ات)\s+(?:ال)?مرور\s+(?:ال)?تطبيق(?:ك|ات)?|كلمة\s+المرور\s+الخاصة\s+بالتطبيق/i;
              const bodyText = textOf(document.body);
              const createWasIssued = createClicked || window.__emAppPasswordCreateIssued === true ||
                (() => { try { return sessionStorage.getItem('__emAppPasswordCreateIssued') === '1'; } catch (_) { return false; } })();
              const grouped = bodyText.match(/\b([a-z0-9]{4})[\s\u00a0]+([a-z0-9]{4})[\s\u00a0]+([a-z0-9]{4})[\s\u00a0]+([a-z0-9]{4})\b/i);
              const compact = bodyText.match(/\b([a-z0-9]{16})\b/i);
              if (passwordContext.test(bodyText) && (grouped || compact)) {
                const raw = grouped
                  ? [grouped[1], grouped[2], grouped[3], grouped[4]].join(' ')
                  : compact[1].match(/.{4}/g).join(' ');
                return 'password_found:' + raw.toLowerCase();
              }
              if (createWasIssued) return 'waiting';

              const inputs = Array.from(document.querySelectorAll('input:not([type="hidden"]),textarea')).filter(visible);
              const appNameRe = /app\s*name|name\s+(?:of|your)\s+app|اسم\s+(?:التطبيق|التطبيقات|التطبيق\s+أو\s+الخدمة)/i;
              const inputDescription = el => {
                const labels = Array.from(document.querySelectorAll('label'))
                  .filter(label => label.control === el || label.contains(el) || (el.id && label.htmlFor === el.id))
                  .map(textOf);
                const parent = el.parentElement;
                return normalize([
                  el.getAttribute('aria-label'), el.getAttribute('placeholder'), el.getAttribute('name'),
                  el.id, ...labels, parent?.innerText, parent?.parentElement?.innerText
                ].filter(Boolean).join(' '));
              };
              let nameInput = inputs.find(el => appNameRe.test(inputDescription(el)));
              if (!nameInput) {
                const textInputs = inputs.filter(el => el instanceof HTMLInputElement && el.type === 'text');
                if (textInputs.length === 1) nameInput = textInputs[0];
              }
              if (!nameInput) return 'waiting';

              const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
              if (setter && nameInput instanceof HTMLInputElement) setter.call(nameInput, 'All');
              else nameInput.value = 'All';
              nameInput.dispatchEvent(new Event('input', {bubbles:true}));
              nameInput.dispatchEvent(new Event('change', {bubbles:true}));
              try { nameInput.blur(); } catch (_) {}

              const buttons = Array.from(document.querySelectorAll('button,[role="button"],input[type="submit"]')).filter(visible);
              const createButton = buttons.find(el => /^(create|إنشاء|انشاء)$/i.test(textOf(el))) ||
                buttons.find(el => /create|إنشاء|انشاء/i.test(textOf(el)));
              if (!createButton || createButton.disabled || createButton.getAttribute('aria-disabled') === 'true') return 'waiting';
              window.__emAppPasswordCreateIssued = true;
              try { sessionStorage.setItem('__emAppPasswordCreateIssued', '1'); } catch (_) {}
              try { createButton.click(); } catch (_) {
                window.__emAppPasswordCreateIssued = false;
                try { sessionStorage.removeItem('__emAppPasswordCreateIssued'); } catch (_) {}
                return 'waiting';
              }
              return 'create_clicked';
            })();
        """.trimIndent()

        view.evaluateJavascript(script) { result ->
            val value = result?.trim('"').orEmpty()
            when {
                value == "create_clicked" -> {
                    appPasswordAutomationCreateClicked = true
                    view.postDelayed({ if (appPasswordAutomationActive) injectAppPasswordAutomation(view) }, 900L)
                }
                value.startsWith("password_found:") -> {
                    val password = value.substringAfter("password_found:").trim()
                    if (password.matches(Regex("[a-z0-9]{4}(?:\\s+[a-z0-9]{4}){3}", RegexOption.IGNORE_CASE))) {
                        saveGeneratedAppPassword(view, password)
                    }
                    if (appPasswordAutomationActive &&
                        System.currentTimeMillis() - appPasswordAutomationStartedAt >= APP_PASSWORD_AUTOMATION_TIMEOUT_MS) {
                        finishAppPasswordAutomation(view, saved = false)
                    } else if (appPasswordAutomationActive) {
                        view.postDelayed({ injectAppPasswordAutomation(view) }, 900L)
                    }
                }
                else -> {
                    if (System.currentTimeMillis() - appPasswordAutomationStartedAt >= APP_PASSWORD_AUTOMATION_TIMEOUT_MS) {
                        finishAppPasswordAutomation(view, saved = false)
                    } else if (appPasswordAutomationActive) {
                        view.postDelayed({ injectAppPasswordAutomation(view) }, 900L)
                    }
                }
            }
        }
    }

    // ---- Ads stage ---------------------------------------------------------------------------

    private fun startAdsAutomation(view: WebView) {
        if (!automationMasterEnabled || !adsAutomationEnabled || adsAutomationActive) return
        val account = accountKeyForStages(view)
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(account).matches()) {
            Snackbar.make(drawerLayout, "Ads check skipped: account not identified", Snackbar.LENGTH_LONG).show()
            startNextConfiguredStage(view, "ads", extraDelay = 250L)
            return
        }
        adsAutomationActive = true
        adsAutomationView = view
        adsAutomationAccount = account
        adsAutomationLoadedAt = 0L
        adsAutomationLoadFailed = false
        adsAutomationStartedAt = android.os.SystemClock.elapsedRealtime()
        val generation = ++adsAutomationGeneration
        view.loadUrl(ADS_URL)
        view.postDelayed({ injectAdsAutomation(view, generation) }, 1000L)
    }

    private fun stopAdsAutomation() {
        adsAutomationActive = false
        adsAutomationView = null
        adsAutomationAccount = ""
        adsAutomationLoadedAt = 0L
        adsAutomationLoadFailed = false
        adsAutomationStartedAt = 0L
        adsAutomationGeneration++
    }

    private fun persistAdsResult(account: String, available: Boolean) {
        val accounts = loadAuthenticatorAccounts()
        val index = (0 until accounts.length()).firstOrNull {
            accounts.optJSONObject(it)?.optString("account").orEmpty().equals(account, true)
        }
        val existing = index?.let { accounts.optJSONObject(it) }
        val staged = stagedSignInCredentials(account)
        val item = when {
            existing != null -> JSONObject(existing.toString())
            staged != null -> JSONObject(staged.toString())
            else -> JSONObject()
        }
        if (staged != null) {
            for (key in listOf("password", "twoFa", "secret", "appPassword", "recoveryEmail")) {
                if (item.optString(key).isBlank() && staged.optString(key).isNotBlank()) {
                    item.put(key, staged.optString(key))
                }
            }
        }
        val savedAt = System.currentTimeMillis()
        item.put("account", account)
        item.put("ads", if (available) "ads available" else "ads not available")
        item.put("adsAt", savedAt)
        if (item.optLong("savedAt", 0L) == 0L) item.put("savedAt", savedAt)
        if (index != null) accounts.put(index, item) else accounts.put(item)
        saveAuthenticatorAccounts(accounts)
        saveAuthenticatorLogFile(accounts)
    }

    private fun finishAdsAutomation(view: WebView, found: Boolean) {
        if (!adsAutomationActive || adsAutomationView !== view) return
        val account = adsAutomationAccount
        if (account != accountKeyForStages(view)) {
            stopAdsAutomation()
            Snackbar.make(drawerLayout, "Ads check stopped: account changed", Snackbar.LENGTH_LONG).show()
            return
        }
        persistAdsResult(account, found)
        markStageCompleted("ads", view, account)
        stopAdsAutomation()
        val message = if (found) "ads available" else "ads not available (conditions not detected)"
        Snackbar.make(drawerLayout, message, Snackbar.LENGTH_LONG).show()
        startNextConfiguredStage(view, "ads", immediate = true, accountOverride = account)
    }

    private fun injectAdsAutomation(view: WebView, generation: Long) {
        if (generation != adsAutomationGeneration || !adsAutomationActive ||
            !automationMasterEnabled || !adsAutomationEnabled || adsAutomationView !== view) return
        fun retry() = view.postDelayed({ injectAdsAutomation(view, generation) }, 500L)
        if (automationActivityStopped || view !== currentWebView()) {
            if (adsAutomationLoadedAt > 0L) adsAutomationLoadedAt = android.os.SystemClock.elapsedRealtime()
            adsAutomationStartedAt = android.os.SystemClock.elapsedRealtime()
            retry()
            return
        }
        val uri = runCatching { android.net.Uri.parse(view.url.orEmpty()) }.getOrNull()
        val host = uri?.host?.lowercase(Locale.US).orEmpty()
        if (googleVerificationActive || googleVerificationCheckPending) {
            if (adsAutomationLoadedAt > 0L) adsAutomationLoadedAt = android.os.SystemClock.elapsedRealtime()
            adsAutomationStartedAt = android.os.SystemClock.elapsedRealtime()
            retry()
            return
        }
        if (adsAutomationLoadedAt == 0L && android.os.SystemClock.elapsedRealtime() - adsAutomationStartedAt >= ADS_LOAD_TIMEOUT_MS) {
            stopAdsAutomation()
            Snackbar.make(drawerLayout, "Ads page did not load; no result saved", Snackbar.LENGTH_LONG).show()
            startNextConfiguredStage(view, "ads", immediate = true)
            return
        }
        if (!uri?.scheme.equals("https", true) || host != "ads.google.com" || uri?.port !in listOf(-1, 443)) {
            retry()
            return
        }
        val documentGeneration = adsAutomationDocumentGeneration
        val script = """
            (function() {
              if (location.protocol !== 'https:' || location.hostname !== 'ads.google.com' ||
                  (location.port && location.port !== '443') ||
                  document.readyState !== 'complete') return 'waiting';
              const visible = el => {
                const r = el.getBoundingClientRect();
                if (r.width <= 0 || r.height <= 0) return false;
                for (let node = el; node; node = node.parentElement) {
                  const s = getComputedStyle(node);
                  if (node.hidden || s.display === 'none' || s.visibility === 'hidden' || Number(s.opacity) === 0) return false;
                }
                return true;
              };
              const body = (document.body?.innerText || '').replace(/\s+/g, ' ').trim();
              if (!body || /\b(?:loading|please wait|just a moment|error|failed to load|couldn.t load|could not load|unable to load|can.t load|something went wrong|there was a problem|this site can.t be reached|page isn.t working|no internet|temporarily unavailable|service unavailable|try again later|sign in|verify (?:your (?:identity|account|phone|email)|it.s you)|confirm (?:your identity|it.s you)|verification (?:required|needed)|complete (?:the )?verification|security check|checking your browser|unusual traffic|captcha|i.m not a robot|prove you.re (?:not a robot|human))\b/i.test(body) ||
                  Array.from(document.querySelectorAll('[role="progressbar"],[aria-busy="true"],progress,mat-spinner,mat-progress-spinner,.spinner,.loader,.loading,.loading-spinner,.loading-indicator,.skeleton,.error-page,.error-message,iframe[src*="/recaptcha/api2/bframe"],iframe[src*="/recaptcha/api2/anchor"],iframe[src*="/recaptcha/enterprise/bframe"],iframe[src*="/recaptcha/enterprise/anchor"]')).some(visible) ||
                  Array.from(document.querySelectorAll('[aria-label]')).some(el => visible(el) && /^(?:loading|please wait)(?:\.{3}|\u2026)?${'$'}/i.test((el.getAttribute('aria-label') || '').trim()))) return 'waiting';
              const shells = Array.from(document.querySelectorAll('ufo-root,.awsm-content-main')).filter(visible);
              const renderedShells = shells.filter(el => {
                const text = (el.innerText || '').replace(/\s+/g, ' ').trim();
                return text.length >= 4 && /[^\s\d.,:;!?()[\]{}'"_\-]/.test(text);
              });
              const noAccounts = Array.from(document.querySelectorAll('multiaccount-view div.no-accounts-container > h2.no-accounts-tag')).some(visible);
              const accountSelection = Array.from(document.querySelectorAll('multiaccount-view h2.selection-header-new, multiaccount-view button.new-account-button')).some(visible);
              if (!noAccounts && !accountSelection && (!location.pathname.startsWith('/aw/') || !renderedShells.length)) return 'waiting';
              const expectedAccount = ${JSONObject.quote(adsAutomationAccount)}.trim().toLowerCase();
              const emails = new Set();
              const emailPattern = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig;
              for (const el of document.querySelectorAll('[aria-label],[title]')) {
                if (!visible(el)) continue;
                const labels = [el.getAttribute('aria-label'), el.getAttribute('title')].filter(label =>
                  /^\s*google account(?:\s*[:,(\-]|\s*${'$'})/i.test(label || ''));
                if (!labels.length) continue;
                const values = [...labels, el.getAttribute('data-email'), el.getAttribute('data-identifier')];
                for (const value of values) for (const email of String(value || '').match(emailPattern) || []) emails.add(email.toLowerCase());
              }
              if (emails.size && (emails.size !== 1 || !emails.has(expectedAccount))) return 'account_mismatch';
              const accountStatus = emails.size ? 'verified' : 'unverified';
              if (noAccounts) return 'found_no_accounts_' + accountStatus;
              if (accountSelection) return 'found_selection_' + accountStatus;
              const headings = Array.from(document.querySelectorAll('h1.ufo-page-header'));
              if (/^\/aw\/signup(?:\/|${'$'})/.test(location.pathname) &&
                  headings.some(el => visible(el) && renderedShells.some(shell => shell.contains(el)) &&
                  (el.innerText || '').trim().length > 0)) return 'found_' + accountStatus;
              return 'loaded_' + accountStatus;
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (generation != adsAutomationGeneration || !adsAutomationActive ||
                !automationMasterEnabled) return@evaluateJavascript
            if (documentGeneration != adsAutomationDocumentGeneration) {
                retry()
                return@evaluateJavascript
            }
            if (view !== currentWebView() || automationActivityStopped) {
                if (adsAutomationLoadedAt > 0L) adsAutomationLoadedAt = android.os.SystemClock.elapsedRealtime()
                adsAutomationStartedAt = android.os.SystemClock.elapsedRealtime()
                retry()
                return@evaluateJavascript
            }
            val currentUri = runCatching { android.net.Uri.parse(view.url.orEmpty()) }.getOrNull()
            if (!currentUri?.scheme.equals("https", true) || !currentUri?.host.equals("ads.google.com", true) ||
                currentUri?.port !in listOf(-1, 443)) {
                adsAutomationLoadedAt = 0L
                retry()
                return@evaluateJavascript
            }
            val scriptResult = result?.trim('"').orEmpty()
            val value = if (currentUri?.path?.startsWith("/aw/") == true || scriptResult == "account_mismatch" ||
                scriptResult == "found_no_accounts_verified" || scriptResult == "found_no_accounts_unverified" ||
                scriptResult == "found_selection_verified" || scriptResult == "found_selection_unverified") scriptResult else "waiting"
            val now = android.os.SystemClock.elapsedRealtime()
            if (value == "account_mismatch") {
                stopAdsAutomation()
                Snackbar.make(drawerLayout, "Ads check stopped: a different account is shown", Snackbar.LENGTH_LONG).show()
                return@evaluateJavascript
            }
            val found = value == "found_verified" || value == "found_unverified" ||
                value == "found_no_accounts_verified" || value == "found_no_accounts_unverified" ||
                value == "found_selection_verified" || value == "found_selection_unverified"
            val resolved = found || (adsAutomationLoadedAt > 0L && now - adsAutomationLoadedAt >= ADS_DETECTION_TIMEOUT_MS)
            if (resolved) {
                finishAdsAutomation(view, found)
            } else retry()
        }
    }

    // ---- YouTube premium stage ---------------------------------------------------------------

    private fun startYoutubePremiumAutomation(view: WebView) {
        if (!automationMasterEnabled || !youtubePremiumAutomationEnabled || youtubePremiumAutomationActive) return
        youtubePremiumAutomationActive = true
        youtubePremiumAutomationSaved = false
        youtubePremiumAutomationStartedAt = System.currentTimeMillis()
        val generation = ++youtubePremiumAutomationGeneration
        view.loadUrl(withSelectedLanguage(YOUTUBE_PREMIUM_URL))
        view.postDelayed({ injectYoutubePremiumAutomation(view, generation) }, 2000L)
    }

    private fun stopYoutubePremiumAutomation() {
        youtubePremiumAutomationActive = false
        youtubePremiumAutomationSaved = false
        youtubePremiumAutomationStartedAt = 0L
        youtubePremiumAutomationGeneration++
    }

    private fun finishYoutubePremiumAutomation(view: WebView, message: String) {
        if (!youtubePremiumAutomationActive) return
        stopYoutubePremiumAutomation()
        Snackbar.make(drawerLayout, message, Snackbar.LENGTH_LONG).show()
        startNextConfiguredStage(view, "youtube_premium", extraDelay = 250L)
    }

    private fun persistYoutubePremium(account: String) {
        val accounts = loadAuthenticatorAccounts()
        val index = (0 until accounts.length()).firstOrNull {
            accounts.optJSONObject(it)?.optString("account").orEmpty().equals(account, true)
        }
        val staged = stagedSignInCredentials(account)
        val existing = index?.let { accounts.optJSONObject(it) }
        val item = when {
            existing != null -> JSONObject(existing.toString())
            staged != null -> JSONObject(staged.toString())
            else -> JSONObject()
        }
        val savedAt = System.currentTimeMillis()
        item.put("account", account)
        item.put("youtubePremium", "YouTube premium")
        item.put("youtubePremiumAt", savedAt)
        if (item.optLong("savedAt", 0L) == 0L) item.put("savedAt", savedAt)
        if (index != null) accounts.put(index, item) else accounts.put(item)
        saveAuthenticatorAccounts(accounts)
        saveAuthenticatorLogFile(accounts)
        clearStagedSignInCredentials(account)
    }

    private fun injectYoutubePremiumAutomation(view: WebView, generation: Long) {
        if (generation != youtubePremiumAutomationGeneration || !youtubePremiumAutomationActive ||
            !automationMasterEnabled || !youtubePremiumAutomationEnabled) return
        val script = """
            (function() {
              if (!/(^|\.)youtube\.com$/i.test(location.hostname)) return 'waiting';
              if (document.readyState === 'loading') return 'waiting';
              const normalize = value => String(value || '')
                .replace(/[\u200e\u200f\u202a-\u202e]/g, '')
                .replace(/\s+/g, ' ').trim();
              const visible = el => {
                if (!el) return false;
                const r = el.getBoundingClientRect();
                const s = getComputedStyle(el);
                return r.width > 1 && r.height > 1 && s.display !== 'none' &&
                       s.visibility !== 'hidden' && s.opacity !== '0';
              };
              // "Try 1 month for EGP 0" (the price may contain a non-breaking space).
              const trial = /^try\s+1\s+month\s+for\s+egp\s*0(?:[.,]0+)?$/i;
              const candidates = Array.from(document.querySelectorAll('button,[role="button"],a'));
              const hit = candidates.find(el => visible(el) && (
                trial.test(normalize(el.getAttribute('aria-label'))) ||
                trial.test(normalize(el.innerText || el.textContent))
              ));
              return hit ? 'found' : 'waiting';
            })();
        """.trimIndent()

        view.evaluateJavascript(script) { result ->
            if (generation != youtubePremiumAutomationGeneration || !youtubePremiumAutomationActive) return@evaluateJavascript
            val value = result?.trim('"').orEmpty()
            if (value == "found") {
                val account = accountKeyForStages(view)
                if (account.isBlank()) {
                    finishYoutubePremiumAutomation(view, "YouTube premium found, but the account could not be identified")
                } else {
                    persistYoutubePremium(account)
                    youtubePremiumAutomationSaved = true
                    markStageCompleted("youtube_premium", view, account)
                    finishYoutubePremiumAutomation(view, "YouTube premium saved to Accounts")
                }
                return@evaluateJavascript
            }
            if (System.currentTimeMillis() - youtubePremiumAutomationStartedAt >= YOUTUBE_PREMIUM_TIMEOUT_MS) {
                finishYoutubePremiumAutomation(view, "YouTube premium offer not found for this account")
            } else {
                view.postDelayed({ injectYoutubePremiumAutomation(view, generation) }, 800L)
            }
        }
    }

    private fun updateSavedAccountPassword(newPassword: String, accountOverride: String? = null) {
        val targetAccount = (accountOverride ?: currentAccountKey).orEmpty()
        if (targetAccount.isBlank() || newPassword.isBlank()) return
        val accounts = loadAuthenticatorAccounts()
        val index = (0 until accounts.length()).firstOrNull {
            accounts.optJSONObject(it)?.optString("account").orEmpty().equals(targetAccount, true)
        }
        val stagedCredentials = stagedSignInCredentials(targetAccount)
        val existingItem = index?.let { accounts.optJSONObject(it) }
        val existingIsChanged = existingItem?.let { isAccountChangeRecord(it) } == true
        val item = when {
            existingIsChanged -> existingItem
            stagedCredentials != null -> JSONObject(stagedCredentials.toString())
            else -> existingItem
        } ?: JSONObject()
        val previousPassword = item.optString("password")
        if (previousPassword == newPassword) return
        val changedAt = System.currentTimeMillis()
        val stagedTwoFa = stagedCredentials?.optString("twoFa").orEmpty()
            .ifBlank { stagedCredentials?.optString("secret").orEmpty() }
        if (item.optString("twoFa").isBlank() && stagedTwoFa.isNotBlank()) {
            item.put("twoFa", stagedTwoFa)
            item.put("secret", stagedTwoFa)
        }
        item.apply {
            put("account", targetAccount)
            put("password", newPassword)
            put("passwordChangedAt", changedAt)
            if (optLong("savedAt", 0L) == 0L) put("savedAt", changedAt)
        }
        if (index != null) accounts.put(index, item) else accounts.put(item)
        saveAuthenticatorAccounts(accounts)
        saveAuthenticatorLogFile(accounts)
        clearStagedSignInCredentials(targetAccount)
    }

    private fun completePasswordAutomationFromSuccess(view: WebView, confirmedPassword: String? = null) {
        if (!isPasswordRun(view, passwordConfirmationToken) || view !== currentWebView() || automationActivityStopped || !passwordChangeSubmitted) return
        val observedAccount = accountKeyByWebView[view].orEmpty()
        if (passwordAutomationAccount.isNotBlank() && observedAccount.isNotBlank() &&
            !passwordAutomationAccount.equals(observedAccount, true)) return
        val account = passwordAutomationAccount.ifBlank { observedAccount }
        currentAccountKey = account
        if (account.isNotBlank()) accountKeyByWebView[view] = account

        // Google has confirmed the change: the "new" password is now the real sign-in
        // password, so it becomes "current" automatically (for the next sign-in, and for
        // anything — like the Google field autofill — that reads "current password").
        val changedPassword = confirmedPassword ?: passwordAutomationNew
        if (changedPassword.isNotBlank()) {
            passwordAutomationCurrent = changedPassword
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_PASSWORD_CURRENT, changedPassword)
                .apply()
            updateSavedAccountPassword(changedPassword, accountOverride = account)
        }

        clearPasswordAutomationState()
        recoveryEmailAutomationActive = false
        combinedAutomationWaitingForPassword = false

        // Clear the one-submit lock only after Google has accepted the change.
        view.evaluateJavascript("try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); sessionStorage.removeItem('__emPasswordFlowReauth'); } catch(e) {}", null)

        automationHasRunInCurrentGoogleSession = true
        Snackbar.make(drawerLayout, "Password changed successfully", Snackbar.LENGTH_LONG).show()
        if (account.isNotBlank()) markStageCompleted("password", view, account)
        startNextConfiguredStage(view, "password")
    }

    private fun injectPasswordChangeScript(view: WebView) {
        if (googleVerificationActive || googleVerificationCheckPending) return
        val confirmationToken = passwordConfirmationToken
        if (!isPasswordRun(view, confirmationToken) || view !== currentWebView() || automationActivityStopped ||
            credentialHost(android.net.Uri.parse(view.url.orEmpty())) == null) return
        val current = JSONObject.quote(passwordAutomationCurrent)
        val newPassword = JSONObject.quote(passwordAutomationNew)

        val script = """
            (function() {
              if (location.protocol !== 'https:' || !['accounts.google.com', 'myaccount.google.com'].includes(location.hostname) ||
                  (location.port && location.port !== '443')) return 'waiting';
              const currentPassword = $current;
              const newPassword = $newPassword;
              const visible = el => !!el && el.offsetParent !== null;
              const setValue = (el, value) => {
                const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
                if (setter) setter.call(el, value); else el.value = value;
                el.dispatchEvent(new Event('input', {bubbles:true}));
                el.dispatchEvent(new Event('change', {bubbles:true}));
              };
              const buttonText = el => ((el.innerText || el.value || el.getAttribute('aria-label') || '') + '').trim().toLowerCase();
              const buttons = Array.from(document.querySelectorAll('button, input[type=submit]')).filter(visible);
              const formButtons = buttons.filter(el => !el.closest('[role="dialog"],dialog,[aria-modal="true"]'));
              const passwords = Array.from(document.querySelectorAll('input[type=password]')).filter(visible);
              // Never take ownership of a field the user has edited, even if cleared.
              const flowToken = ${JSONObject.quote(confirmationToken)};
              if (!window.__emPasswordFields || window.__emPasswordFields.token !== flowToken) {
                window.__emPasswordFields = {token: flowToken, manual: {}, owned: new WeakMap(), observed: new WeakSet()};
              }
              const fields = window.__emPasswordFields;
              const fillField = (el, key, value) => {
                if (!fields.observed.has(el)) {
                  fields.observed.add(el);
                  el.addEventListener('input', e => { if (e.isTrusted) fields.manual[key] = true; });
                  el.addEventListener('change', e => { if (e.isTrusted) fields.manual[key] = true; });
                }
                const owned = fields.owned.get(el);
                if ((owned !== undefined && el.value !== owned) || (owned === undefined && el.value)) fields.manual[key] = true;
                if (!value || fields.manual[key]) return false;
                if (owned === undefined || owned !== value) {
                  setValue(el, value);
                  fields.owned.set(el, value);
                }
                return el.value === value;
              };
              const pageText = document.body?.innerText || document.documentElement?.innerText || '';
              // Google can show password success in more than one UI surface:
              // a bottom snackbar/toast OR a green confirmation banner near the
              // top of the page. Do not wait for one specific notification class.
              // Read all visible notification-like elements, plus visible elements
              // with a green background, and normalize Arabic whitespace/punctuation.
              const normalizeSuccessText = value => (value || '')
                .replace(/[\u200f\u200e]/g, '')
                .replace(/[\u0640]/g, '')
                .replace(/[\u061f.,،؛:!؟]+/g, ' ')
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();
              const successText = /تم\s+(?:تغيير|تحديث)\s+(?:كلمة\s+)?(?:المرور|السر)(?:\s+بنجاح)?|تم\s+تغيير\s+كلمة\s+المرور|password\s+(?:changed|updated)(?:\s+successfully)?|your\s+password\s+(?:was\s+)?changed|password\s+has\s+been\s+changed/i;
              const notificationNodes = Array.from(document.querySelectorAll(
                '[role="alert"],[role="status"],[aria-live],.snackbar,.toast,.notification,.alert,.banner,[class*="snackbar"],[class*="toast"],[class*="notification"],[class*="alert"],[class*="banner"]'
              )).filter(visible);
              const greenNodes = Array.from(document.querySelectorAll('body *')).filter(el => {
                if (!visible(el)) return false;
                const text = normalizeSuccessText(el.innerText || el.textContent || el.getAttribute('aria-label') || '');
                if (!text || text.length > 220) return false;
                const style = window.getComputedStyle(el);
                const bg = (style.backgroundColor || '').replace(/\s+/g, '');
                return /rgb\(?(?:25[0-9]|2[0-4][0-9]),(?:1[0-9][0-9]|[0-9]{1,2}),(?:7[0-9]|[0-5][0-9])\)?/i.test(bg) ||
                       /rgb\(?(?:0,)?(?:12[0-9]|1[0-1][0-9]),(?:14[0-9]|1[0-9][0-9]),(?:7[0-9]|[0-5][0-9])\)?/i.test(bg);
              });
              const liveText = notificationNodes.concat(greenNodes)
                .map(el => normalizeSuccessText(el.innerText || el.textContent || el.getAttribute('aria-label') || ''))
                .filter(Boolean)
                .join(' ');
              const normalizedPageText = normalizeSuccessText(pageText);
              // window-scoped locks disappear when Google navigates/reloads the
              // password page. sessionStorage survives that navigation, preventing
              // a second fill/click while the first request is still awaiting Google's response.
              // Lock the password submission synchronously in page storage before any
              // second evaluateJavascript callback can reach the fields. This prevents
              // two concurrent injections from both seeing an unlocked form and filling
              // / clicking it twice.
              const submitLocked = window.__emPasswordAutomationSubmitted === true ||
                    (() => { try { return sessionStorage.getItem('__emPasswordFlowSubmitted') === '1'; } catch(e) { return false; } })();
              const reauthLocked = window.__emPasswordAutomationReauthSubmitted === true ||
                     (() => { try { return sessionStorage.getItem('__emPasswordFlowReauth') === '1'; } catch(e) { return false; } })();
              const errorText = /حدث خطأ(?: أثناء تغيير كلمة المرور| في تغيير كلمة المرور)?|حدثت مشكلة(?: أثناء تغيير كلمة المرور| في تغيير كلمة المرور)?|تعذر تغيير كلمة المرور|تعذر تحديث كلمة المرور|لم نتمكن من تغيير كلمة المرور|لم يتم تغيير كلمة المرور|فشل تغيير كلمة المرور|حدث خطأ ما|هناك خطأ ما|هناك مشكلة(?: أثناء تغيير كلمة المرور| في تغيير كلمة المرور)?|حدثت مشكلة ما|something went wrong(?: while changing your password)?|there was a problem(?: changing your password)?|couldn['\\'’]t change your password|could not change your password|unable to change your password|we couldn['\\'’]t change your password|password change failed|failed to change your password|password could not be changed/i;

              // Capture only an actual user click on the change form, never an app click
              // or a reauthentication submission. The value is short-lived and run-scoped.
              const manualKey = '__emPasswordManualSubmit';
              const explicitSuccess = value => /^(?:your password (?:was |has been )?(?:changed|updated)(?: successfully)?|password (?:changed|updated)(?: successfully)?|تم (?:تغيير|تحديث) كلمة (?:المرور|السر)(?: بنجاح)?)$/i.test(normalizeSuccessText(value));
              const hasManualSuccess = () => Array.from(document.querySelectorAll('[role="alert"],[role="status"],[aria-live],.snackbar,.toast,.notification,.alert,.banner,[class*="snackbar"],[class*="toast"],[class*="notification"],[class*="alert"],[class*="banner"],h1,h2')).filter(visible)
                .some(el => explicitSuccess(el.innerText || el.textContent || el.getAttribute('aria-label') || ''));
              if (!fields.manualListener) {
                fields.manualListener = true;
                document.addEventListener('click', event => {
                  if (!event.isTrusted || window.__emPasswordFields !== fields || window.top !== window ||
                      location.protocol !== 'https:' || !['accounts.google.com', 'myaccount.google.com'].includes(location.hostname) ||
                      (location.port && location.port !== '443') || !/^\/signinoptions\/password(?:\/|$)/i.test(location.pathname)) return;
                  try { if (window.__emPasswordAutomationSubmitted || sessionStorage.getItem('__emPasswordFlowSubmitted') === '1') return; } catch (_) { return; }
                  const button = event.target?.closest('button,input[type=submit],[role="button"]');
                  if (!button || !visible(button) || button.disabled || button.getAttribute('aria-disabled') === 'true' ||
                      button.closest('[role="dialog"],dialog,[aria-modal="true"]') ||
                      !/^(?:change password|save|تغيير كلمة المرور|تغيير كلمة السر|حفظ)$/i.test(buttonText(button).replace(/\s+/g, ' '))) return;
                  const inputs = Array.from(document.querySelectorAll('input[type=password]')).filter(visible);
                  if (inputs.length !== 2 && inputs.length !== 3) return;
                  const form = button.closest('form');
                  if (!form || inputs.some(el => el.closest('form') !== form || el.disabled || el.readOnly || !el.value)) return;
                  const candidate = inputs[inputs.length - 2].value;
                  if (candidate !== inputs[inputs.length - 1].value || hasManualSuccess() || errorText.test(document.body?.innerText || '')) return;
                  try { sessionStorage.setItem(manualKey, JSON.stringify({token: flowToken, password: candidate, time: Date.now()})); } catch (_) {}
                }, true);
              }
              let manual = null;
              try { manual = JSON.parse(sessionStorage.getItem(manualKey) || 'null'); } catch (_) {}
              if (manual && manual.token !== flowToken) {
                try { sessionStorage.removeItem(manualKey); } catch (_) {}
                manual = null;
              }
              if (manual && manual.token === flowToken) {
                if (typeof manual.password !== 'string' || !manual.password || !Number.isSafeInteger(manual.time) ||
                    Date.now() < manual.time || Date.now() - manual.time > 300000 || errorText.test(pageText)) {
                  try { sessionStorage.removeItem(manualKey); } catch (_) {}
                } else {
                  if (window.top === window && passwords.length === 0 && hasManualSuccess()) return JSON.stringify({status: 'manual_success', password: manual.password, url: location.href});
                  return 'manual_wait';
                }
              }

              const dialogVisible = el => {
                if (!el) return false;
                const rect = el.getBoundingClientRect();
                if (rect.width <= 1 || rect.height <= 1) return false;
                for (let node = el; node; node = node.parentElement) {
                  const style = getComputedStyle(node);
                  if (node.hidden || node.getAttribute('aria-hidden') === 'true' || style.display === 'none' ||
                      style.visibility === 'hidden' || style.visibility === 'collapse' || Number(style.opacity) === 0) return false;
                }
                return true;
              };
              if (${passwordChangeSubmitted} || submitLocked) {
                const dialogSelector = '[role="dialog"],dialog,[aria-modal="true"]';
                const dialogs = Array.from(document.querySelectorAll(dialogSelector)).filter(dialogVisible);
                for (const dialog of dialogs) {
                  const walker = document.createTreeWalker(dialog, NodeFilter.SHOW_TEXT);
                  const words = [];
                  while (walker.nextNode()) {
                    const parent = walker.currentNode.parentElement;
                    if (parent && parent.closest(dialogSelector) === dialog &&
                        !parent.closest('button,a,[role="button"]') && dialogVisible(parent)) words.push(walker.currentNode.nodeValue);
                  }
                  const description = (words.join(' ') + ' ' + (dialog.getAttribute('aria-label') || '')).replace(/\s+/g, ' ').trim();
                  if (!/\bchang(?:e|ing)\s+(?:your\s+)?password\b|\bconfirm\s+(?:your\s+)?password\s+change\b|تغيير كلمة (?:المرور|السر)/i.test(description)) continue;
                  const confirm = Array.from(dialog.querySelectorAll('button,[role="button"],input[type=button],input[type=submit]'))
                    .filter(el => el.closest(dialogSelector) === dialog && dialogVisible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true')
                    .find(el => /^(change password|تغيير كلمة المرور|تغيير كلمة السر)$/i.test(buttonText(el).replace(/\s+/g, ' ')));
                  const token = ${JSONObject.quote(confirmationToken)};
                  let issued = ${passwordConfirmationClickIssued} || window.__emPasswordConfirmationIssued === token;
                  try { issued = issued || sessionStorage.getItem('__emPasswordConfirmationIssued') === token; } catch (_) {}
                  if (!confirm || issued) return 'waiting_confirmation';
                  window.__emPasswordConfirmationIssued = token;
                  try { sessionStorage.setItem('__emPasswordConfirmationIssued', token); } catch (_) {}
                  try { confirm.click(); return 'confirmation_clicked'; } catch (_) {
                    delete window.__emPasswordConfirmationIssued;
                    try { sessionStorage.removeItem('__emPasswordConfirmationIssued'); } catch (_) {}
                    return 'waiting_confirmation';
                  }
                }
              }
              if (${passwordChangeSubmitted} || submitLocked) {
                if (errorText.test(pageText)) {
                  window.__emPasswordAutomationSubmitted = false;
                  window.__emPasswordAutomationReauthSubmitted = false;
                  try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); sessionStorage.removeItem('__emPasswordFlowReauth'); } catch(e) {}
                  return 'retry_error';
                }
                if (successText.test(normalizedPageText) || successText.test(liveText)) return 'success';
                return 'waiting_success';
              }

              if (passwords.length >= 3) {
                const ready = [fillField(passwords[0], 'current', currentPassword),
                  fillField(passwords[1], 'new', newPassword), fillField(passwords[2], 'confirm', newPassword)];
                if (!ready.every(Boolean)) return 'waiting';
                // Lock before clicking so another poll cannot submit again.
                try { if (sessionStorage.getItem('__emPasswordFlowSubmitted') === '1') return 'waiting_success'; sessionStorage.setItem('__emPasswordFlowSubmitted', '1'); } catch(e) { if (window.__emPasswordAutomationSubmitted === true) return 'waiting_success'; window.__emPasswordAutomationSubmitted = true; }
                window.__emPasswordAutomationSubmitted = true;
                const submit = formButtons.find(b => /change|تغيير|حفظ|save/.test(buttonText(b))) || formButtons.find(b => b.type === 'submit');
                if (submit && !submit.disabled) {
                  submit.click();
                  return 'submitted';
                }
                window.__emPasswordAutomationSubmitted = false;
                try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); } catch(e) {}
                return 'filled';
              }

              if (passwords.length === 2) {
                const ready = [fillField(passwords[0], 'new', newPassword), fillField(passwords[1], 'confirm', newPassword)];
                if (!ready.every(Boolean)) return 'waiting';
                // Lock before clicking so another poll cannot submit again.
                try { if (sessionStorage.getItem('__emPasswordFlowSubmitted') === '1') return 'waiting_success'; sessionStorage.setItem('__emPasswordFlowSubmitted', '1'); } catch(e) { if (window.__emPasswordAutomationSubmitted === true) return 'waiting_success'; window.__emPasswordAutomationSubmitted = true; }
                window.__emPasswordAutomationSubmitted = true;
                const submit = formButtons.find(b => /change|تغيير|حفظ|save/.test(buttonText(b))) || formButtons.find(b => b.type === 'submit');
                if (submit && !submit.disabled) {
                  submit.click();
                  return 'submitted';
                }
                window.__emPasswordAutomationSubmitted = false;
                try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); } catch(e) {}
                return 'filled';
              }

              if (passwords.length === 1) {
                if (reauthLocked || ${passwordReauthSubmitted}) return 'waiting_reauth';
                if (!fillField(passwords[0], 'reauth', currentPassword)) return 'waiting';
                const next = buttons.find(b => /next|التالي|continue|متابعة/.test(buttonText(b))) || buttons.find(b => b.type === 'submit');
                if (next && !next.disabled) {
                  window.__emPasswordAutomationReauthSubmitted = true;
                  try { sessionStorage.setItem('__emPasswordFlowReauth', '1'); } catch(e) {}
                  return (next.click(), 'reauth');
                }
                return 'one_password';
              }
              return 'waiting';
            })();
        """.trimIndent()

        view.evaluateJavascript(script) { result ->
            if (!isPasswordRun(view, confirmationToken)) return@evaluateJavascript
            val manualResult = runCatching {
                JSONObject(org.json.JSONArray("[${result ?: "null"}]").optString(0))
            }.getOrNull()
            if (manualResult?.optString("status") == "manual_success") {
                val submittedPassword = manualResult.optString("password")
                val observedAccount = accountKeyByWebView[view].orEmpty()
                if (submittedPassword.isNotBlank() && manualResult.optString("url") == view.url &&
                    passwordAutomationAccount.isNotBlank() && observedAccount.isNotBlank() &&
                    passwordAutomationAccount.equals(observedAccount, true) &&
                    view === currentWebView() && !automationActivityStopped && !googleVerificationActive && !googleVerificationCheckPending) {
                    passwordChangeSubmitted = true
                    completePasswordAutomationFromSuccess(view, submittedPassword)
                } else if (view === currentWebView() && !automationActivityStopped) {
                    view.postDelayed({ if (isPasswordRun(view, confirmationToken)) injectPasswordChangeScript(view) }, 180L)
                }
                return@evaluateJavascript
            }
            when (result?.trim('"')) {
                "submitted" -> {
                    // After submitting, never press the change button again unless
                    // Google explicitly reports a password-change error.
                    passwordChangeSubmitted = true
                    view.postDelayed({ if (passwordAutomationActive && confirmationToken == passwordConfirmationToken) injectPasswordChangeScript(view) }, 180L)
                }
                "confirmation_clicked" -> {
                    passwordChangeSubmitted = true
                    passwordConfirmationClickIssued = true
                    view.postDelayed({ if (passwordAutomationActive && confirmationToken == passwordConfirmationToken) injectPasswordChangeScript(view) }, 180L)
                }
                "retry_error" -> {
                    // Google explicitly reported that the password change failed.
                    // Only in this case is another attempt allowed.
                    passwordChangeSubmitted = false
                    passwordReauthSubmitted = false
                    passwordConfirmationClickIssued = false
                    passwordAutomationSuccessPending = false
                    passwordConfirmationToken = java.util.UUID.randomUUID().toString()
                    passwordFlowStartedForCurrentAutomation = false
                    val retryToken = passwordConfirmationToken
                    view.postDelayed({ if (passwordAutomationActive && retryToken == passwordConfirmationToken) injectPasswordChangeScript(view) }, 180L)
                }
                "filled", "reauth", "one_password", "waiting_reauth", "waiting", "manual_wait", "waiting_success", "waiting_confirmation" -> {
                    if (result?.trim('"') == "reauth") passwordReauthSubmitted = true
                    if (result?.trim('"') == "waiting_success" || result?.trim('"') == "waiting_confirmation") passwordChangeSubmitted = true
                    view.postDelayed({ if (passwordAutomationActive && confirmationToken == passwordConfirmationToken) injectPasswordChangeScript(view) }, 180L)
                }
                "success" -> {
                    passwordChangeSubmitted = true
                    if (view === currentWebView() && !automationActivityStopped) completePasswordAutomationFromSuccess(view)
                    else passwordAutomationSuccessPending = true
                }
            }
        }
    }

    private fun openAppStorageSettings() {
        val appDetails = android.content.Intent(
            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            android.net.Uri.fromParts("package", packageName, null)
        )
        runCatching { startActivity(appDetails) }
            .onFailure { startActivity(android.content.Intent(android.provider.Settings.ACTION_SETTINGS)) }
    }

    private fun homeUrl(): String =
        HOME_URL

    private fun captureTabThumbnail(tab: BrowserTab): Bitmap? {
        val webView = tab.webView
        if (webView.width <= 0 || webView.height <= 0) return tab.thumbnail
        return try {
            // Keep enough resolution for the large Chrome-style tab cards.
            val maxWidth = dp(600)
            val ratio = maxWidth.toFloat() / webView.width.toFloat()
            val bitmap = Bitmap.createBitmap(
                maxWidth,
                (webView.height * ratio).toInt().coerceAtLeast(dp(180)),
                Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(bitmap)
            canvas.scale(ratio, ratio)
            webView.draw(canvas)
            bitmap
        } catch (_: Throwable) {
            tab.thumbnail
        }
    }

    private fun showTabSwitcher() {
        if (tabs.isNotEmpty()) {
            tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
        }

        // Match the reference: a light full-screen Chrome-style tab switcher,
        // with two large cards per row and generous outer/inner spacing.
        val backgroundColor = Color.rgb(250, 250, 250)
        val cardColor = Color.WHITE
        val textColor = Color.rgb(45, 45, 45)
        val secondaryColor = Color.rgb(80, 80, 80)
        val activeGreen = Color.rgb(17, 107, 55)

        val dialogRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(28), dp(8), dp(28), dp(14))
            setBackgroundColor(backgroundColor)
        }
        lateinit var dialog: AlertDialog

        // Chrome-like top controls.
        val topBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        val more = TextView(this).apply {
            text = "⋮"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(textColor)
            setPadding(0, 0, 0, dp(4))
            setOnClickListener { dialog.dismiss(); drawerLayout.openDrawer(Gravity.END) }
        }
        topBar.addView(more, LinearLayout.LayoutParams(dp(44), dp(58)))

        // Keep the tab counter visually centered in the top bar after removing
        // the extra grid button.
        val leftSpacer = View(this)
        topBar.addView(leftSpacer, LinearLayout.LayoutParams(0, dp(58), 1f))

        val countPill = TextView(this).apply {
            text = tabs.size.toString()
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(textColor)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(9).toFloat()
                setColor(Color.WHITE)
                setStroke(dp(1), Color.rgb(235, 235, 235))
            }
        }
        topBar.addView(countPill, LinearLayout.LayoutParams(dp(26), dp(26)).apply {
            gravity = Gravity.CENTER_VERTICAL
            leftMargin = dp(2)
        })

        val spacer = View(this)
        topBar.addView(spacer, LinearLayout.LayoutParams(0, dp(58), 1f))

        val add = TextView(this).apply {
            text = "+"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(Color.rgb(16, 123, 61))
            }
            setOnClickListener {
                // Always create a genuinely new WebView. If the last tab was
                // closed, discard any stale persisted tab state before creating
                // the new home tab; otherwise Android/activity restoration can
                // resurrect the previously closed page.
                if (tabs.isEmpty()) {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .remove(KEY_TABS_STATE)
                        .remove(KEY_ACTIVE_TAB)
                        .apply()
                    contentFrame.removeAllViews()
                }
                addTab(homeUrl(), loadPage = true)
                dialog.dismiss()
            }
        }
        topBar.addView(add, LinearLayout.LayoutParams(dp(44), dp(44)))
        dialogRoot.addView(topBar, LinearLayout.LayoutParams(-1, dp(58)))

        val search = EditText(this).apply {
            hint = "Search tabs"
            textSize = 15f
            setSingleLine(true)
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            setTextColor(textColor)
            setHintTextColor(Color.rgb(90, 90, 90))
            setPadding(dp(14), 0, dp(14), 0)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(35).toFloat()
                setColor(Color.rgb(232, 232, 232))
            }
        }
        dialogRoot.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(2)
            leftMargin = dp(14)
            rightMargin = dp(14)
            bottomMargin = dp(12)
        })

        val grid = android.widget.GridLayout(this).apply {
            // Two columns so six tab cards (2 x 3) fit on the screen.
            columnCount = 2
            useDefaultMargins = false
            alignmentMode = android.widget.GridLayout.ALIGN_BOUNDS
        }
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(grid, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        dialogRoot.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun refreshGrid(filter: String = "") {
            grid.removeAllViews()
            val query = filter.trim().lowercase(java.util.Locale.getDefault())
            val visible = tabs.mapIndexedNotNull { index, tab ->
                val title = tab.title.ifBlank { "New tab" }
                if (query.isBlank() || title.lowercase(java.util.Locale.getDefault()).contains(query)) index to tab else null
            }

            // Six cards should be visible at once: 2 columns x 3 rows.
            // Keep compact gaps and let each card fill one half of the grid.
            val horizontalGap = dp(10)
            val verticalGap = dp(12)
            val availableWidth = resources.displayMetrics.widthPixels - dp(56)
            val cardWidth = ((availableWidth - horizontalGap) / 2).coerceAtLeast(dp(1))
            val cardHeight = dp(250)

            visible.forEachIndexed { position, pair ->
                val index = pair.first
                val tab = pair.second
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(0, 0, 0, 0)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(24).toFloat()
                        setColor(cardColor)
                        setStroke(
                            if (index == activeTab) dp(3) else dp(1),
                            if (index == activeTab) activeGreen
                             else Color.rgb(225, 225, 225)
                        )
                    }
                    elevation = dp(1).toFloat()
                    clipToOutline = true
                    isClickable = true
                    isFocusable = true
                    setOnClickListener {
                        if (tabs.isNotEmpty()) tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
                        activeTab = index
                        dialog.dismiss()
                        showActiveWebView()
                    }
                }

                val topRow = LinearLayout(this).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_LTR
                    setPadding(dp(8), 0, dp(8), 0)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadii = floatArrayOf(
                            dp(21).toFloat(), dp(21).toFloat(),
                            dp(21).toFloat(), dp(21).toFloat(),
                            0f, 0f, 0f, 0f
                        )
                        setColor(if (index == activeTab) activeGreen else cardColor)
                    }
                }

                val close = TextView(this).apply {
                    text = "×"
                    textSize = 28f
                    gravity = Gravity.CENTER
                    setTextColor(if (index == activeTab) Color.WHITE else secondaryColor)
                    setOnClickListener {
                        closeTab(index)
                        // Closing the final tab leaves the switcher open and truly
                        // empty: no placeholder card and the counter stays at zero.
                        countPill.text = tabs.size.toString()
                        refreshGrid(search.text?.toString() ?: "")
                    }
                }
                topRow.addView(close, LinearLayout.LayoutParams(dp(34), dp(46)))

                val tabTitle = TextView(this).apply {
                    text = tab.title.ifBlank { "New tab" }
                    textSize = 15.5f
                    setTextColor(if (index == activeTab) Color.WHITE else textColor)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER_VERTICAL
                }
                topRow.addView(tabTitle, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                    leftMargin = dp(4)
                    rightMargin = dp(4)
                })

                val favicon = ImageView(this).apply {
                    val icon = tab.webView.favicon
                    if (icon != null) {
                        setImageBitmap(icon)
                    } else {
                        setImageDrawable(ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.ic_em_browser))
                    }
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                }
                topRow.addView(favicon, LinearLayout.LayoutParams(dp(32), dp(46)))
                card.addView(topRow, LinearLayout.LayoutParams(-1, dp(46)))

                val thumbnail = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setBackgroundColor(Color.WHITE)
                    clipToOutline = true
                    outlineProvider = object : android.view.ViewOutlineProvider() {
                        override fun getOutline(view: View, outline: android.graphics.Outline) {
                            outline.setRoundRect(0, 0, view.width, view.height, dp(18).toFloat())
                        }
                    }
                    tab.thumbnail?.let { setImageBitmap(it) }
                    if (drawable == null) {
                        setImageDrawable(ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.ic_em_browser))
                        scaleType = ImageView.ScaleType.CENTER_INSIDE
                    }
                }
                card.addView(thumbnail, LinearLayout.LayoutParams(-1, 0, 1f).apply {
                    leftMargin = dp(5)
                    rightMargin = dp(5)
                    bottomMargin = dp(5)
                })

                val lp = android.widget.GridLayout.LayoutParams().apply {
                    width = cardWidth
                    height = cardHeight
                    columnSpec = android.widget.GridLayout.spec(position % 2, 1)
                    rowSpec = android.widget.GridLayout.spec(position / 2)
                    setMargins(
                        if (position % 2 == 0) 0 else horizontalGap / 2,
                        verticalGap / 2,
                        if (position % 2 == 1) 0 else horizontalGap / 2,
                        verticalGap / 2
                    )
                }
                grid.addView(card, lp)
            }


        }

        refreshGrid()
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = refreshGrid(s?.toString() ?: "")
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        dialog = AlertDialog.Builder(this)
            .setView(dialogRoot)
            .create()
        dialog.setOnDismissListener {
            // If the user leaves an empty tab switcher (Back/outside tap), return
            // to the browser home page by creating one fresh home tab. Selecting
            // an existing tab or using + already leaves tabs non-empty here.
            if (tabs.isEmpty()) addTab(homeUrl())
        }
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(backgroundColor)
            })
            dialog.window?.setStatusBarColor(backgroundColor)
            dialog.window?.setNavigationBarColor(backgroundColor)
            dialog.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(backgroundColor)
        })
        dialog.window?.setStatusBarColor(backgroundColor)
        dialog.window?.setNavigationBarColor(backgroundColor)
        dialog.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    }

    private data class CredentialRow(
        val email: String,
        val password: String,
        val twoFa: String,
        val recoveryEmail: String = "",
        val appPassword: String = ""
    )

    /**
     * Finds a Google Authenticator Base32 secret in plain text, grouped text, or
     * an otpauth:// URI. The value returned here is ONLY the secret itself.
     */
    // Any run of characters that is not part of a "word" (letters/digits) is treated as a
    // separator between the email / password / secret fields: spaces, tabs, commas, pipes,
    // colons, semicolons, dashes, dots, newlines... whatever the person happens to type.
    private val FIELD_SEPARATOR = Regex("[^A-Za-z0-9]+")
    private val BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
    // A Base32 secret split into short groups by ANY separator (space, dash, dot, underscore...),
    // e.g. "BKYN PGEY CDKH" or "BKYN-PGEY-CDKH" or "BKYN.PGEY.CDKH".
    private val GROUPED_SECRET = Regex("(?i)(?:[A-Z2-7]{2,8}[^A-Za-z0-9]+){2,}[A-Z2-7]{2,8}")
    private val CONTIGUOUS_SECRET = Regex("(?i)\\b[A-Z2-7]{16,64}\\b")
    private val OTPAUTH_URI = Regex("(?i)otpauth://\\S+")
    private val EMAIL_PATTERN = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
    private val APP_PASSWORD_ROW_PATTERN = Regex("(?i)[a-z0-9]{4}(?:\\s+[a-z0-9]{4}){3}")

    private fun extractBase32Secret(value: String): String? {
        val raw = value.trim()
        if (raw.isBlank()) return null

        parseOtpAuth(raw)?.secret?.let { return it }

        val grouped = GROUPED_SECRET.find(raw)?.value
            ?.replace(FIELD_SEPARATOR, "")
            ?.uppercase(Locale.US)
        if (!grouped.isNullOrBlank() && grouped.length in 16..64 && grouped.all { it in BASE32_ALPHABET }) {
            return grouped
        }

        val contiguous = CONTIGUOUS_SECRET.find(raw)?.value?.uppercase(Locale.US)
        return contiguous?.takeIf { it.all { ch -> ch in BASE32_ALPHABET } }
    }

    /**
     * Accepts a credential row pasted into the email/address field, in *any* order and with
     * *any* separator between the fields (space, tab, comma, pipe, colon, dash, newline...):
     *
     *   email + password + secret          email + secret + password
     *   email + secret only                email + password only
     *   email + password + recovery email  email + recovery email + password
     *   email only (nothing extracted)
     *
     * The main email is identified first (the first email found, wherever it appears).  A
     * second email anywhere else in the text, if present, is the recovery email. A Base32/
     * otpauth value is identified next as the authenticator secret (grouped or contiguous,
     * wherever it appears). Whatever text is left over — stripped of separators — is the
     * current password. The 2FA value stored by the app is ONLY the Base32 secret; no
     * otpauth:// prefix or other generated-link text is placed in the 2FA Link field.
     */
    private fun parseCredentialRow(raw: String): CredentialRow? {
        val text = raw.trim()
        if (text.isBlank()) return null

        // Prefer the explicit tab-delimited export format. It protects passwords exactly as
        // pasted, even when they contain punctuation that resembles a secret separator.
        // Supported forms: email<TAB>password[<TAB>2FA or recovery][<TAB>app password].
        if (raw.contains('\t')) {
            val columns = raw.trimEnd('\r', '\n').split('\t').toMutableList()
            while (columns.isNotEmpty() && columns.last().isBlank()) columns.removeAt(columns.lastIndex)
            if (columns.isNotEmpty()) {
                val emailMatch = EMAIL_PATTERN.find(columns[0].trim())
                if (emailMatch != null) {
                    val email = emailMatch.value.lowercase(Locale.US)
                    var password = columns.getOrNull(1).orEmpty()
                    var twoFa = ""
                    var recovery = ""
                    var appPassword = ""
                    val passwordSecret = extractBase32Secret(password)
                    val passwordSecretRange = when {
                        OTPAUTH_URI.containsMatchIn(password) -> OTPAUTH_URI.find(password)?.range
                        GROUPED_SECRET.containsMatchIn(password) -> GROUPED_SECRET.find(password)?.range
                        else -> CONTIGUOUS_SECRET.find(password)?.range
                    }
                    val passwordRemainder = passwordSecretRange?.let { password.removeRange(it) }.orEmpty()
                    if (passwordSecret != null && passwordRemainder.none { it.isLetterOrDigit() }) {
                        twoFa = passwordSecret
                        password = ""
                    }
                    val creationTime = Regex("(?:(?:January|February|March|April|May|June|July|August|September|October|November|December) )?(?:19|20)\\d{2}", RegexOption.IGNORE_CASE)
                    val isAccountExport = columns.size >= 5 &&
                        (columns[4].isBlank() || creationTime.matches(columns[4])) &&
                        columns.drop(5).all {
                            it.isBlank() || it.matches(Regex("[0-9]{8}")) ||
                                it.equals("YouTube premium", true) || it.equals("ads available", true) ||
                                it.equals("ads not available", true)
                        }
                    // Exported creation times, availability and backup codes are not passwords.
                    val fields = if (isAccountExport) columns.drop(2).take(2) else columns.drop(2)
                    for ((columnIndex, column) in fields.withIndex()) {
                        val candidate = column.trim()
                        if (candidate.isBlank()) continue
                        val emailInColumn = EMAIL_PATTERN.find(candidate)
                        val secret = extractBase32Secret(candidate)
                        when {
                            emailInColumn != null && emailInColumn.range.first == 0 && emailInColumn.range.last == candidate.lastIndex ->
                                recovery = emailInColumn.value.lowercase(Locale.US)
                            columnIndex >= 1 && APP_PASSWORD_ROW_PATTERN.matches(candidate) -> appPassword = candidate
                            secret != null && twoFa.isBlank() -> twoFa = secret
                            else -> if (password.isBlank()) password = column
                        }
                    }
                    return CredentialRow(email, password, twoFa, recovery, appPassword)
                }
            }
        }

        val emailMatch = EMAIL_PATTERN.find(text) ?: return null
        val email = emailMatch.value.lowercase(Locale.US)
        var remainder = text.removeRange(emailMatch.range).trim()
        if (remainder.isBlank()) return null

        // A second email anywhere in what's left is a recovery email (any provider: Gmail,
        // Yahoo, Outlook...), not part of the password/secret.
        val recoveryMatch = EMAIL_PATTERN.find(remainder)
        val recoveryEmail = recoveryMatch?.value?.lowercase(Locale.US).orEmpty()
        if (recoveryMatch != null) {
            remainder = remainder.removeRange(recoveryMatch.range).trim()
        }

        val secret = extractBase32Secret(remainder)
        if (secret != null) {
            val secretRange = when {
                OTPAUTH_URI.containsMatchIn(remainder) -> OTPAUTH_URI.find(remainder)?.range
                GROUPED_SECRET.containsMatchIn(remainder) -> GROUPED_SECRET.find(remainder)?.range
                else -> CONTIGUOUS_SECRET.find(remainder)?.range
            }
            // Remove only the authenticator value. Punctuation inside the password
            // is data and must never be treated as a separator.
            val password = if (secretRange != null) {
                remainder.removeRange(secretRange).trim(' ', '\t', '\r', '\n')
            } else {
                remainder
            }
            return CredentialRow(email, password, secret, recoveryEmail)
        }

        // No authenticator secret: preserve the password exactly, including
        // @ # $ & ! / . - _ and internal spaces.
        val password = remainder.trim(' ', '\t', '\r', '\n')
        return CredentialRow(email, password, "", recoveryEmail)
    }

    private fun recoveryTargetForAccount(account: String): String {
        val raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_RECOVERY_TARGETS, "{}").orEmpty()
        return runCatching { JSONObject(raw).optString(account.trim().lowercase(Locale.US)) }.getOrDefault("")
    }

    private fun saveRecoveryTarget(account: String, target: String) {
        val key = account.trim().lowercase(Locale.US)
        if (key.isBlank()) return
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val targets = runCatching { JSONObject(prefs.getString(KEY_RECOVERY_TARGETS, "{}").orEmpty()) }.getOrElse { JSONObject() }
        val value = target.trim()
        if (targets.optString(key) == value) return
        if (devicesAutomationActive && devicesAutomationAccount == key) recoveryActionPermit = ""
        if (value.isBlank()) targets.remove(key) else targets.put(key, value)
        prefs.edit().putString(KEY_RECOVERY_TARGETS, targets.toString()).apply()
        clearStageCompleted("recovery_set", key)
    }

    private fun saveCredentialRow(row: CredentialRow) {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val editor = prefs.edit()
        val account = row.email.trim().lowercase(Locale.US)
        var stagedRow = row
        if (row.password.isNotBlank() || row.appPassword.isBlank()) {
            passwordAutomationCurrent = row.password
            editor.putString(KEY_PASSWORD_CURRENT, row.password)
        }
        if (row.twoFa.isNotBlank()) {
            val secret = extractBase32Secret(row.twoFa) ?: row.twoFa
            editor.putString(KEY_TWO_FA_LINK, secret)
                .putString(KEY_TOTP_SECRET, secret)
                .putString(KEY_TOTP_OWNER, account)
                .putString(KEY_TOTP_LABEL, "2FA")
                .putString(KEY_TOTP_ALGORITHM, "SHA1")
                .putInt(KEY_TOTP_DIGITS, 6)
                .putLong(KEY_TOTP_PERIOD, 30L)
                .remove("totp_uri")
            authenticatorSecret = secret
            authenticatorLabel = "2FA"
            authenticatorAlgorithm = "SHA1"
            authenticatorDigits = 6
            authenticatorPeriod = 30L
            authenticatorOtpauthUri = ""
        } else {
            val activeSecret = prefs.getString(KEY_TWO_FA_LINK, "").orEmpty()
                .ifBlank { prefs.getString(KEY_TOTP_SECRET, "").orEmpty() }
                .ifBlank { authenticatorSecret }
            val owner = prefs.getString(KEY_TOTP_OWNER, null)
            val knownOwners = mutableSetOf<String>()
            if (owner == null && activeSecret.isNotBlank()) {
                val staged = loadStagedSignInCredentials()
                for (key in staged.keys()) {
                    val item = staged.optJSONObject(key) ?: continue
                    val secret = item.optString("twoFa").ifBlank { item.optString("secret") }
                    if (secret.isNotBlank() && formatSavedAuthenticatorKey(secret) == formatSavedAuthenticatorKey(activeSecret)) {
                        knownOwners.add(key.lowercase(Locale.US))
                    }
                }
                val accounts = loadAuthenticatorAccounts()
                for (i in 0 until accounts.length()) {
                    val item = accounts.optJSONObject(i) ?: continue
                    val secret = item.optString("twoFa").ifBlank { item.optString("secret") }
                    if (secret.isNotBlank() && formatSavedAuthenticatorKey(secret) == formatSavedAuthenticatorKey(activeSecret)) {
                        knownOwners.add(item.optString("account").lowercase(Locale.US))
                    }
                }
            }
            // An unowned legacy key can be associated with the next account unless it is known to belong elsewhere.
            val mayBind = owner == "" || owner.equals(account, true) ||
                (owner == null && (knownOwners.isEmpty() || account in knownOwners))
            if (activeSecret.isNotBlank() && mayBind) {
                editor.putString(KEY_TOTP_OWNER, account)
                stagedRow = row.copy(twoFa = activeSecret)
            } else if (activeSecret.isNotBlank()) {
                editor.remove(KEY_TWO_FA_LINK).remove(KEY_TOTP_SECRET).remove(KEY_TOTP_LABEL)
                    .remove(KEY_TOTP_ALGORITHM).remove(KEY_TOTP_DIGITS).remove(KEY_TOTP_PERIOD)
                    .remove("totp_uri").remove(KEY_TOTP_OWNER)
                authenticatorSecret = ""
                authenticatorLabel = ""
                authenticatorAlgorithm = "SHA1"
                authenticatorDigits = 6
                authenticatorPeriod = 30L
                authenticatorOtpauthUri = ""
            }
        }
        // Recovery is kept only in the dedicated Current Recovery field, never in Accounts.
        // Clear it for a newly imported row without recovery so an older account's value cannot leak.
        recoveryEmailValue = row.recoveryEmail
        editor.putString(KEY_RECOVERY_EMAIL_VALUE, row.recoveryEmail)
        editor.apply()

        saveRecoveryTarget(account, row.recoveryEmail)
        saveStagedSignInCredentials(stagedRow)
        // Sign-in credentials stay available for autofill, but only confirmed account
        // changes are written to the separate Accounts change log.
    }

    private fun loadStagedSignInCredentials(): JSONObject {
        val raw = getSharedPreferences(PREFS, MODE_PRIVATE)
            .getString(KEY_STAGED_SIGN_IN_CREDENTIALS, "{}") ?: "{}"
        return runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
    }

    private fun stagedSignInCredentials(account: String): JSONObject? =
        loadStagedSignInCredentials().optJSONObject(account.lowercase(Locale.US))

    private fun saveStagedSignInCredentials(row: CredentialRow) {
        if (row.email.isBlank()) return
        val account = row.email.lowercase(Locale.US)
        val credentials = loadStagedSignInCredentials()
        val item = credentials.optJSONObject(account) ?: JSONObject()
        item.put("account", account)
        if (row.password.isNotBlank()) item.put("password", row.password)
        if (row.twoFa.isNotBlank()) {
            val secret = formatSavedAuthenticatorKey(extractBase32Secret(row.twoFa) ?: row.twoFa)
            item.put("twoFa", secret)
            item.put("secret", secret)
        }
        if (row.appPassword.isNotBlank()) item.put("appPassword", row.appPassword)
        credentials.put(account, item)
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_STAGED_SIGN_IN_CREDENTIALS, credentials.toString())
            .apply()
    }

    private fun clearStagedSignInCredentials(account: String) {
        if (account.isBlank()) return
        val credentials = loadStagedSignInCredentials()
        credentials.remove(account.lowercase(Locale.US))
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_STAGED_SIGN_IN_CREDENTIALS, credentials.toString())
            .apply()
    }

    private fun updateSavedAccountRecovery(email: String, accountOverride: String? = null) {
        // Recovery belongs only in the dedicated Current Recovery field.
        // Do not duplicate it into the Accounts list or account export.
        val accountEmail = email.lowercase(Locale.US)
        recoveryEmailValue = accountEmail
        getSharedPreferences(PREFS, MODE_PRIVATE)
            .edit()
            .putString(KEY_RECOVERY_EMAIL_VALUE, accountEmail)
            .apply()
    }

    private fun loadAddress(raw: String) {
        val input = raw.trim()
        if (input.isBlank()) return

        // A pasted credential row is data, not a search query. Keep its values for
        // autofill and leave only the email visible; it is not an account change.
        parseCredentialRow(input)?.let { row ->
            saveCredentialRow(row)
            addressBar.setText(row.email)
            addressBar.setSelection(addressBar.text.length)
            currentWebView()?.loadUrl(withSelectedLanguage("https://accounts.google.com/"))
            addressBar.clearFocus()
            return
        }
        val url = if (android.util.Patterns.EMAIL_ADDRESS.matcher(input).matches()) {
            "https://accounts.google.com/"
        } else if (android.util.Patterns.WEB_URL.matcher(input).matches() &&
            (input.startsWith("http://") || input.startsWith("https://"))) {
            input
        } else if (input.contains(".") && !input.contains(" ")) {
            "https://$input"
        } else {
            "https://www.google.com/search?q=" + android.net.Uri.encode(input)
        }
        progressAnimator?.cancel()
        pageProgress.progress = 0
        pageProgress.visibility = View.VISIBLE
        currentWebView()?.loadUrl(withSelectedLanguage(url))
        addressBar.clearFocus()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun addTab(
        url: String,
        restoredProfileName: String? = null,
        loadPage: Boolean = true,
        applyAccountRecoveryMode: Boolean = true
    ) {
        if (tabs.isNotEmpty()) {
            tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
        }

        val profileName = restoredProfileName ?: if (!hasCreatedFirstTabThisSession) {
            // Only the very first tab of this app session gets the shared default profile
            // (so an existing Google Account session is available right away on launch).
            // A tab opened after the list was emptied is a fresh "new tab" the person asked
            // for, not a continuation of whatever was open before, so it must not reuse that.
            Profile.DEFAULT_PROFILE_NAME
        } else {
            // Every new tab gets its own persistent WebView profile. Cookies,
            // local storage and other site data are therefore not shared with
            // the first tab or with any other tab.
            "em_tab_${System.currentTimeMillis()}_${tabs.size}"
        }
        hasCreatedFirstTabThisSession = true

        val webView = WebView(this)
        applyProfile(webView, profileName)
        val tab = BrowserTab(webView = webView, profileName = profileName)
        tabs.add(tab)
        // A new tab is a new automation run. Settings remain enabled, but the
        // master Automation switch controls whether execution starts automatically
        // once this tab reaches Google/Gmail.
        automationCompletedForCurrentAccount = false
        automationHasRunInCurrentGoogleSession = false
        completedAccountKey = ""
        currentAccountKey = ""
        if (!passwordAutomationActive) clearPasswordAutomationState()
        stopAppPasswordAutomation()
        stopAdsAutomation()
        stopYoutubePremiumAutomation()
        stopCreationTimeAutomation()
        stopBackupAutomation()
        recoveryEmailAutomationActive = false
        phoneNumbersAutomationActive = false
        phoneNumbersDeletePending = false
        phoneNumbersDeleteConfirmIssued = false
        phoneNumbersDeleteCountBeforeClick = 0
        phoneNumbersNoDeleteSince = 0L
        recoveryRemovalAwaitingVerification = false
        combinedAutomationWaitingForPassword = false
        recoveryDirectRetryCount = 0
        twoStepAutomationActive = false
        twoStepAutomationStage = "idle"
        twoStepAutomationRefreshDone = false
        twoStepAutomationTurnOnClicked = false
        configureWebView(webView)
        activeTab = tabs.lastIndex
        showActiveWebView(syncAccountRecovery = false)
        // A newly opened tab must not leave the URL field focused. Keep focus on
        // the browser content/root until the user explicitly taps an input.
        rootLayout.post {
            if (::addressBar.isInitialized) addressBar.clearFocus()
            rootLayout.requestFocus()
        }
        progressAnimator?.cancel()
        pageProgress.progress = 0
        pageProgress.visibility = View.VISIBLE
        if (loadPage) {
            val startRecovery = accountRecoveryModeEnabled && applyAccountRecoveryMode
            if (startRecovery) tab.accountRecoveryModeApplied = true
            webView.loadUrl(withSelectedLanguage(if (startRecovery) ACCOUNT_RECOVERY_URL else url))
        }
        updateChromeBar()
        saveTabsState()
    }

    private fun saveTabsState() {
        // An empty tab list is meaningful: persist the empty state by removing
        // the previous snapshot, so a closed tab cannot reappear on restart.
        if (tabs.isEmpty()) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .remove(KEY_TABS_STATE)
                .remove(KEY_ACTIVE_TAB)
                .apply()
            return
        }

        val array = JSONArray()
        tabs.forEach { tab ->
            val url = tab.webView.url?.takeIf { it.isNotBlank() } ?: HOME_URL
            array.put(JSONObject().apply {
                put("url", url)
                put("title", tab.title)
                put("profile", tab.profileName)
                put("accountRecoveryModeApplied", tab.accountRecoveryModeApplied)
            })
        }

        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_TABS_STATE, array.toString())
            .putInt(KEY_ACTIVE_TAB, activeTab.coerceIn(0, tabs.lastIndex))
            .apply()
    }

    private fun restoreTabsState(): Boolean {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val raw = prefs.getString(KEY_TABS_STATE, null) ?: return false
        return runCatching {
            val array = JSONArray(raw)
            if (array.length() == 0) return false

            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val url = item.optString("url", HOME_URL).ifBlank { HOME_URL }
                val title = item.optString("title", "New tab").ifBlank { "New tab" }
                val profile = item.optString("profile", Profile.DEFAULT_PROFILE_NAME)
                    .ifBlank { Profile.DEFAULT_PROFILE_NAME }
                addTab(url, profile, loadPage = true, applyAccountRecoveryMode = false)
                tabs.last().title = title
                tabs.last().accountRecoveryModeApplied = item.optBoolean("accountRecoveryModeApplied", false)
            }

            activeTab = prefs.getInt(KEY_ACTIVE_TAB, 0).coerceIn(0, tabs.lastIndex)
            showActiveWebView()
            updateChromeBar()
            true
        }.getOrElse {
            prefs.edit().remove(KEY_TABS_STATE).remove(KEY_ACTIVE_TAB).apply()
            false
        }
    }

    private fun applyProfile(webView: WebView, profileName: String) {
        if (profileName == Profile.DEFAULT_PROFILE_NAME) return
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            WebViewCompat.setProfile(webView, profileName)
        }
    }

    private fun isCurrentCredentialPage(view: WebView, document: CredentialDocument, pageUrl: String): Boolean {
        val host = credentialHost(android.net.Uri.parse(pageUrl)) ?: return false
        return credentialDocuments[view] === document && credentialEnabledViews[view] == true &&
            !isResettingBrowser && !isFinishing && !isDestroyed && !automationActivityStopped &&
            view === currentWebView() && tabs.any { it.webView === view } && view.url == pageUrl &&
            credentialHost(android.net.Uri.parse(document.committedUrl.orEmpty())) == host
    }

    private fun initializeCredentialMessageClient(view: WebView) {
        val document = credentialDocuments[view] ?: return
        val pageUrl = view.url ?: return
        if (!isCurrentCredentialPage(view, document, pageUrl)) return
        val token = document.token ?: java.util.UUID.randomUUID().toString().also { document.token = it }
        val attempt = ++document.attempt
        val candidate = java.util.UUID.randomUUID().toString()
        val probe = """
            (function() {
              if (window.top !== window || location.href !== ${JSONObject.quote(pageUrl)} ||
                  !['https://accounts.google.com', 'https://myaccount.google.com'].includes(location.origin)) return null;
              if (!document.__emCredentialDocumentId) {
                Object.defineProperty(document, '__emCredentialDocumentId', {value: ${JSONObject.quote(candidate)}});
              }
              return document.__emCredentialDocumentId;
            })();
        """.trimIndent()
        view.evaluateJavascript(probe) { result ->
            if (credentialDocuments[view] !== document) return@evaluateJavascript
            if (view.url != pageUrl) {
                initializeCredentialMessageClient(view)
                return@evaluateJavascript
            }
            if (!isCurrentCredentialPage(view, document, pageUrl)) return@evaluateJavascript
            val documentId = runCatching { JSONArray("[$result]").opt(0) as? String }.getOrNull()
            if (documentId.isNullOrEmpty()) return@evaluateJavascript
            installCredentialMessageClient(view, pageUrl, token, documentId, document, attempt)
        }
    }

    private fun installCredentialMessageClient(view: WebView, pageUrl: String, token: String, documentId: String, document: CredentialDocument, attempt: Long) {
        val script = """
            (function() {
              if (window.top !== window || location.href !== ${JSONObject.quote(pageUrl)} ||
                  !['https://accounts.google.com', 'https://myaccount.google.com'].includes(location.origin) ||
                  document.__emCredentialDocumentId !== ${JSONObject.quote(documentId)} ||
                  !document.documentElement || !window.EMCredential) return false;
              const token = ${JSONObject.quote(token)};
              const generation = ${document.generation};
              const existing = window.__emCredentialClient;
              if (existing) {
                if (existing.documentId !== ${JSONObject.quote(documentId)} || existing.generation > generation) return false;
                // A cancelled navigation can leave this document and its pending requests alive.
                existing.token = token;
                existing.generation = generation;
                window.EMCredential.onmessage = existing.onmessage;
                window.__emCredentialRequest = existing.request;
                return true;
              }
              const client = {token, generation, documentId: ${JSONObject.quote(documentId)}};
              const pending = new Map();
              let sequence = 0;
              client.onmessage = event => {
                let reply;
                try { reply = JSON.parse(event.data); } catch (e) { return; }
                const entry = pending.get(reply.id);
                if (!entry || typeof reply.value !== 'string') return;
                pending.delete(reply.id);
                clearTimeout(entry.timer);
                entry.resolve(reply.value);
              };
              client.request = (operation, value) => new Promise(resolve => {
                const token = client.token;
                const id = token + '-' + (++sequence);
                const timer = setTimeout(() => { pending.delete(id); resolve(''); }, 3000);
                pending.set(id, {resolve, timer});
                try {
                  window.EMCredential.postMessage(JSON.stringify({id, operation, value, token, documentId: client.documentId, url: location.href}));
                } catch (e) {
                  clearTimeout(timer);
                  pending.delete(id);
                  resolve('');
                }
              });
              window.__emCredentialClient = client;
              window.EMCredential.onmessage = client.onmessage;
              window.__emCredentialRequest = client.request;
              return true;
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (credentialDocuments[view] !== document) return@evaluateJavascript
            if (view.url != pageUrl) {
                initializeCredentialMessageClient(view)
                return@evaluateJavascript
            }
            if (result == "true" && attempt >= document.confirmedAttempt &&
                isCurrentCredentialPage(view, document, pageUrl)) {
                document.confirmedAttempt = attempt
                document.documentId = documentId
                injectCredentialAutofill(view)
                injectCredentialRowHook(view)
            }
        }
    }

    /**
     * Watches Google's own "Email or phone" field for a pasted credential row
     * (email + password and/or secret, in any order/separator) and, when found,
     * hands the password/secret to the app via [CredentialBridge] and replaces the
     * field's content with just the email — mirroring what already happens when the
     * same row is pasted into the browser's own address bar.
     */
    private fun injectCredentialRowHook(view: WebView) {
        if (credentialHost(android.net.Uri.parse(view.url.orEmpty())) == null) return

        val script = """
            (function() {
              if (window.top !== window || !['https://accounts.google.com', 'https://myaccount.google.com'].includes(location.origin)) return;
              if (window.__emCredentialHooked) return;
              window.__emCredentialHooked = true;

              const setValue = (el, value) => {
                const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
                if (setter) setter.call(el, value); else el.value = value;
                el.dispatchEvent(new Event('input', {bubbles:true}));
                el.dispatchEvent(new Event('change', {bubbles:true}));
              };

              const handle = (el, raw, before) => {
                if (typeof window.__emCredentialRequest !== 'function' || !raw || el.__emRowPending === raw) return;
                el.__emRowPending = raw;
                const url = location.href;
                const version = el.__emRowVersion || 0;
                window.__emCredentialRequest('processRow', raw).then(email => {
                  if (email && el.isConnected && location.href === url && el.value === before &&
                      (el.__emRowVersion || 0) === version) setValue(el, email);
                }).finally(() => { if (el.__emRowPending === raw) el.__emRowPending = null; });
              };

              const attach = (el) => {
                if (!el || el.__emHooked) return;
                el.__emHooked = true;
                el.addEventListener('input', () => {
                  el.__emRowVersion = (el.__emRowVersion || 0) + 1;
                  handle(el, el.value, el.value);
                });
                el.addEventListener('paste', event => {
                  const raw = event.clipboardData?.getData('text/plain') || '';
                  const email = raw.match(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/);
                  if (email && raw.trim() !== email[0]) {
                    // Do not briefly put a full credential row into the Google identifier field.
                    event.preventDefault();
                    if (typeof window.__emCredentialRequest === 'function') handle(el, raw, el.value);
                    else setValue(el, email[0]);
                  } else {
                    setTimeout(() => handle(el, el.value, el.value), 0);
                  }
                });
              };

              const scan = () => {
                document.querySelectorAll(
                  'input[type="email"], input[name="identifier"], input[autocomplete="username"]'
                ).forEach(attach);
              };

              scan();
              new MutationObserver(scan).observe(document.documentElement, {childList: true, subtree: true});
            })();
        """.trimIndent()

        view.evaluateJavascript(script, null)
    }

    /**
     * Keeps the Google password field and the TOTP "Enter code" field filled for as long as
     * the person is on an accounts.google.com / myaccount.google.com page — however many
     * screens the sign-in flow steps through. Unlike a one-shot fill right after page load,
     * this installs a MutationObserver plus a 1s poll so it still catches fields that appear
     * later via client-side navigation (Google's sign-in flow doesn't always trigger a fresh
     * page load between the email, password and 2FA screens), and keeps the code field
     * refreshed as the TOTP code rotates every ~30s.
     */
    private fun injectCredentialAutofill(view: WebView) {
        if (credentialHost(android.net.Uri.parse(view.url.orEmpty())) == null) return

        val script = """
            (function() {
              if (window.top !== window || !['https://accounts.google.com', 'https://myaccount.google.com'].includes(location.origin)) return;
              if (window.__emAutofillHooked) return;
              window.__emAutofillHooked = true;

              const visible = el => {
                if (!el) return false;
                const r = el.getBoundingClientRect();
                if (r.width <= 1 || r.height <= 1) return false;
                for (let node = el; node; node = node.parentElement) {
                  const s = getComputedStyle(node);
                  if (node.hidden || s.display === 'none' || s.visibility === 'hidden' || s.visibility === 'collapse' || Number(s.opacity) === 0) return false;
                }
                return true;
              };
              const setValue = (el, value) => {
                const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
                if (setter) setter.call(el, value); else el.value = value;
                el.dispatchEvent(new Event('input', {bubbles:true}));
                el.dispatchEvent(new Event('change', {bubbles:true}));
              };
              const findPasswordInput = () =>
                Array.from(document.querySelectorAll('input[type="password"], input[name="Passwd"]'))
                  .find(el => visible(el) && ((el.getAttribute('aria-label') || '').toLowerCase().includes('enter your password') || el.name === 'Passwd'));
              const activePromptText = () => {
                if (!document.body) return '';
                const parts = [];
                const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
                while (walker.nextNode()) {
                  const parent = walker.currentNode.parentElement;
                  if (!parent || !visible(parent) || parent.closest('button, a, select, option, summary, [onclick], [role="button"], [role="link"], [role="option"], [role="radio"], [role="menu"], [role="menuitem"], [role="menuitemradio"], [role="listbox"]')) continue;
                  const part = (walker.currentNode.nodeValue || '').trim();
                  if (/^(?:or\b|alternatively\b|another (?:way|method)\b|other (?:ways?|methods?)\b|try\b)/i.test(part) || /\b(?:instead|as an alternative)\b/i.test(part)) continue;
                  let alternative = false;
                  for (let node = parent; node && node !== document.body; node = node.parentElement) {
                    if (!node.matches('p, div, section, li, h1, h2, h3, [role="heading"]') || node.querySelector('input')) continue;
                    const text = (node.innerText || '').trim();
                    if (/^(?:or\b|alternatively\b|another (?:way|method)\b|other (?:ways?|methods?)\b|try\b)/i.test(text) || /\b(?:instead|as an alternative)\b/i.test(text)) {
                      alternative = true;
                    }
                    break;
                  }
                  if (!alternative) parts.push(walker.currentNode.nodeValue);
                }
                return parts.join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
              };
              const findCodeInput = () => {
                // The setup automation owns this field, including replies already in flight.
                if (location.origin === 'https://myaccount.google.com' &&
                    /^\/two-step-verification\/authenticator\/?$/i.test(location.pathname) &&
                    window.__emAuthenticatorSetupClickIssued === true) return null;
                const prompt = activePromptText();
                const otherMethod = /\b(?:backup(?:\s+codes?)?|recovery\s+codes?|sms|text\s+messages?|texted)\b|\b(?:sent|send|receive)\b.{0,80}\b(?:phone|mobile)\b/i.test(prompt);
                const hasBackupPrompt = Array.from(document.querySelectorAll('input')).some(el => visible(el) &&
                  /backup|recovery/.test(((el.id || '') + ' ' + (el.name || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase()));
                if (otherMethod || hasBackupPrompt) return null;
                const isAuthenticator = /google authenticator|authenticator app/i.test(prompt);
                const candidates = Array.from(document.querySelectorAll('input')).filter(el => {
                  if (!visible(el) || el.matches(':disabled') || el.readOnly || el.type === 'hidden' || el.type === 'password') return false;
                  const id = (el.id || '').toLowerCase();
                  const name = (el.name || '').toLowerCase();
                  const label = (el.getAttribute('aria-label') || '').trim().toLowerCase();
                  if (id === 'backupcodepin' || /backup|recovery|sms|text message/.test(label + ' ' + name + ' ' + id)) return false;
                  return id === 'totppin' || name === 'totppin' ||
                    (isAuthenticator && (label === 'enter code' || label === 'verification code'));
                });
                if (candidates.length !== 1) return null;
                const el = candidates[0];
                const identity = [(el.id || '').toLowerCase(), (el.name || '').toLowerCase()];
                return {el, canRemount: identity.some(Boolean), signature: JSON.stringify([location.href, identity, (el.getAttribute('aria-label') || '').trim().toLowerCase(), prompt])};
              };
              const findRecoveryEmailInput = () =>
                document.querySelector('#knowledge-preregistered-email-response') ||
                Array.from(document.querySelectorAll('input')).find(el => visible(el) &&
                  ((el.getAttribute('aria-label') || '').toLowerCase() === 'enter recovery email address' ||
                   (el.getAttribute('name') || '').toLowerCase() === 'knowledgepreregisteredemailresponse'));

              const requestFill = (el, operation, stillEligible) => {
                if (typeof window.__emCredentialRequest !== 'function' || el.__emFillPending) return;
                el.__emFillPending = true;
                let edited = false;
                const onInput = () => {
                  edited = true;
                  if (operation !== 'totp') el.__emFilled = true;
                };
                const url = location.href;
                el.addEventListener('input', onInput);
                window.__emCredentialRequest(operation).then(value => {
                  if (value && !edited && el.isConnected && location.href === url && stillEligible()) {
                    if (operation !== 'totp') el.__emFilled = true;
                    if (el.value !== value) setValue(el, value);
                  }
                }).finally(() => {
                  el.removeEventListener('input', onInput);
                  el.__emFillPending = false;
                });
              };

              const fillPassword = () => {
                const el = findPasswordInput();
                // Fill once per field: respects anything the person types/clears afterward.
                if (el && !el.value && !el.__emFilled) {
                  requestFill(el, 'password', () => findPasswordInput() === el && !el.value && !el.__emFilled);
                }
              };

              let totpState = null;
              window.__emReadyAutofilledTotp = () => {
                const challenge = findCodeInput();
                const state = totpState;
                if (!challenge || !state || state.el !== challenge.el || state.signature !== challenge.signature ||
                    state.confirmedSignature !== challenge.signature ||
                    state.manual || state.last === null || challenge.el.value !== state.last ||
                    !challenge.el.isConnected || !Number.isSafeInteger(state.expiresAt) || Date.now() >= state.expiresAt) return null;
                return {el: challenge.el, expiresAt: state.expiresAt};
              };
              const fillTotp = () => {
                const challenge = findCodeInput();
                if (!challenge || typeof window.__emCredentialRequest !== 'function') return;
                const {el, signature, canRemount} = challenge;
                let state = totpState;
                if (!state || state.el !== el) {
                  const remount = state && canRemount && !state.el.isConnected && state.signature === signature &&
                    (state.manual || Date.now() - state.lastSeen <= 3000);
                  if (remount) {
                    if (state.el.value !== (state.last || '')) state.manual = true;
                    if (el.value && el.value !== state.last) state.manual = true;
                    if (state.manual || !el.value) state.last = null;
                    state.el = el;
                    state.pending = null;
                  } else {
                    state = totpState = {el, signature, manual: !!el.value, writing: false, last: null, pending: null};
                  }
                  el.addEventListener('input', () => {
                    if (state.el === el && !state.writing) { state.manual = true; state.last = null; }
                  });
                }
                state.signature = signature;
                state.lastSeen = Date.now();
                if (state.last !== null && el.value !== state.last) { state.manual = true; state.last = null; }
                if (state.manual || state.pending) return;
                state.pending = el;
                const url = location.href;
                const before = el.value;
                window.__emCredentialRequest('totp').then(value => {
                  let reply;
                  try { reply = JSON.parse(value); } catch (e) { return; }
                  const code = reply?.code;
                  const current = findCodeInput();
                  if (typeof code !== 'string' || !/^(?:\d{6}|\d{8})$/.test(code) ||
                      !Number.isSafeInteger(reply.expiresAt) || Date.now() >= reply.expiresAt ||
                      totpState !== state || state.el !== el || state.pending !== el || state.manual ||
                      !el.isConnected || location.href !== url || el.value !== before ||
                      !current || current.el !== el || current.signature !== signature) return;
                  state.confirmedSignature = signature;
                  if (el.value !== code) {
                    state.writing = true;
                    try { state.last = code; state.expiresAt = reply.expiresAt; setValue(el, code); } finally { state.writing = false; }
                  } else if (state.last === code) state.expiresAt = reply.expiresAt;
                }).finally(() => { if (state.pending === el) state.pending = null; });
              };

              const fillRecoveryEmail = () => {
                const el = findRecoveryEmailInput();
                if (el && !el.value && !el.__emFilled) {
                  requestFill(el, 'recovery', () => findRecoveryEmailInput() === el && !el.value && !el.__emFilled);
                }
              };

              const watchPasswordChange = () => {
                const url = location.href.toLowerCase();
                if (!url.includes('/signinoptions/password')) return;
                const fields = Array.from(document.querySelectorAll('input[type="password"]')).filter(visible);
                if (fields.length < 2) return;
                const candidate = fields[fields.length - 1];
                if (!candidate.__emChangeWatch) {
                  candidate.__emChangeWatch = true;
                  candidate.addEventListener('input', () => {
                    if (candidate.value) {
                      try { sessionStorage.setItem('__emLastNewPassword', candidate.value); } catch(e) {}
                    }
                  });
                }
              };
              const tick = () => { fillPassword(); fillTotp(); fillRecoveryEmail(); watchPasswordChange(); };
              tick();
              new MutationObserver(tick).observe(document.documentElement, {childList: true, subtree: true});
              setInterval(tick, 1000);
            })();
        """.trimIndent()

        view.evaluateJavascript(script, null)
    }

    private fun startBackupCodePromptAutofill(view: WebView) {
        fun trustedPage(): Boolean {
            val uri = runCatching { android.net.Uri.parse(view.url.orEmpty()) }.getOrNull()
            return uri?.scheme.equals("https", true) && uri?.port in listOf(-1, 443) &&
                uri?.host?.lowercase(Locale.US) in setOf("accounts.google.com", "myaccount.google.com")
        }
        if (!trustedPage()) return
        val generation = (backupCodePromptGenerations[view] ?: 0L) + 1L
        backupCodePromptGenerations[view] = generation
        val promptUrl = view.url.orEmpty()

        // Use only the account identified on this prompt, never the global or another tab's account.
        val promptContext = """
            const backupPrompt = () => {
              if (window.top !== window || document.visibilityState !== 'visible' || location.href !== ${JSONObject.quote(promptUrl)} ||
                  window.location.protocol !== 'https:' ||
                  !['accounts.google.com', 'myaccount.google.com'].includes(window.location.hostname) ||
                  (window.location.port && window.location.port !== '443')) return null;
              const visible = el => {
                if (!el || !el.getBoundingClientRect().width || !el.getBoundingClientRect().height) return false;
                for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
                  const style = getComputedStyle(node);
                  if (node.hidden || style.display === 'none' || style.visibility !== 'visible' || Number(style.opacity) === 0) return false;
                }
                return true;
              };
              const inputs = Array.from(document.querySelectorAll('input')).filter(el => visible(el) &&
                (el.id === 'backupCodePin' || (el.getAttribute('aria-label') || '').trim().toLowerCase() === 'enter a backup code'));
              if (inputs.length !== 1 || inputs[0].disabled || inputs[0].readOnly) return null;
              if (!inputs[0].__emBackupWatch) {
                inputs[0].__emBackupWatch = true;
                inputs[0].addEventListener('input', event => { if (event.isTrusted) inputs[0].__emBackupManual = true; });
              }
              if (inputs[0].__emBackupManual || inputs[0].value) return null;
              const email = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}${'$'}/i;
              const emailInLabel = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig;
              const accounts = new Set();
              for (const el of document.querySelectorAll('#profileIdentifier,[data-identifier],[data-email],[aria-label],[title]')) {
                if (!visible(el)) continue;
                const values = [el.getAttribute('data-identifier'), el.getAttribute('data-email')];
                if (el.id === 'profileIdentifier') values.push(el.innerText || el.textContent);
                for (const value of values) {
                  const candidate = String(value || '').trim();
                  if (email.test(candidate)) accounts.add(candidate.toLowerCase());
                }
                const label = (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '');
                if (/google account/i.test(label)) {
                  for (const value of label.match(emailInLabel) || []) accounts.add(value.toLowerCase());
                }
              }
              return accounts.size === 1 ? {input: inputs[0], account: [...accounts][0]} : null;
            };
        """.trimIndent()
        val probeScript = """
            (function() {
              $promptContext
              const prompt = backupPrompt();
              return prompt ? prompt.account : '';
            })();
        """.trimIndent()
        val considered = mutableSetOf<String>()

        fun current(): Boolean = backupCodePromptGenerations[view] == generation && trustedPage() && view.url.orEmpty() == promptUrl &&
            !isResettingBrowser && !isFinishing && !isDestroyed && tabs.any { it.webView === view }
        fun probe() {
            if (!current()) return
            if (automationActivityStopped || view !== currentWebView()) {
                view.postDelayed({ probe() }, 1000L)
                return
            }
            view.evaluateJavascript(probeScript) { result ->
                if (!current()) return@evaluateJavascript
                if (!automationActivityStopped && view === currentWebView()) {
                    val account = runCatching { JSONArray("[$result]").optString(0) }.getOrDefault("")
                        .trim().lowercase(Locale.US)
                    if (android.util.Patterns.EMAIL_ADDRESS.matcher(account).matches()) {
                        val accounts = loadAuthenticatorAccounts()
                        val matches = (0 until accounts.length()).mapNotNull { accounts.optJSONObject(it) }
                            .filter { it.optString("account").trim().equals(account, true) }
                        val item = matches.singleOrNull()
                        val encrypted = item?.optString("backupCodesEncrypted").orEmpty()
                        val code = if (item != null && encrypted.isNotBlank() && "$account:$encrypted" !in considered) {
                            readAccountBackupCodes(item).getOrNull(1)
                        } else null
                        if (code != null && current() && view === currentWebView()) {
                            val fillScript = """
                                (function() {
                                  $promptContext
                                  const prompt = backupPrompt();
                                  if (!prompt || prompt.account !== ${JSONObject.quote(account)}) return false;
                                  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
                                  if (setter) setter.call(prompt.input, ${JSONObject.quote(code)}); else prompt.input.value = ${JSONObject.quote(code)};
                                  prompt.input.dispatchEvent(new Event('input', {bubbles:true}));
                                  prompt.input.dispatchEvent(new Event('change', {bubbles:true}));
                                  return true;
                                })();
                            """.trimIndent()
                            view.evaluateJavascript(fillScript) { filled ->
                                if (current() && filled == "true") considered.add("$account:$encrypted")
                            }
                        }
                    }
                }
                if (current()) view.postDelayed({ probe() }, 1000L)
            }
        }
        probe()
    }

    private fun detectGoogleAccountKey(view: WebView, strictIdentity: Boolean = false, onDetected: (String) -> Unit) {
        val script = """
            (function() {
              const emailRe = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig;
              if (${strictIdentity}) {
                const found = new Set();
                for (const el of document.querySelectorAll('#profileIdentifier,[aria-label],[title]')) {
                  const r = el.getBoundingClientRect(), s = getComputedStyle(el);
                  if (r.width <= 0 || r.height <= 0 || s.display === 'none' || s.visibility === 'hidden') continue;
                  const label = [el.getAttribute('aria-label'), el.getAttribute('title')].filter(Boolean).join(' ');
                  const candidate = el.id === 'profileIdentifier' ? (el.innerText || el.textContent || '') :
                    (/google account|حساب google/i.test(label) ? label : '');
                  for (const email of candidate.match(emailRe) || []) found.add(email.toLowerCase());
                }
                return found.size === 1 ? [...found][0] : '';
              }
              const priority = Array.from(document.querySelectorAll('[data-email],[aria-label],[title]'))
                .map(el => [el.getAttribute('data-email'), el.getAttribute('aria-label'), el.getAttribute('title')].filter(Boolean).join(' '))
                .filter(v => /google account|حساب google|حساب Google|account/.test(v.toLowerCase()));
              const matches = priority.join('\n').match(emailRe);
              if (matches && matches.length) return matches[0].toLowerCase();

              const dataEmail = Array.from(document.querySelectorAll('[data-email]'))
                .map(el => el.getAttribute('data-email') || '').find(v => emailRe.test(v));
              if (dataEmail) return dataEmail.toLowerCase();

              // Fallback for Gmail pages where the account menu exposes the email only in its label.
              const labels = Array.from(document.querySelectorAll('[aria-label],[title]'))
                .map(el => [el.getAttribute('aria-label'), el.getAttribute('title')].filter(Boolean).join(' '));
              const fallback = labels.join('\n').match(emailRe);
              return fallback && fallback.length ? fallback[0].toLowerCase() : '';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            val key = result?.trim('"')?.replace("\\\"", "\"")?.trim().orEmpty()
            onDetected(key)
        }
    }

    private fun configureWebView(webView: WebView) {
        webView.settings.apply {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            builtInZoomControls = false
            displayZoomControls = false
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false
            allowContentAccess = false
            userAgentString = "${WebSettings.getDefaultUserAgent(this@MainActivity)} eM-browser/2.0 (en-US)"
        }
        webView.addJavascriptInterface(inspectBridge, "EMInspect")
        webView.addJavascriptInterface(recoveryActionGuard, "EMRecoveryGuard")
        credentialEnabledViews[webView] = runCatching {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) return@runCatching false
            WebViewCompat.addWebMessageListener(
                webView,
                "EMCredential",
                setOf("https://accounts.google.com", "https://myaccount.google.com"),
                credentialBridge
            )
            true
        }.getOrDefault(false)
        webView.setBackgroundColor(Color.WHITE)
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (::pageProgress.isInitialized && view === currentWebView()) {
                    val target = newProgress.coerceIn(0, 100)
                    if (target < 100) {
                        pageProgress.visibility = View.VISIBLE
                    }
                    progressAnimator?.cancel()
                    progressAnimator = ObjectAnimator.ofInt(pageProgress, "progress", pageProgress.progress, target).apply {
                        duration = if (target >= 100) 220L else 260L
                        start()
                    }
                    if (target >= 100) {
                        pageProgress.postDelayed({
                            if (pageProgress.progress >= 100) pageProgress.visibility = View.GONE
                        }, 240L)
                    }
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                devicesPageDocuments[view] = DevicesPageDocument(url.orEmpty())
                if (devicesAutomationActive && devicesAutomationView === view) {
                    recoveryActionPermit = ""
                    devicesAutomationInitialReadyAt = 0L
                    val sameDestination = !url.isNullOrBlank() && url == devicesAutomationStartedUrl && isDevicesDestination(url)
                    val previousOrigin = if (sameDestination) devicesAutomationDocumentOrigin else
                        devicesAutomationDocumentOrigin ?: devicesAutomationPreviousDocumentOrigin
                    devicesAutomationDocumentGeneration++
                    devicesAutomationStartedUrl = url.orEmpty()
                    devicesAutomationPreviousDocumentOrigin = previousOrigin
                    devicesAutomationDocumentOrigin = null
                    devicesAutomationCommitted = false
                    devicesAutomationFinishedAt = 0L
                    devicesAutomationReadyAt = 0L
                    devicesAutomationFailed = false
                    devicesAutomationScheduledDocument = 0L
                    recoveryActionPending = false
                    recoveryFinishProbeInFlight = false
                    if (!devicesAutomationInitialPending && sameDestination && previousOrigin == null) failDevicesDocument(view, url)
                    val target = runCatching { android.net.Uri.parse(url.orEmpty()) }.getOrNull()
                    if (!devicesAutomationInitialPending && target?.host.equals("accounts.google.com", true) && target?.path.orEmpty().contains("/challenge", true)) {
                        noteDevicesVerification(view)
                    }
                    scheduleDevicesWatchdog(view)
                }
                // Invalidate the old document before accepting messages from the next one.
                credentialDocuments[view] = CredentialDocument((credentialDocuments[view]?.generation ?: 0L) + 1L)
                if (adsAutomationActive && adsAutomationView === view) {
                    adsAutomationDocumentGeneration++
                    adsAutomationLoadedAt = 0L
                    adsAutomationLoadFailed = false
                }
                backupCodePromptGenerations[view] = (backupCodePromptGenerations[view] ?: 0L) + 1L
                if (view === currentWebView() && automationMasterEnabled && isSecurityStageOwner(view) &&
                    !(devicesAutomationActive && devicesAutomationView === view && devicesAutomationInitialPending)) {
                    googleVerificationGeneration++
                    googleVerificationProbeInFlight = false
                    val target = runCatching { android.net.Uri.parse(url.orEmpty()) }.getOrNull()
                    if (target?.scheme.equals("https", true) && target?.host.equals("accounts.google.com", true) &&
                        (automationHasRunInCurrentGoogleSession || automationStageHandoffPending)) {
                        googleVerificationCheckPending = true
                    } else if (devicesAutomationActive && devicesAutomationView === view &&
                        target?.scheme.equals("https", true) && target?.host.equals("myaccount.google.com", true)) {
                        googleVerificationCheckPending = true
                    } else if (creationTimeAutomationActive && target?.host.equals("myactivity.google.com", true)) {
                        googleVerificationActive = false
                        googleVerificationCheckPending = false
                        googleVerificationNoticeShown = false
                    } else if (adsAutomationActive && target?.scheme.equals("https", true) &&
                        target?.host.equals("ads.google.com", true)) {
                        googleVerificationActive = false
                        googleVerificationCheckPending = false
                        googleVerificationNoticeShown = false
                    } else if (youtubePremiumAutomationActive && target?.scheme.equals("https", true) &&
                        target?.host?.lowercase(Locale.US) in setOf("youtube.com", "m.youtube.com", "www.youtube.com")) {
                        googleVerificationActive = false
                        googleVerificationCheckPending = false
                        googleVerificationNoticeShown = false
                    }
                }
                if (backupAutomationView === view) {
                    recoveryActionPermit = ""
                    backupAutomationDocumentGeneration++
                    backupAutomationProbeInFlight = false
                    backupAutomationIgnoredAccount = ""
                    backupAutomationIgnoredCodes = emptyList()
                    resetBackupAutomationCandidate()
                }
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                super.onPageCommitVisible(view, url)
                devicesPageDocuments[view]?.let { document ->
                    if (url == document.url && view.url == url) document.committed = true
                }
                if (devicesAutomationActive && devicesAutomationView === view &&
                    url == devicesAutomationStartedUrl && view.url == url) {
                    devicesAutomationCommitted = true
                    scheduleDevicesAutomation(view)
                }
                val document = credentialDocuments[view] ?: return
                val committedUrl = url ?: return
                if (view.url != committedUrl || credentialHost(android.net.Uri.parse(committedUrl)) == null) return
                document.committedUrl = committedUrl
                initializeCredentialMessageClient(view)
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                devicesPageDocuments[view]?.let { document ->
                    if (!url.isNullOrBlank() && view.url == url && document.committed && document.url != url) {
                        document.url = url
                        document.revision++
                        if (devicesAutomationActive && devicesAutomationView === view) devicesAutomationInitialReadyAt = 0L
                    }
                }
                if (devicesAutomationActive && devicesAutomationView === view && !url.isNullOrBlank() && view.url == url &&
                    url != devicesAutomationStartedUrl && devicesAutomationCommitted && devicesAutomationFinishedAt > 0L) {
                    recoveryActionPermit = ""
                    devicesAutomationDocumentGeneration++
                    devicesAutomationStartedUrl = url
                    devicesAutomationPreviousDocumentOrigin = null
                    devicesAutomationFinishedAt = android.os.SystemClock.elapsedRealtime()
                    devicesAutomationReadyAt = 0L
                    devicesAutomationScheduledDocument = 0L
                    recoveryActionPending = false
                    recoveryFinishProbeInFlight = false
                    val ownsVerification = !devicesAutomationInitialPending && view === currentWebView() && isSecurityStageOwner(view)
                    if (ownsVerification) {
                        googleVerificationGeneration++
                        googleVerificationProbeInFlight = false
                    }
                    scheduleDevicesWatchdog(view)
                    val uri = runCatching { android.net.Uri.parse(url) }.getOrNull()
                    if (uri?.scheme.equals("https", true) && uri?.port in listOf(-1, 443) &&
                        uri?.host?.lowercase(Locale.US) in setOf("myaccount.google.com", "accounts.google.com")) {
                        if (!devicesAutomationInitialPending && uri?.host.equals("accounts.google.com", true) && uri?.path.orEmpty().contains("/challenge", true)) {
                            noteDevicesVerification(view)
                        }
                        if (ownsVerification) {
                            googleVerificationCheckPending = true
                            if (!devicesAutomationPaused) injectGoogleVerification(view)
                        }
                        scheduleDevicesAutomation(view)
                    } else if (!devicesAutomationInitialPending) {
                        failDevicesDocument(view, url)
                    }
                }
                initializeCredentialMessageClient(view)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val target = request.url.toString()
                if (devicesAutomationActive && devicesAutomationView === view) return false

                // Let Google's password page navigate normally. The old global
                // interception called loadUrl() from inside shouldOverrideUrlLoading(),
                // which could turn one password-page navigation into a second load.
                // During the automated Password stage this must be a single navigation.
                if ((passwordAutomationActive && passwordAutomationView === view &&
                    (target.contains("myaccount.google.com/signinoptions/password") ||
                     target.contains("accounts.google.com/signinoptions/password"))) ||
                    (appPasswordAutomationActive && target.contains("myaccount.google.com/apppasswords")) ||
                    (adsAutomationActive && target.contains("ads.google.com")) ||
                    (youtubePremiumAutomationActive && target.contains("youtube.com")) ||
                    (authenticatorAutomationActive && authenticatorAutomationView === view && target.contains("myaccount.google.com/two-step-verification")) ||
                    (twoStepAutomationActive && (target.contains("myaccount.google.com/signinoptions/twosv") || target.contains("myaccount.google.com/two-step-verification"))) ||
                    (creationTimeAutomationActive && target.contains("myactivity.google.com/product/youtube/controls"))) {
                    return false
                }

                view.loadUrl(withSelectedLanguage(target))
                return true
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame && adsAutomationActive && adsAutomationView === view) adsAutomationLoadFailed = true
                if (request.isForMainFrame) failDevicesDocument(view, request.url.toString())
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: android.webkit.WebResourceResponse) {
                super.onReceivedHttpError(view, request, response)
                if (request.isForMainFrame && response.statusCode >= 400 && adsAutomationActive && adsAutomationView === view) adsAutomationLoadFailed = true
                if (request.isForMainFrame && response.statusCode >= 400) failDevicesDocument(view, request.url.toString())
            }

            override fun onReceivedSslError(view: WebView, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError) {
                if (adsAutomationActive && adsAutomationView === view) adsAutomationLoadFailed = true
                failDevicesDocument(view, error.url)
                super.onReceivedSslError(view, handler, error)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                devicesPageDocuments[view]?.let { document ->
                    if (document.committed && url == document.url && view.url == url) document.finished = true
                }
                val index = tabs.indexOfFirst { it.webView === view }
                if (index >= 0) {
                    tabs[index].title = view.title?.ifBlank { "eM gmail" } ?: "eM gmail"
                    if (index == activeTab) {
                        updateChromeBar()
                        addressBar.setText(url ?: view.url ?: "")
                    }
                }
                val pageUrl = url.orEmpty()

                val adsUri = runCatching { android.net.Uri.parse(pageUrl) }.getOrNull()
                if (adsAutomationActive && adsAutomationView === view && pageUrl == view.url && !adsAutomationLoadFailed &&
                    adsUri?.scheme.equals("https", true) && adsUri?.host.equals("ads.google.com", true) && adsUri?.port in listOf(-1, 443)) {
                    adsAutomationLoadedAt = android.os.SystemClock.elapsedRealtime()
                }

                if (creationTimeAutomationActive && pageUrl.contains("myactivity.google.com/product/youtube/controls")) {
                    if (creationTimeAutomationWaitStartedAt == 0L) {
                        creationTimeAutomationWaitStartedAt = android.os.SystemClock.elapsedRealtime()
                    }
                    injectCreationTimeAutomation(view)
                }

                // The client is document-scoped; the observers catch fields added by Google's SPA.
                val document = credentialDocuments[view]
                if (document != null && pageUrl == view.url &&
                    credentialHost(android.net.Uri.parse(pageUrl)) != null) {
                    document.committedUrl = pageUrl
                    if (credentialEnabledViews[view] == true) {
                        initializeCredentialMessageClient(view)
                    } else if (view === currentWebView() && !credentialCompatibilityWarningShown) {
                        credentialCompatibilityWarningShown = true
                        Snackbar.make(drawerLayout, "Secure autofill is unavailable. Update Android System WebView or enter credentials manually", Snackbar.LENGTH_LONG).show()
                    }
                }
                if (pageUrl.contains("accounts.google.com") || pageUrl.contains("myaccount.google.com")) {
                    if (view.url.orEmpty() == pageUrl) startBackupCodePromptAutofill(view)
                }

                // Google can insert the "To continue, first verify it\'s you"
                // password gate between two automation stages, including during
                // the centralized 3s hand-off window when no child stage is active.
                // Treat verification as a global automation interstitial, not as
                // part of any individual stage.
                val verificationUri = runCatching { android.net.Uri.parse(pageUrl) }.getOrNull()
                if (automationMasterEnabled && !automationActivityStopped && view === currentWebView() && view.url.orEmpty() == pageUrl && isSecurityStageOwner(view) &&
                    !(devicesAutomationActive && devicesAutomationView === view && devicesAutomationInitialPending) &&
                    verificationUri?.scheme.equals("https", true) && verificationUri?.port in listOf(-1, 443) &&
                    verificationUri?.host?.lowercase(Locale.US) in setOf("myaccount.google.com", "accounts.google.com") &&
                    !automationCompletedForCurrentAccount &&
                    (automationHasRunInCurrentGoogleSession || passwordAutomationActive || appPasswordAutomationActive || recoveryEmailAutomationActive ||
                      creationTimeAutomationActive || devicesAutomationActive || phoneNumbersAutomationActive ||
                     authenticatorAutomationActive || twoStepAutomationActive ||
                     automationStageHandoffPending)) {
                    googleVerificationGeneration++
                    googleVerificationProbeInFlight = false
                    googleVerificationCheckPending = true
                    val verificationGeneration = googleVerificationGeneration
                    view.postDelayed({
                        if (verificationGeneration == googleVerificationGeneration && view.url.orEmpty() == pageUrl) injectGoogleVerification(view)
                    }, 120L)
                }
                if (devicesAutomationActive && devicesAutomationView === view && pageUrl == devicesAutomationStartedUrl &&
                    view.url == pageUrl && !devicesAutomationFailed) {
                    if (devicesAutomationFinishedAt == 0L) devicesAutomationFinishedAt = android.os.SystemClock.elapsedRealtime()
                    if (isDevicesDestination(pageUrl)) scheduleDevicesAutomation(view)
                }
                if (devicesAutomationActive && devicesAutomationView === view && pageUrl == devicesAutomationStartedUrl &&
                    view.url == pageUrl && !devicesAutomationInitialPending && !isDevicesDestination(pageUrl)) {
                    val uri = runCatching { android.net.Uri.parse(pageUrl) }.getOrNull()
                    if (!uri?.scheme.equals("https", true) || uri?.port !in listOf(-1, 443) ||
                        uri?.host?.lowercase(Locale.US) !in setOf("myaccount.google.com", "accounts.google.com")) {
                        failDevicesDocument(view, pageUrl)
                    }
                }
                if (inspectModeEnabled) {
                    view.postDelayed({ if (inspectModeEnabled) installInspectMode(view) }, 120L)
                }
                // Recovery automation must stay on Google's dedicated Recovery Email page.
                // If Google lands on the recovery-phone page, never start Password from there;
                // return once to the direct Recovery Email destination instead.
                if (recoveryEmailAutomationActive &&
                    pageUrl.contains("myaccount.google.com/recovery/phone")) {
                    if (recoveryDirectRetryCount < 2) {
                        recoveryDirectRetryCount++
                        view.postDelayed({
                            if (recoveryEmailAutomationActive) view.loadUrl(withSelectedLanguage(RECOVERY_EMAIL_URL))
                        }, 250L)
                    }
                    return
                }
                val isGoogleAccountPage = pageUrl.contains("myaccount.google.com") || pageUrl.contains("accounts.google.com")
                val isGmailPage = pageUrl.contains("mail.google.com")
                if (isGoogleAccountPage || isGmailPage) {
                    lastAutomationUrl = pageUrl
                    val devicesRun = if (devicesAutomationActive && devicesAutomationView === view) devicesAutomationGeneration else null
                    val devicesDocument = devicesAutomationDocumentGeneration
                    detectGoogleAccountKey(view, devicesRun != null && !devicesAutomationInitialPending) { detectedKey ->
                        if (view !== currentWebView() || view.url.orEmpty() != pageUrl) return@detectGoogleAccountKey
                        if ((devicesRun != null && (!devicesAutomationActive || devicesAutomationView !== view ||
                                devicesRun != devicesAutomationGeneration || devicesDocument != devicesAutomationDocumentGeneration)) ||
                            (devicesRun == null && devicesAutomationActive && devicesAutomationView === view)) return@detectGoogleAccountKey
                        if (detectedKey.isNotBlank()) {
                            val runningAccount = when {
                                passwordAutomationActive && passwordAutomationView === view -> passwordAutomationAccount
                                authenticatorAutomationActive && authenticatorAutomationView === view -> authenticatorAutomationAccount
                                twoStepAutomationActive && twoStepAutomationView === view -> twoStepAutomationAccount
                                backupAutomationView === view -> backupAutomationAccount
                                devicesAutomationActive && devicesAutomationView === view -> devicesAutomationAccount
                                automationStageHandoffPending && securityStageHandoffView === view -> securityStageHandoffAccount
                                else -> ""
                            }
                            if (runningAccount.isNotBlank() && !runningAccount.equals(detectedKey, true)) {
                                cancelSecurityAutomationForView(view)
                                currentAccountKey = detectedKey
                                accountKeyByWebView[view] = detectedKey
                                automationCompletedForCurrentAccount = false
                                completedAccountKey = ""
                                Snackbar.make(drawerLayout, "Automation stopped: Google account changed", Snackbar.LENGTH_LONG).show()
                                return@detectGoogleAccountKey
                            }
                            val accountChanged = currentAccountKey.isNotBlank() && currentAccountKey != detectedKey
                            currentAccountKey = detectedKey
                            accountKeyByWebView[view] = detectedKey
                            if (backupAutomationView === view && backupAutomationAccount.isBlank()) backupAutomationAccount = detectedKey.trim().lowercase(Locale.US)
                            if (accountChanged) {
                                automationCompletedForCurrentAccount = false
                                automationHasRunInCurrentGoogleSession = false
                                completedAccountKey = ""
                            }
                        }

                // Recovery data remains separate; account passwords are recorded only
                // after Google's success state is detected below.
                if (isGoogleAccountPage) {
                    val recoveryProbe = """
                        (function(){
                          const body=(document.body?.innerText||'').replace(/\s+/g,' ');
                          const lower=body.toLowerCase();
                          const recoveryContext=/recovery email|recovery e-mail|البريد الإلكتروني المخصص لاسترداد الحساب|بريد الاسترداد|استرداد الحساب/i.test(body);
                          if (!recoveryContext) return '';
                          const emails=Array.from(new Set((body.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig)||[]).map(x=>x.toLowerCase())));
                          const current='${currentAccountKey.replace("'", "")}'.toLowerCase();
                          const candidates=emails.filter(e=>e !== current);
                          if (candidates.length) return candidates[0];
                          const noRecovery=/add a recovery email|add recovery email|إضافة بريد إلكتروني لاسترداد الحساب/i.test(body);
                          return noRecovery ? '__NONE__' : '';
                        })();
                    """.trimIndent()
                    val probeDocument = credentialDocuments[view]
                    val probeAccount = accountKeyByWebView[view].orEmpty()
                    fun syncRecovery() {
                        if (view !== currentWebView() || view.url.orEmpty() != pageUrl ||
                            credentialHost(android.net.Uri.parse(pageUrl)) != "myaccount.google.com" ||
                            credentialDocuments[view] !== probeDocument || accountKeyByWebView[view].orEmpty() != probeAccount ||
                            (devicesAutomationActive && devicesAutomationView === view)) return
                        view.evaluateJavascript(recoveryProbe) { result ->
                            if (view !== currentWebView() || view.url.orEmpty() != pageUrl ||
                                credentialDocuments[view] !== probeDocument || accountKeyByWebView[view].orEmpty() != probeAccount ||
                                (devicesAutomationActive && devicesAutomationView === view)) return@evaluateJavascript
                            val value = result?.trim('"').orEmpty()
                            if (value == "__NONE__") credentialBridge.updateDetectedRecoveryEmail("")
                            else if (value.isNotBlank()) credentialBridge.updateDetectedRecoveryEmail(value)
                        }
                    }
                    syncRecovery()
                    repeat(4) { pass -> view.postDelayed({ syncRecovery() }, 700L + pass * 1000L) }
                    detectPendingAuthenticatorChange(view)
                }
                        if (automationCompletedForCurrentAccount && completedAccountKey.isNotBlank() && currentAccountKey.isNotBlank() && completedAccountKey != currentAccountKey) {
                            automationCompletedForCurrentAccount = false
                            automationHasRunInCurrentGoogleSession = false
                        }

                        if (isGoogleAccountPage && isSecurityStageOwner(view)) {
                            view.evaluateJavascript("""
                                (function(){
                                  try {
                                    const p=sessionStorage.getItem('__emLastNewPassword') || '';
                                    const body=(document.body?.innerText||'').replace(/\s+/g,' ');
                                    const success=/password (?:changed|updated)|your password (?:was )?changed|تم تغيير كلمة المرور|تم تحديث كلمة المرور/i.test(body);
                                    const onPassword=/signinoptions\/password/i.test(location.href);
                                    return (!onPassword && success && p) ? p : '';
                                  } catch(e) { return ''; }
                                })();
                            """.trimIndent()) { result ->
                                if (view !== currentWebView() || !isSecurityStageOwner(view)) return@evaluateJavascript
                                val value = result?.trim('"').orEmpty()
                                if (value.isNotBlank()) {
                                    passwordAutomationCurrent = value
                                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_PASSWORD_CURRENT, value).apply()
                                    updateSavedAccountPassword(value, accountOverride = accountKeyByWebView[view].orEmpty())
                                    view.evaluateJavascript("try { sessionStorage.removeItem('__emLastNewPassword'); } catch(e) {}", null)
                                }
                            }
                        }
                        if (passwordAutomationActive && passwordAutomationView === view) {
                            // Navigation alone does not confirm a password change.
                            val token = passwordConfirmationToken
                            view.postDelayed({ if (isPasswordRun(view, token)) injectPasswordChangeScript(view) }, 250L)
                        }
                        if (appPasswordAutomationActive) {
                            view.postDelayed({ if (appPasswordAutomationActive) injectAppPasswordAutomation(view) }, 350L)
                        }
                        if (recoveryEmailAutomationActive) {
                            view.postDelayed({ injectRecoveryEmailRemovalScript(view) }, 250L)
                        }
                        if (phoneNumbersAutomationActive) {
                            view.postDelayed({ injectPhoneNumbersAutomation(view) }, 250L)
                        }
                        if (authenticatorAutomationActive && authenticatorAutomationView === view) {
                            val token = authenticatorAutomationRemovalToken
                            view.postDelayed({ if (isAuthenticatorRun(view, token)) injectAuthenticatorAutomation(view) }, 500L)
                        }
                        if (twoStepAutomationActive) {
                            // Direct flow: no reload/refresh. As soon as the 2-Step
                            // page finishes loading, press the Turn On action.
                            if (!twoStepAutomationTurnOnClicked && twoStepAutomationStage != "confirm" && twoStepAutomationStage != "waiting_success") {
                                twoStepAutomationStage = "direct_click"
                            }
                            view.postDelayed({ injectTwoStepAutomation(view) }, 350L)
                        }
                        if (automationMasterEnabled && !anyAutomationStageActive() && !automationCompletedForCurrentAccount) {
                            view.postDelayed({ startConfiguredAutomationForCurrentAccount() }, 250L)
                        }
                    }
                }
                saveTabsState()
            }

            override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                // Recover from a WebView renderer crash without taking down the
                // whole browser. This is important when several tabs are open.
                val index = tabs.indexOfFirst { it.webView === view }
                if (index < 0) return true

                if (devicesAutomationActive && devicesAutomationView === view) {
                    Snackbar.make(drawerLayout, "Devices stopped because the page crashed. Turn Devices off and on to retry.", Snackbar.LENGTH_LONG).show()
                }
                cancelSecurityAutomationForView(view)
                if (adsAutomationView === view) stopAdsAutomation()
                cancelBackupAutomationForView(view)
                val urlToRestore = view.url ?: HOME_URL
                (view.parent as? ViewGroup)?.removeView(view)
                view.stopLoading()
                view.destroy()

                val replacement = WebView(this@MainActivity)
                val oldTitle = tabs[index].title
                val profileName = tabs[index].profileName
                tabs[index].webView = replacement
                tabs[index].title = oldTitle
                val resumeAccountRecovery = index == activeTab && accountRecoveryModeEnabled
                tabs[index].accountRecoveryModeApplied = resumeAccountRecovery
                applyProfile(replacement, profileName)
                configureWebView(replacement)

                if (index == activeTab) {
                    showActiveWebView(syncAccountRecovery = false)
                    val restoreUrl = if (resumeAccountRecovery) ACCOUNT_RECOVERY_URL else urlToRestore
                    replacement.loadUrl(withSelectedLanguage(restoreUrl))
                } else {
                    replacement.loadUrl(withSelectedLanguage(urlToRestore))
                }
                return true
            }
        }
    }

    private fun showActiveWebView(syncAccountRecovery: Boolean = true) {
        // A WebView can only have one parent. The previous implementation left
        // an inactive WebView attached to its old SwipeRefreshLayout after the
        // tab container was removed, which could crash when switching between
        // multiple tabs (especially when the same page was opened more than once).
        val webView = tabs.getOrNull(activeTab)?.webView ?: return
        if (devicesAutomationActive && devicesAutomationView !== webView) {
            recoveryActionPermit = ""
            devicesAutomationReadyAt = 0L
            devicesAutomationInitialReadyAt = 0L
        }
        if (credentialEnabledViews[webView] == false && !credentialCompatibilityWarningShown &&
            credentialHost(android.net.Uri.parse(webView.url.orEmpty())) != null) {
            credentialCompatibilityWarningShown = true
            Snackbar.make(drawerLayout, "Secure autofill is unavailable. Update Android System WebView or enter credentials manually", Snackbar.LENGTH_LONG).show()
        }
        val ownsSecurityStage = (passwordAutomationActive && passwordAutomationView === webView) ||
            (authenticatorAutomationActive && authenticatorAutomationView === webView) ||
            (backupAutomationView === webView) ||
            (adsAutomationActive && adsAutomationView === webView) ||
            (devicesAutomationActive && devicesAutomationView === webView) ||
            (automationStageHandoffPending && securityStageHandoffView === webView)
        if (ownsSecurityStage) {
            currentAccountKey = accountKeyByWebView[webView].orEmpty().ifBlank {
                when {
                    passwordAutomationView === webView -> passwordAutomationAccount
                    authenticatorAutomationView === webView -> authenticatorAutomationAccount
                    backupAutomationView === webView -> backupAutomationAccount
                    adsAutomationView === webView -> adsAutomationAccount
                    devicesAutomationView === webView -> devicesAutomationAccount
                    automationLastHandoffStage == "recovery_set" && securityStageHandoffView === webView -> securityStageHandoffAccount
                    else -> ""
                }
            }
        }
        if (!isSecurityStageOwner(webView)) {
            googleVerificationGeneration++
            googleVerificationProbeInFlight = false
            googleVerificationActive = false
            googleVerificationCheckPending = false
            googleVerificationSubmitIssued = false
            googleVerificationNoticeShown = false
        }
        backupAutomationView?.takeIf { it !== webView }?.let { suspendBackupAutomation() }
        (webView.parent as? ViewGroup)?.removeView(webView)
        contentFrame.removeAllViews()

        val refresh = SwipeRefreshLayout(this).apply {
            setColorSchemeColors(ContextCompat.getColor(this@MainActivity, R.color.page_progress_blue))
            addView(webView, ViewGroup.LayoutParams(-1, -1))
            setOnRefreshListener {
                webView.reload()
                postDelayed({ isRefreshing = false }, 800)
            }
        }
        contentFrame.addView(refresh, LinearLayout.LayoutParams(-1, -1))
        updateChromeBar()
        if (syncAccountRecovery && !ownsSecurityStage) syncAccountRecoveryToActiveTab()
        initializeCredentialMessageClient(webView)
        if (backupAutomationView === webView) {
            googleVerificationCheckPending = true
            scheduleBackupAutomationProbe(webView, backupAutomationGeneration, 0L)
        }
        if ((devicesAutomationActive && devicesAutomationView === webView && !devicesAutomationInitialPending) ||
            (automationStageHandoffPending && automationLastHandoffStage == "recovery_set" && securityStageHandoffView === webView)) {
            val uri = runCatching { android.net.Uri.parse(webView.url.orEmpty()) }.getOrNull()
            if (uri?.scheme.equals("https", true) && uri?.port in listOf(-1, 443) &&
                uri?.host?.lowercase(Locale.US) in setOf("myaccount.google.com", "accounts.google.com")) {
                googleVerificationCheckPending = true
            }
        }
        if (ownsSecurityStage) webView.post { resumeSecurityAutomation(webView) }
    }

    private fun setAccountRecoveryMode(enabled: Boolean) {
        accountRecoveryModeEnabled = enabled
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(KEY_ACCOUNT_RECOVERY_MODE_ENABLED, enabled)
            .apply()

        if (enabled) {
            syncAccountRecoveryToActiveTab()
            return
        }

        val active = tabs.getOrNull(activeTab)
        if (active?.accountRecoveryModeApplied == true &&
            isAccountRecoveryFlowUrl(active.webView.url.orEmpty())) {
            active.webView.stopLoading()
            active.webView.loadUrl(withSelectedLanguage(HOME_URL))
        }
        tabs.forEach { it.accountRecoveryModeApplied = false }
        saveTabsState()
    }

    private fun syncAccountRecoveryToActiveTab() {
        if (!accountRecoveryModeEnabled) return
        val tab = tabs.getOrNull(activeTab) ?: return
        if (tab.accountRecoveryModeApplied) return

        tab.accountRecoveryModeApplied = true
        if (!isAccountRecoveryFlowUrl(tab.webView.url.orEmpty())) {
            tab.webView.loadUrl(withSelectedLanguage(ACCOUNT_RECOVERY_URL))
        }
    }

    private fun isAccountRecoveryFlowUrl(url: String): Boolean {
        val current = url.lowercase(Locale.US)
        return current.contains("accounts.google.com/v3/signin/recovery") ||
            current.contains("accounts.google.com/signin/recovery")
    }

    private fun updateChromeBar() {
        if (::tabCountView.isInitialized) tabCountView.text = tabs.size.toString()
        if (::addressBar.isInitialized) {
            val currentUrl = currentWebView()?.url
            if (currentUrl != null) addressBar.setText(currentUrl) else addressBar.text?.clear()
        }
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        // Closing a tab removes the tab object itself, including the final tab;
        // never turn the last tab into an empty/home tab card.
        val tab = tabs.removeAt(index)
        cancelSecurityAutomationForView(tab.webView)
        if (adsAutomationView === tab.webView) stopAdsAutomation()
        cancelBackupAutomationForView(tab.webView)
        // Detach before destroying: destroying a WebView that's still attached to the
        // screen (true whenever the closed tab happens to be the one on screen) is the
        // same class of bug fixed earlier for Clear Browsing Data, and could glitch or
        // crash the view hierarchy and generally make switching/closing tabs feel janky.
        (tab.webView.parent as? ViewGroup)?.removeView(tab.webView)
        tab.webView.stopLoading()
        tab.webView.destroy()
        // Remove the tab's private profile after its WebView is gone.
        // The default profile belongs to the first tab and is intentionally kept.
        if (tab.profileName != Profile.DEFAULT_PROFILE_NAME &&
            WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            runCatching { ProfileStore.getInstance().deleteProfile(tab.profileName) }
        }
        activeTab = when {
            tabs.isEmpty() -> 0
            activeTab >= tabs.size -> tabs.lastIndex
            index < activeTab -> activeTab - 1
            else -> activeTab
        }
        if (tabs.isEmpty()) {
            // Keep the browser content area truly empty until the user creates
            // a new tab or leaves the switcher; never leave the closed WebView's
            // container visible underneath the tab switcher.
            contentFrame.removeAllViews()
            if (::addressBar.isInitialized) addressBar.text?.clear()
            if (::tabCountView.isInitialized) tabCountView.text = "0"
        } else {
            showActiveWebView()
        }
        saveTabsState()
    }

    private fun showClearAllDataDialog() {
        val dialog = AlertDialog.Builder(this)
            .setMessage("Clear all data?")
            .setNegativeButton("No", null)
            .setPositiveButton("Yes") { _, _ ->
                clearAllBrowserData()
            }
            .setNeutralButton("Deep clear") { _, _ -> openAppStorageSettings() }
            .create()

        dialog.setOnShowListener {
            val dialogBackground = Color.WHITE
            val dialogText = Color.BLACK

            dialog.window?.setBackgroundDrawable(GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(dialogBackground)
                cornerRadius = dp(18).toFloat()
            })
            dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(dialogText)
        }

        dialog.show()
        applyRoundedDialogCorners(dialog)
    }

    /**
     * Resets eM browser to a first-install state without uninstalling the APK.
     * All browser/site data and all app preferences created by the browser are removed.
     */
    private fun clearAllBrowserData() {
        if (isResettingBrowser) return
        isResettingBrowser = true
        stopAppPasswordAutomation()
        stopCreationTimeAutomation()
        stopBackupAutomation()

        // 1) Detach every WebView from the screen BEFORE destroying it. Destroying a WebView
        //    that is still attached to contentFrame/SwipeRefreshLayout leaves a dead view in the
        //    hierarchy, and the next draw/touch/layout pass crashes the app.
        runCatching { contentFrame.removeAllViews() }
        tabs.toList().forEach { tab ->
            runCatching {
                val wv = tab.webView
                cancelSecurityAutomationForView(wv)
                (wv.parent as? ViewGroup)?.removeView(wv)
                wv.stopLoading()
                wv.webViewClient = WebViewClient()
                wv.webChromeClient = null
                wv.clearHistory()
                wv.clearCache(true)
                wv.clearFormData()
                wv.clearSslPreferences()
                wv.loadUrl("about:blank")
                wv.destroy()
            }
        }
        tabs.clear()
        activeTab = 0
        runCatching { if (::tabCountView.isInitialized) tabCountView.text = "0" }

        // 2) Clear every tab profile (each profile has its own cookies/storage).
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            runCatching {
                val store = ProfileStore.getInstance()
                store.getAllProfileNames().forEach { name ->
                    if (name != Profile.DEFAULT_PROFILE_NAME) {
                        runCatching {
                            store.getProfile(name)?.let { profile ->
                                profile.getCookieManager().removeAllCookies(null)
                                profile.getWebStorage().deleteAllData()
                            }
                        }
                    }
                }
            }
        }

        // 3) Default-profile stores. Each call is isolated so one failure cannot crash the reset.
        runCatching { WebStorage.getInstance().deleteAllData() }
        runCatching {
            val webViewDatabase = WebViewDatabase.getInstance(this)
            webViewDatabase.clearHttpAuthUsernamePassword()
            webViewDatabase.clearFormData()
            webViewDatabase.clearUsernamePassword()
        }

        // 4) Cookie deletion is asynchronous; finish only after it completes (once only).
        val cookieManager = CookieManager.getInstance()
        var finished = false
        val finishOnce = {
            if (!finished) {
                finished = true
                runCatching { cookieManager.flush() }
                finishFullBrowserReset()
            }
        }
        runCatching {
            cookieManager.removeAllCookies {
                runCatching { cookieManager.removeSessionCookies { finishOnce() } }
                    .onFailure { finishOnce() }
            }
        }.onFailure { finishOnce() }
        // Safety net: if a callback never fires, still finish the reset.
        window.decorView.postDelayed({ finishOnce() }, 3000L)
    }

    private fun finishFullBrowserReset() {
        // Reset lightweight state immediately. Heavy filesystem work runs in the background
        // so the UI never blocks long enough to trigger an ANR.
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.edit().clear().apply()

        val databaseNames = databaseList().toList()
        Thread {
            runCatching { deleteDirectoryContents(filesDir) }
            runCatching { deleteDirectoryContents(noBackupFilesDir) }
            runCatching { deleteDirectoryContents(cacheDir) }
            databaseNames.forEach { name -> runCatching { deleteDatabase(name) } }

            runOnUiThread {
                isResettingBrowser = false
                if (!isFinishing && !isDestroyed) {
                    recreate()
                }
            }
        }.start()
    }

    private fun deleteDirectoryContents(directory: File) {
        directory.listFiles()?.forEach { file ->
            if (file.isDirectory) file.deleteRecursively() else file.delete()
        }
    }

    private fun currentWebView(): WebView? = tabs.getOrNull(activeTab)?.webView

    private fun withSelectedLanguage(url: String): String {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return url
        // Keep website language independent from the phone's time-zone setting.
        var result = url
        val language = "en"
        result = if (result.contains(Regex("([?&])hl=[^&]*", RegexOption.IGNORE_CASE))) {
            result.replace(Regex("([?&])hl=[^&]*", RegexOption.IGNORE_CASE), "$1hl=$language")
        } else {
            result + if (result.contains("?")) "&hl=$language" else "?hl=$language"
        }
        return result
    }

    /**
     * Applies only a rounded outer background to an already-sized AlertDialog.
     * No width, height, padding, margins, or window layout parameters are changed.
     */
    private fun applyRoundedDialogCorners(dialog: AlertDialog) {
        val backgroundColor = resolveColor(com.google.android.material.R.attr.colorSurface)
        dialog.window?.setBackgroundDrawable(GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(backgroundColor)
            cornerRadius = dp(18).toFloat()
        })

        // Keep every text element inside app dialogs bold, including titles,
        // messages, custom content, and action buttons. Preserve each view's
        // existing typeface family (for example the Authenticator code).
        fun boldTextViews(view: View) {
            if (view is TextView) {
                view.typeface = android.graphics.Typeface.create(view.typeface, android.graphics.Typeface.BOLD)
            }
            if (view is ViewGroup) {
                for (i in 0 until view.childCount) boldTextViews(view.getChildAt(i))
            }
        }
        dialog.window?.decorView?.let { boldTextViews(it) }
    }

    private fun resolveColor(attr: Int): Int {
        val value = android.util.TypedValue()
        theme.resolveAttribute(attr, value, true)
        return if (value.resourceId != 0) ContextCompat.getColor(this, value.resourceId) else value.data
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onResume() {
        super.onResume()
        devicesAutomationPaused = false
        backupAutomationView?.takeIf { it === currentWebView() }?.let {
            resumeSecurityAutomation(it)
            scheduleBackupAutomationProbe(it, backupAutomationGeneration, 0L)
        }
        val view = devicesAutomationView
        if (devicesAutomationActive && !devicesAutomationInitialPending && view != null && view === currentWebView() && isSecurityStageOwner(view)) {
            googleVerificationGeneration++
            googleVerificationProbeInFlight = false
            googleVerificationCheckPending = true
            resumeSecurityAutomation(view)
            scheduleDevicesAutomation(view)
        }
    }

    override fun onPause() {
        recoveryActionPermit = ""
        devicesAutomationPaused = true
        if (backupAutomationView != null) suspendBackupAutomation()
        if (devicesAutomationActive) {
            devicesAutomationReadyAt = 0L
            devicesAutomationInitialReadyAt = 0L
            val view = devicesAutomationView
            if (!devicesAutomationInitialPending && view != null && view === currentWebView() && isSecurityStageOwner(view)) {
                googleVerificationGeneration++
                googleVerificationProbeInFlight = false
                googleVerificationCheckPending = true
            }
        }
        super.onPause()
    }

    override fun onStart() {
        super.onStart()
        automationActivityStopped = false
        val view = currentWebView()
        view?.let {
            initializeCredentialMessageClient(it)
            if (backupAutomationView === it) scheduleBackupAutomationProbe(it, backupAutomationGeneration, 0L)
        }
        if (view != null && ((passwordAutomationActive && passwordAutomationView === view) ||
                (authenticatorAutomationActive && authenticatorAutomationView === view) ||
                (backupAutomationView === view) ||
                (devicesAutomationActive && devicesAutomationView === view))) {
            resumeSecurityAutomation(view)
        } else if (view != null && isSecurityStageOwner(view) && automationMasterEnabled &&
            (googleVerificationActive || googleVerificationCheckPending || automationStageHandoffPending)) {
            val uri = runCatching { android.net.Uri.parse(view.url.orEmpty()) }.getOrNull()
            if (uri?.scheme.equals("https", true) && uri?.port in listOf(-1, 443) &&
                uri?.host?.lowercase(Locale.US) in setOf("myaccount.google.com", "accounts.google.com")) {
                googleVerificationCheckPending = true
                injectGoogleVerification(view)
            }
        }
    }

    override fun onStop() {
        recoveryActionPermit = ""
        automationActivityStopped = true
        googleVerificationGeneration++
        googleVerificationProbeInFlight = false
        suspendBackupAutomation()
        // Persist open tabs and WebView site state before Android may stop the activity/process.
        if (!isResettingBrowser) saveTabsState()
        // Persist WebView cookies/site state before Android may stop the activity/process.
        runCatching { CookieManager.getInstance().flush() }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            tabs.forEach { tab ->
                runCatching { WebViewCompat.getProfile(tab.webView).getCookieManager().flush() }
            }
        }
        super.onStop()
    }

    override fun onDestroy() {
        stopBackupAutomation()
        // Never clear browser/site data automatically when the activity is destroyed.
        // Browsing data is removed only through the user's explicit Clear Browsing Data action.
        tabs.toList().forEach {
            runCatching {
                cancelSecurityAutomationForView(it.webView)
                (it.webView.parent as? ViewGroup)?.removeView(it.webView)
                it.webView.stopLoading()
                it.webView.destroy()
            }
        }
        super.onDestroy()
    }
}
