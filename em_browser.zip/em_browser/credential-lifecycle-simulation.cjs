// Runs the production injected scripts against a model of WebView's asynchronous callbacks.
// This is not an Android WebView or an integration test of the Kotlin code.
const { readFileSync } = require('node:fs');
const { join } = require('node:path');
const vm = require('node:vm');
const { test } = require('node:test');
const assert = require('node:assert/strict');

const source = readFileSync(join(__dirname, 'app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
function scriptIn(functionName, variable) {
  const start = source.indexOf(`private fun ${functionName}(`);
  assert.notEqual(start, -1, `missing ${functionName}`);
  const match = source.slice(start).match(new RegExp(`val ${variable} = """([\\s\\S]*?)"""\\.trimIndent\\(\\)`));
  assert.ok(match, `missing ${variable} script in ${functionName}`);
  return match[1];
}
const probeTemplate = scriptIn('initializeCredentialMessageClient', 'probe');
const installTemplate = scriptIn('installCredentialMessageClient', 'script');
function render(template, values) {
  return template.replace(/\$\{JSONObject\.quote\((\w+)\)\}|\$\{document\.generation\}/g,
    (_, name) => name ? JSON.stringify(values[name]) : String(values.generation));
}
function host(url) {
  try {
    const u = new URL(url);
    if (u.protocol !== 'https:' || u.username || u.password || (u.port && u.port !== '443')) return null;
    return ['accounts.google.com', 'myaccount.google.com'].includes(u.hostname) ? u.hostname : null;
  } catch { return null; }
}
function page(url) {
  const sent = [];
  const location = { href: url, origin: new URL(url).origin };
  const window = { EMCredential: { postMessage: raw => sent.push(JSON.parse(raw)) } };
  window.top = window;
  const context = vm.createContext({ window, location, document: { documentElement: {} }, setTimeout, clearTimeout });
  return { context, window, location, sent };
}

class WebViewModel {
  constructor(url) {
    this.url = url;
    this.page = page(url);
    this.state = null;
    this.jobs = [];
    this.counter = 0;
    this.active = true;
    this.foreground = true;
    this.enabled = true;
  }
  id() { return `00000000-0000-0000-0000-${String(++this.counter).padStart(12, '0')}`; }
  start() {
    this.state = { generation: (this.state?.generation || 0) + 1, committedUrl: null,
      token: null, documentId: null, attempt: 0, confirmedAttempt: 0 };
  }
  replace(url) { this.url = url; this.page = page(url); }
  navigateSpa(url) {
    this.url = url;
    this.page.location.href = url;
    this.page.location.origin = new URL(url).origin;
    this.initialize();
  }
  current(state, url) {
    return this.state === state && this.enabled && this.foreground && this.active && this.url === url &&
      host(url) !== null && host(state.committedUrl) === host(url);
  }
  commit(url) {
    if (!this.state || this.url !== url || !host(url)) return;
    this.state.committedUrl = url;
    this.initialize();
  }
  finish(url) { this.commit(url); }
  schedule(kind, script, callback) {
    this.jobs.push({ kind, execute: () => {
      const result = vm.runInContext(script, this.page.context);
      return () => callback(result);
    } });
  }
  take(kind) {
    const index = this.jobs.findIndex(job => job.kind === kind);
    assert.notEqual(index, -1, `no ${kind} job`);
    return this.jobs.splice(index, 1)[0];
  }
  flush() {
    let count = 0;
    while (this.jobs.length) {
      assert.ok(++count < 100, 'unexpected retry loop');
      this.jobs.shift().execute()();
    }
  }
  initialize() {
    const state = this.state, url = this.url;
    if (!state || !this.current(state, url)) return;
    const token = state.token || (state.token = this.id());
    const attempt = ++state.attempt;
    const candidate = this.id();
    this.schedule('probe', render(probeTemplate, { pageUrl: url, candidate }), documentId => {
      if (this.state !== state) return;
      if (this.url !== url) { this.initialize(); return; }
      if (!this.current(state, url) || typeof documentId !== 'string' || !documentId) return;
      this.schedule('install', render(installTemplate, { pageUrl: url, token, documentId, generation: state.generation }), result => {
        if (this.state !== state) return;
        if (this.url !== url) { this.initialize(); return; }
        if (result === true && attempt >= state.confirmedAttempt && this.current(state, url)) {
          state.confirmedAttempt = attempt;
          state.documentId = documentId;
        }
      });
    });
  }
  accepts(message, { origin = new URL(this.url).origin, main = true } = {}) {
    const state = this.state;
    return !!(main && this.enabled && this.foreground && this.active && state && host(origin) &&
      host(origin) === host(this.url) && host(origin) === host(state.committedUrl) &&
      message.token === state.token && message.documentId === state.documentId && message.url === this.url);
  }
  request() {
    const promise = this.page.window.__emCredentialRequest('totp');
    return { promise, message: this.page.sent.at(-1) };
  }
  reply(message, value = '123456') {
    this.page.window.EMCredential.onmessage({ data: JSON.stringify({ id: message.id, value }) });
  }
}

const A = 'https://accounts.google.com/signin';
const B = 'https://accounts.google.com/challenge/totp';
const C = 'https://myaccount.google.com/security';
function loaded(url = A) {
  const web = new WebViewModel(url);
  web.start();
  web.commit(url);
  web.flush();
  return web;
}

test('cancelling a row transition discards pending credential replies', async () => {
  const web = loaded();
  const old = web.request();
  web.page.window.__emCancelCredentialRequests();
  web.reply(old.message, 'old-account-code');
  assert.equal(await old.promise, '');
  const next = web.request();
  web.reply(next.message, 'new-account-code');
  assert.equal(await next.promise, 'new-account-code');
});

test('source retains the bridge and navigation guards', () => {
  for (const text of [
    'setOf("https://accounts.google.com", "https://myaccount.google.com")',
    '!isMainFrame', 'view !== currentWebView()', '!view.isAttachedToWindow',
    'Lifecycle.State.STARTED', 'token != document.token', 'documentId != document.documentId',
    'url != currentUrl', 'view.url != committedUrl', 'pageUrl == view.url',
    'initializeCredentialMessageClient(webView)', 'initializeCredentialMessageClient(it)'
  ]) assert.ok(source.includes(text), `missing ${text}`);
  assert.ok(!source.includes('CredentialPredecessors'));
  assert.ok(!source.includes('snapshotPreviousCredentialDocument'));
});

test('normal commit and finish-only fallback install a usable client', async () => {
  for (const fallback of [false, true]) {
    const web = new WebViewModel(A);
    web.start();
    fallback ? web.finish(A) : web.commit(A);
    web.flush();
    const { promise, message } = web.request();
    assert.ok(web.accepts(message));
    web.reply(message);
    assert.equal(await promise, '123456');
  }
});

test('redirect chain ignores stale URLs and initializes the final destination', () => {
  const web = new WebViewModel(A);
  web.start();
  web.start();
  web.replace(B);
  web.start();
  web.replace(C);
  web.commit(A);
  web.finish(B);
  assert.equal(web.jobs.length, 0);
  web.commit(C);
  web.flush();
  const { message, promise } = web.request();
  assert.ok(web.accepts(message));
  web.reply(message);
  return promise;
});

test('cancelled duplicate same-URL start needs only one later callback', () => {
  const web = new WebViewModel(A);
  web.start();
  web.start();
  web.commit(A);
  web.flush();
  assert.ok(web.state.documentId);
  assert.equal(web.state.generation, 2);
});

test('same-URL reload rejects old token and binds a new document', () => {
  const web = loaded();
  const old = { token: web.state.token, documentId: web.state.documentId, url: A };
  web.start();
  assert.equal(web.accepts(old), false);
  web.replace(A);
  web.commit(A);
  web.flush();
  assert.notEqual(web.state.token, old.token);
  assert.notEqual(web.state.documentId, old.documentId);
  assert.equal(web.accepts(old), false);
});

test('SPA and repeated installs retain the client and outstanding requests', async () => {
  const web = loaded();
  const client = web.page.window.__emCredentialClient;
  const oldToken = web.state.token;
  const { promise, message } = web.request();
  web.navigateSpa(B);
  web.finish(B);
  web.flush();
  assert.equal(web.page.window.__emCredentialClient, client);
  assert.equal(web.state.token, oldToken);
  assert.equal(web.accepts(message), false);
  web.reply(message);
  assert.equal(await promise, '123456');
  const next = web.request();
  assert.ok(web.accepts(next.message));
  web.reply(next.message);
  assert.equal(await next.promise, '123456');
});

test('a cancelled start can rekey the surviving client without losing pending replies', async () => {
  const web = loaded();
  const client = web.page.window.__emCredentialClient;
  const pending = web.request();
  web.start();
  assert.equal(web.accepts(pending.message), false);
  web.commit(A);
  web.flush();
  assert.equal(web.page.window.__emCredentialClient, client);
  assert.notEqual(web.state.token, pending.message.token);
  web.reply(pending.message);
  assert.equal(await pending.promise, '123456');
  const next = web.request();
  assert.ok(web.accepts(next.message));
  web.reply(next.message);
  assert.equal(await next.promise, '123456');
});

test('missing and late asynchronous callbacks do not block a finish retry', () => {
  const web = new WebViewModel(A);
  web.start();
  web.commit(A);
  const lateProbe = web.take('probe').execute();
  web.finish(A);
  web.flush();
  const confirmed = web.state.confirmedAttempt;
  lateProbe();
  web.flush();
  assert.equal(web.state.confirmedAttempt, confirmed);
  assert.ok(web.state.documentId);
});

test('a document replacement between probe and install is detected and retried', () => {
  const web = new WebViewModel(A);
  web.start();
  web.commit(A);
  web.take('probe').execute()();
  web.replace(A);
  web.take('install').execute()();
  assert.equal(web.state.documentId, null);
  web.finish(A);
  web.flush();
  assert.ok(web.state.documentId);
});

test('a probe reply from an earlier start is discarded', () => {
  const web = new WebViewModel(A);
  web.start();
  web.commit(A);
  const lateProbe = web.take('probe').execute();
  web.start();
  web.replace(A);
  web.commit(A);
  web.flush();
  const { token, documentId } = web.state;
  lateProbe();
  assert.equal(web.jobs.length, 0);
  assert.equal(web.state.token, token);
  assert.equal(web.state.documentId, documentId);
});

test('an older install callback cannot replace a newer confirmed document', () => {
  const web = new WebViewModel(A);
  web.start();
  web.commit(A);
  web.take('probe').execute()();
  const oldCallback = web.take('install').execute();
  web.replace(A);
  web.finish(A);
  web.flush();
  const documentId = web.state.documentId;
  oldCallback();
  assert.equal(web.state.documentId, documentId);
  assert.equal(web.state.confirmedAttempt, 2);
});

test('stale generation cannot overwrite a rekeyed client', () => {
  const web = loaded();
  web.initialize();
  web.take('probe').execute()();
  const oldInstall = web.take('install');
  web.start();
  web.commit(A);
  web.flush();
  const token = web.state.token;
  oldInstall.execute()();
  assert.equal(web.page.window.__emCredentialClient.token, token);
});

test('probe refuses an iframe, a different actual URL, and an untrusted destination', () => {
  const iframe = new WebViewModel(A);
  iframe.start();
  iframe.page.window.top = {};
  iframe.commit(A);
  iframe.flush();
  assert.equal(iframe.state.documentId, null);

  const mismatched = new WebViewModel(A);
  mismatched.start();
  mismatched.commit(A);
  mismatched.page.location.href = B;
  mismatched.flush();
  assert.equal(mismatched.state.documentId, null);

  for (const url of ['http://accounts.google.com/signin', 'https://accounts.google.com.evil.example/',
    'https://accounts.google.com:444/', 'https://user@accounts.google.com/']) {
    const web = new WebViewModel(url);
    web.start();
    web.commit(url);
    web.finish(url);
    assert.equal(web.jobs.length, 0, url);
  }
});

test('foreground and tab return retry an already committed page', () => {
  const web = new WebViewModel(A);
  web.start();
  web.foreground = false;
  web.commit(A);
  assert.equal(web.jobs.length, 0);
  web.foreground = true;
  web.initialize();
  web.flush();
  assert.ok(web.state.documentId);
  const client = web.page.window.__emCredentialClient;
  web.active = false;
  web.initialize();
  assert.equal(web.jobs.length, 0);
  web.active = true;
  web.initialize();
  web.flush();
  assert.equal(web.page.window.__emCredentialClient, client);
});

test('wrong origin, subframe, background, and inactive tab cannot use the bridge', () => {
  const web = loaded();
  const message = { token: web.state.token, documentId: web.state.documentId, url: A };
  assert.ok(web.accepts(message));
  assert.equal(web.accepts(message, { origin: 'https://accounts.google.com.evil.example' }), false);
  assert.equal(web.accepts(message, { origin: 'http://accounts.google.com' }), false);
  assert.equal(web.accepts(message, { main: false }), false);
  assert.equal(web.accepts({ ...message, documentId: 'old-document' }), false);
  assert.equal(web.accepts({ ...message, url: B }), false);
  web.foreground = false;
  assert.equal(web.accepts(message), false);
  web.foreground = true;
  web.active = false;
  assert.equal(web.accepts(message), false);
  web.active = true;
  web.initialize();
  web.flush();
  assert.ok(web.accepts(message));
});
