const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const section = source.slice(source.indexOf('private fun probeBackupLink('), source.indexOf('private fun clearPasswordAutomationState('));
const script = section.match(/val script = """([\s\S]*?)"""\.trimIndent\(\)/)[1];

function fixture(options = {}) {
  let clicks = 0;
  const url = options.url || 'https://myaccount.google.com/two-step-verification';
  const base = {isConnected: true, parentElement: null, hidden: false,
    getBoundingClientRect: () => ({width: 100, height: 20})};
  const avatar = {...base, getAttribute: name => name === 'aria-label' ? `Google Account: ${options.avatar ?? 'user@example.com'}` : ''};
  const link = {...base, innerText: 'Backup codes Get backup codes', target: '',
    getAttribute: name => name === 'href' ? (options.href ?? 'two-step-verification/backup-codes') : '',
    hasAttribute: name => name === 'download' && !!options.download, click: () => clicks++};
  const document = {baseURI: options.baseURI || url, readyState: 'complete', visibilityState: options.visibility || 'visible', body: {innerText: options.body || ''},
    querySelectorAll: selector => selector === '[aria-label],[title]' ? [avatar] :
      selector === 'a.RlFDUe.mlgsfe[href]' ? (options.links ?? [link]) : []};
  const window = {EMRecoveryGuard: {permitted: () => typeof options.permitted === 'function' ? options.permitted() : options.permitted !== false}};
  window.top = options.subframe ? {} : window;
  const context = vm.createContext({document, window, location: new URL(url), URL,
    getComputedStyle: el => ({display: el.hidden ? 'none' : 'block', visibility: 'visible', opacity: '1'})});
  const code = script.replaceAll("${'$'}", '$').replace('${JSONObject.quote(url)}', JSON.stringify(url))
    .replace('${JSONObject.quote(permit)}', '"permit"').replace('${JSONObject.quote(account)}', JSON.stringify(options.account ?? 'user@example.com'));
  return {run: () => vm.runInContext(code, context), clicks: () => clicks, link, document};
}

test('clicks the visible matching anchor once', () => {
  const f = fixture();
  assert.equal(f.run(), 'clicked');
  assert.equal(f.run(), 'waiting');
  assert.equal(f.clicks(), 1);
});

test('opens backup codes regardless of how many codes are available', () => {
  for (const label of ['Backup codes 0 codes available', 'Backup codes 1 code available', 'Backup codes 9 codes available', 'Backup codes 10 codes available', 'Backup codes']) {
    const f = fixture();
    f.link.innerText = label;
    assert.equal(f.run(), 'clicked', label);
    assert.equal(f.clicks(), 1);
  }
});

test('resolves relative links against the document base and rejects an unsafe base', () => {
  const safe = fixture({url: 'https://myaccount.google.com/signinoptions/twosv', baseURI: 'https://myaccount.google.com/'});
  assert.equal(safe.run(), 'clicked');
  assert.equal(safe.clicks(), 1);
  const unsafe = fixture({baseURI: 'https://evil.test/'});
  assert.equal(unsafe.run(), 'waiting');
  assert.equal(unsafe.clicks(), 0);
  const wrongPath = fixture({baseURI: 'https://myaccount.google.com/unrelated/'});
  assert.equal(wrongPath.run(), 'waiting');
  assert.equal(wrongPath.clicks(), 0);
});

test('wrong destination, account, visibility or verification never clicks', () => {
  for (const options of [
    {href: 'https://evil.test/two-step-verification/backup-codes'},
    {href: '/two-step-verification/backup-codes-extra'}, {href: 'javascript:alert(1)'},
    {avatar: 'other@example.com'}, {account: ''}, {visibility: 'hidden'},
    {url: 'https://evil.test/two-step-verification'}, {subframe: true},
    {body: 'Verify your identity'}, {permitted: false}, {download: true}, {links: []},
  ]) {
    const f = fixture(options); f.run(); assert.equal(f.clicks(), 0, JSON.stringify(options));
  }
});

test('hidden, mislabeled, new-tab and ambiguous links wait', () => {
  for (const mutate of [f => f.link.hidden = true, f => f.link.innerText = 'Unrelated section',
    f => f.link.target = '_blank', f => f.document.querySelectorAll = selector =>
      selector === '[aria-label],[title]' ? [{isConnected: true, parentElement: null, getBoundingClientRect: () => ({width: 1, height: 1}), getAttribute: n => n === 'aria-label' ? 'Google Account: user@example.com' : ''}] :
      selector === 'a.RlFDUe.mlgsfe[href]' ? [f.link, f.link] : []]) {
    const f = fixture(); mutate(f); f.run(); assert.equal(f.clicks(), 0);
  }
});

test('handoff is account bound and confirmed two-step is required independently of the toggle', () => {
  assert.match(source, /setOf\("password", "authenticator", "two_step", "backup"/);
  assert.doesNotMatch(source, /twoStepAutomationEnabled && !isStageCompleted\("two_step", view\)/);
  assert.match(source, /if \(!isBackupTwoStepConfirmed\(view\)\)/);
  assert.match(section, /backupAutomationProbeInFlight \|\| !isBackupTwoStepConfirmed\(view\)/);
  assert.match(section, /backupAutomationDocumentGeneration != documentGeneration/);
  assert.match(section, /recoveryActionPermit == permit/);
});

test('skipped two-step, account changes and a toggle during a queued click fail closed', () => {
  // Evaluate the production Kotlin predicate after translating its simple expression to JS.
  const helper = source.slice(source.indexOf('private fun isBackupTwoStepConfirmed('), source.indexOf('private fun isBackupCodesUrl('));
  const expression = helper.match(/return ([\s\S]*?)\n    }/)[1]
    .replace('account.isNotBlank()', '!!account')
    .replace('detected.isBlank()', '!detected')
    .replace('completedStagesByAccount[account]?.contains("two_step") == true', 'completed.has(account)');
  const confirmed = new Function('account', 'detected', 'completed', `return ${expression}`);
  const account = 'user@example.com';
  const completed = new Set();
  let permit = false;
  const f = fixture({permitted: () => permit});
  const dispatch = (detected, enabled) => {
    // The setting selects the two-step stage, but never substitutes for completion.
    if (!confirmed(account, detected, completed)) return 'waiting';
    permit = true;
    return 'queued';
  };
  assert.equal(dispatch(account, false), 'waiting');
  assert.equal(f.clicks(), 0);
  completed.add('other@example.com');
  assert.equal(dispatch(account, true), 'waiting');
  completed.add(account);
  assert.equal(dispatch('other@example.com', true), 'waiting');
  assert.equal(dispatch(account, true), 'queued');
  // Disabling 2-Step revokes the issued permit and removes its completion record.
  permit = false;
  completed.delete(account);
  assert.equal(f.run(), 'waiting');
  assert.equal(dispatch(account, false), 'waiting');
  assert.equal(f.clicks(), 0);
  completed.add(account);
  assert.equal(dispatch(account, false), 'queued');
  assert.equal(f.run(), 'clicked');
});

test('completion invalidation revokes queued actions and callback rechecks before saving', () => {
  const toggle = source.slice(source.indexOf('addSettingRow("2-Step"'), source.indexOf('addSettingRow("Backup"'));
  const clear = source.slice(source.indexOf('private fun clearStageCompleted('), source.indexOf('// Single hand-off point'));
  const probe = source.slice(source.indexOf('private fun probeBackupAutomation('), source.indexOf('private fun probeBackupLink('));
  assert.match(toggle, /recoveryActionPermit = ""/);
  assert.match(toggle, /clearStageCompleted\("two_step", ownerAccount/);
  assert.match(clear, /stage == "two_step"[\s\S]*recoveryActionPermit = ""/);
  assert.match(clear, /private fun clearAllStagesForAccount[\s\S]*recoveryActionPermit = ""/);
  assert.match(probe, /EMRecoveryGuard\.permitted\(\$\{JSONObject\.quote\(permit\)\}\)/);
  assert.match(probe, /googleVerificationActive \|\| googleVerificationCheckPending \|\| !isBackupTwoStepConfirmed\(view\)/);
});
