const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const probe = source.split('private fun probeAddSignIn(')[1].split('\n    private fun ')[0];
const script = probe.split('val script = """')[1].split('""".trimIndent()')[0]
  .replace('${JSONObject.quote(row.email.lowercase(Locale.US))}', JSON.stringify('person@example.test'));

function run(labels, options = {}) {
  const element = (label, visible = true) => ({
    getBoundingClientRect: () => ({ width: visible ? 10 : 0, height: 10 }),
    getAttribute: name => name === 'aria-label' ? label : null,
  });
  const window = {};
  window.top = options.frame ? {} : window;
  const document = {
    readyState: options.loading ? 'loading' : 'complete',
    visibilityState: options.hidden ? 'hidden' : 'visible',
    querySelectorAll: selector => selector.startsWith('[aria-label]')
      ? labels.map(l => element(l.text, l.visible !== false))
      : options.password ? [element('')] : [],
  };
  return vm.runInNewContext(script, { window, document, getComputedStyle: () => ({ display: 'block', visibility: 'visible' }) });
}

test('signed-in indicator must be visible, unique, and match the queued account', () => {
  assert.equal(run([{ text: 'Google Account: Person (person@example.test)' }]), true);
  assert.equal(run([{ text: 'Google Account: other@example.test' }]), false);
  assert.equal(run([{ text: 'Google Account: person@example.test', visible: false }]), false);
  assert.equal(run([{ text: 'Google Account: person@example.test' }, { text: 'Google Account: other@example.test' }]), false);
  assert.equal(run([{ text: 'person@example.test' }]), false);
});

test('challenges, hidden documents, loading, and frames cannot confirm', () => {
  const labels = [{ text: 'Google Account: person@example.test' }];
  for (const flag of ['password', 'hidden', 'loading', 'frame']) assert.equal(run(labels, { [flag]: true }), false);
});

test('queue stages without backup codes and callbacks retain run, document and view ownership', () => {
  const load = source.split('private fun loadAddRow()')[1].split('\n    private fun ')[0];
  assert.match(load, /saveCredentialRow\(row\.copy\(backupCodes = emptyList\(\)\)\)/);
  assert.match(load, /appendQueryParameter\("login_hint", row\.email\)/);
  assert.match(load, /appendQueryParameter\("continue", "https:\/\/myaccount\.google\.com\/"\)/);
  assert.match(probe, /detectGoogleAccountKey\(view, true\)/);
  assert.match(probe, /addGeneration == generation/);
  assert.match(probe, /credentialDocuments\[view\] === document/);
  assert.match(probe, /view === currentWebView\(\)/);
  assert.match(probe, /!current\(\) \|\| result != "true"/);
  assert.match(source, /addSignInConfirmedAt/);
});
