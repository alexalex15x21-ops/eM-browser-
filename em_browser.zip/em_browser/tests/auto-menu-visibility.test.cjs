const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const menu = source.split('private fun addAutomationMasterMenuItem()')[1].split('\n    private fun ')[0];

test('Auto stages stay visible and the master switch remains available', () => {
  assert.doesNotMatch(menu, /settingsLayout\.visibility|visibility\s*=\s*View\.GONE/);
  assert.match(menu, /container\.addView\(settingsLayout/);
  assert.match(menu, /createAutomationToggle\(automationMasterEnabled\)/);
  assert.match(menu, /settingsLayout\.addView\(settingRow/);
});
