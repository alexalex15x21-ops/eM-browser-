const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require('node:path').join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const section = source.split('private fun schedulePageNext(')[1].split('private fun showAddDialog()')[0];
const script = section.match(/val script = """([\s\S]*?)"""\.trimIndent\(\)/)[1]
  .replace('${JSONObject.quote(url)}', JSON.stringify('https://accounts.google.com/form'))
  .replace('${blocked.toString()}', '{}');

function setup() {
  let clicks = 0;
  let time = 0;
  const field = {type:'text', value:'filled', name:'field', checked:false, disabled:false,
    readOnly:false, willValidate:true, checkValidity:()=>true, getAttribute:()=>null};
  const main = {querySelectorAll:()=>[field]};
  const button = {innerText:'Next', disabled:false, matches:()=>false, getAttribute:()=>null,
    closest:()=>main, click:()=>clicks++};
  const heading = {textContent:'Sign in'};
  const recovery = {textContent:'Confirm the recovery email address you added to your account: abc@gmail.com'};
  for (const el of [field, button, heading, recovery]) el.getBoundingClientRect = () => ({width:10,height:10});
  const document = {visibilityState:'visible', readyState:'complete', recovery:false,
    querySelectorAll: selector => selector.includes('h1.vAV9bf') ? [heading] : selector.includes('div.qWK5J') ? (document.recovery ? [recovery] : []) : [button]};
  const window = {}; window.top = window;
  const ctx = vm.createContext({window, document, location:{href:'https://accounts.google.com/form', origin:'https://accounts.google.com'}, performance:{now:()=>time},
    getComputedStyle:()=>({display:'block', visibility:'visible'})});
  return {field, button, heading, document, run:()=>vm.runInContext(script, ctx), clicks:()=>clicks, advance:ms=>time+=ms};
}
test('stops after the first dispatched click', () => {
  const x = setup(); x.run(); x.advance(1500); x.run(); assert.equal(x.clicks(), 1);
  assert.match(section, /if \(status == "clicked"\) state\.clicked = true/);
});
test('retries failed click calls at most three times with 1500 ms between attempts', () => {
  const x = setup(); let attempts = 0;
  x.button.click = () => { attempts++; throw new Error('failed'); };
  x.run(); x.run(); assert.equal(attempts, 1);
  x.advance(1499); x.run(); assert.equal(attempts, 1);
  x.advance(1); x.run(); assert.equal(attempts, 2);
  x.advance(1500); x.run(); assert.equal(attempts, 3);
  x.advance(1500); x.run(); assert.equal(attempts, 3);
  assert.match(section, /pageNextLoadedUrls\[view\] == url/);
  assert.match(section, /state\.clicks >= 3/);
  assert.match(section, /now - state\.lastClickAt < 1500L/);
});
test('each recognized stage can click once, including variable recovery addresses', () => {
  const x = setup(); x.run();
  x.heading.textContent = 'Welcome'; x.run();
  x.heading.textContent = '2-Step Verification'; x.run();
  x.document.recovery = true; x.run(); x.run();
  assert.equal(x.clicks(), 4);
  x.document.recovery = false; x.heading.textContent = 'Unknown'; x.run();
  assert.equal(x.clicks(), 4);
});
test('does not click when empty, invalid, disabled, hidden or ambiguous', () => {
  for (const change of [
    x => x.field.value = '', x => x.field.checkValidity = () => false,
    x => x.button.disabled = true, x => x.document.visibilityState = 'hidden', x => x.document.readyState = 'loading',
    x => x.document.querySelectorAll = () => [x.button, x.button]
  ]) { const x = setup(); change(x); x.run(); assert.equal(x.clicks(), 0); }
});
test('Copy All decrypts all current skipped rows', () => {
  const skipped = source.split('private fun showSkippedAccountsDialog()')[1].split('private fun createAutomationToggle(')[0];
  assert.match(skipped, /setNegativeButton\("Copy All"/);
  assert.match(skipped, /\(0 until rows\.length\(\)\)\.map \{ decryptRow\(it\) \}/);
});
