const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require('node:path').join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const section = source.split('private fun schedulePageNext(')[1].split('private fun showAddDialog()')[0];
const script = section.match(/val script = """([\s\S]*?)"""\.trimIndent\(\)/)[1]
  .replace('${JSONObject.quote(url)}', JSON.stringify('https://example.com/form'));

function setup() {
  let clicks = 0;
  const field = {type:'text', value:'filled', name:'field', checked:false, disabled:false,
    readOnly:false, willValidate:true, checkValidity:()=>true, getAttribute:()=>null};
  const main = {querySelectorAll:()=>[field]};
  const button = {innerText:'Next', disabled:false, matches:()=>false, getAttribute:()=>null,
    closest:()=>main, click:()=>clicks++};
  for (const el of [field, button]) el.getBoundingClientRect = () => ({width:10,height:10});
  const document = {visibilityState:'visible', readyState:'complete', querySelectorAll:()=>[button]};
  const window = {}; window.top = window;
  const ctx = vm.createContext({window, document, location:{href:'https://example.com/form'},
    getComputedStyle:()=>({display:'block', visibility:'visible'})});
  return {field, button, document, run:()=>vm.runInContext(script, ctx), clicks:()=>clicks};
}
test('clicks once for a filled valid field and again only after the data changes', () => {
  const x = setup(); x.run(); x.run(); assert.equal(x.clicks(), 1);
  x.field.value = 'changed'; x.run(); assert.equal(x.clicks(), 2);
});
test('does not click when empty, invalid, disabled, hidden or ambiguous', () => {
  for (const change of [
    x => x.field.value = '', x => x.field.checkValidity = () => false,
    x => x.button.disabled = true, x => x.document.visibilityState = 'hidden',
    x => x.document.querySelectorAll = () => [x.button, x.button]
  ]) { const x = setup(); change(x); x.run(); assert.equal(x.clicks(), 0); }
});
test('Copy All decrypts all current skipped rows', () => {
  const skipped = source.split('private fun showSkippedAccountsDialog()')[1].split('private fun createAutomationToggle(')[0];
  assert.match(skipped, /setNegativeButton\("Copy All"/);
  assert.match(skipped, /\(0 until rows\.length\(\)\)\.map \{ decryptRow\(it\) \}/);
});
