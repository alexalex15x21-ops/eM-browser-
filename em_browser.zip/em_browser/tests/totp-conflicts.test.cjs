const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
function scriptIn(name) {
  const start = source.indexOf(`private fun ${name}(`);
  assert.ok(start >= 0, `missing ${name}`);
  const match = source.slice(start).match(/val script = """([\s\S]*?)"""\.trimIndent\(\)/);
  assert.ok(match, `missing script in ${name}`);
  return match[1];
}
const autofill = scriptIn('injectCredentialAutofill');
const setup = scriptIn('fillAndSubmitAuthenticatorCode')
  .replace('$codeJson', JSON.stringify('445566')).replace('$stepJson', '42');

class Input {
  constructor(value = '') {
    this.value = value;
    this.id = 'totpPin';
    this.name = 'totpPin';
    this.type = 'text';
    this.maxLength = 6;
    this.isConnected = true;
    this.offsetParent = {};
    this.parentElement = null;
    this.listeners = {};
  }
  getBoundingClientRect() { return {width: 100, height: 20}; }
  getAttribute(name) { return name === 'aria-label' ? 'Enter code' : ''; }
  matches() { return false; }
  addEventListener(name, callback) { (this.listeners[name] ||= []).push(callback); }
  removeEventListener(name, callback) { this.listeners[name] = (this.listeners[name] || []).filter(fn => fn !== callback); }
  dispatchEvent(event) { for (const callback of this.listeners[event.type] || []) callback(event); }
}

function page(url, {guard = false, initial = ''} = {}) {
  const location = new URL(url);
  const input = new Input(initial);
  const parent = {
    parentElement: null, getBoundingClientRect: () => ({width: 100, height: 20}),
    closest: () => null, matches: () => false,
  };
  const text = {parentElement: parent, nodeValue: 'Google Authenticator app'};
  let resolve;
  let calls = 0;
  let clicks = 0;
  const button = {
    offsetParent: {}, disabled: false, innerText: 'Verify',
    getAttribute: () => '', click: () => { clicks++; },
  };
  const window = {
    __emAuthenticatorSetupClickIssued: guard,
    __emCredentialRequest(operation) {
      assert.equal(operation, 'totp');
      calls++;
      return new Promise(done => { resolve = done; });
    },
  };
  window.top = window;
  const document = {
    body: {}, documentElement: {},
    querySelector: () => null,
    querySelectorAll(selector) {
      if (selector === 'input') return [input];
      if (selector === 'button,input[type=submit],[role=button]') return [button];
      return [];
    },
    createTreeWalker() {
      let done = false;
      return {currentNode: null, nextNode() { if (done) return false; done = true; this.currentNode = text; return true; }};
    },
  };
  const context = vm.createContext({
    window, document, location, HTMLInputElement: Input,
    getComputedStyle: () => ({display: 'block', visibility: 'visible', opacity: '1'}),
    NodeFilter: {SHOW_TEXT: 4},
    Event: class { constructor(type) { this.type = type; } },
    MutationObserver: class { observe() {} }, setInterval() {},
  });
  return {context, window, input, get calls() { return calls; }, get clicks() { return clicks; },
    reply(code = '112233') { resolve(JSON.stringify({code, expiresAt: Date.now() + 60000})); }};
}

test('setup field is reserved for the new key and dedicated setup still submits', () => {
  const p = page('https://myaccount.google.com/two-step-verification/authenticator', {guard: true});
  vm.runInContext(autofill, p.context);
  assert.equal(p.calls, 0);
  assert.equal(vm.runInContext(setup, p.context), 'submitted');
  assert.equal(p.input.value, '445566');
  assert.equal(p.clicks, 1);
});

test('a generic reply already in flight cannot fill after setup begins', async () => {
  const p = page('https://myaccount.google.com/two-step-verification/authenticator');
  vm.runInContext(autofill, p.context);
  assert.equal(p.calls, 1);
  p.window.__emAuthenticatorSetupClickIssued = true;
  p.reply();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(p.input.value, '');
  assert.equal(vm.runInContext(setup, p.context), 'submitted');
  assert.equal(p.input.value, '445566');
});

test('sign-in and reauthentication TOTP remain available outside the setup field', async () => {
  for (const url of [
    'https://accounts.google.com/challenge/totp',
    'https://accounts.google.com/two-step-verification/authenticator',
    'https://myaccount.google.com/security/verify',
    'https://myaccount.google.com/two-step-verification/authenticator',
  ]) {
    const p = page(url, {guard: !url.endsWith('/authenticator') || url.startsWith('https://accounts.')});
    vm.runInContext(autofill, p.context);
    assert.equal(p.calls, 1, url);
    p.reply();
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(p.input.value, '112233', url);
  }
});

test('dedicated setup does not overwrite a manually entered code', () => {
  const p = page('https://myaccount.google.com/two-step-verification/authenticator', {guard: true, initial: '987654'});
  assert.equal(vm.runInContext(setup, p.context), 'user_input');
  assert.equal(p.input.value, '987654');
  assert.equal(p.clicks, 0);
});

test('native setup guard is scoped to the owner, stage, host and route', () => {
  const bridge = source.slice(source.indexOf('"totp" -> {'), source.indexOf('else -> return', source.indexOf('"totp" -> {')));
  for (const guard of ['authenticatorAutomationView === view', 'setOf("qr", "code")',
    'originHost == "myaccount.google.com"', '/two-step-verification/authenticator']) assert.ok(bridge.includes(guard));
});
