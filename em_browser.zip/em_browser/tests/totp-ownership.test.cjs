// Runs the production import method with small in-memory preference/store fixtures.
// Use kotlinc on PATH, or set GRADLE_KOTLIN_LIB to a Gradle lib directory.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {spawnSync} = require('node:child_process');

test('imported TOTP ownership and legacy store cases', t => {
  const java = process.env.JAVA_HOME ? path.join(process.env.JAVA_HOME, 'bin/java') : 'java';
  const lib = process.env.GRADLE_KOTLIN_LIB;
  if (!lib && spawnSync('kotlinc', ['-version']).error) return t.skip('kotlinc unavailable');
  const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
  const fixture = fs.readFileSync(path.join(__dirname, 'totp-ownership-fixture.kt'), 'utf8');
  const start = source.indexOf('    private fun saveCredentialRow(');
  const end = source.indexOf('    private fun loadStagedSignInCredentials()', start);
  assert.ok(start >= 0 && end > start);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em-totp-owner-'));
  try {
    const kotlin = path.join(dir, 'OwnerFixture.kt');
    const jar = path.join(dir, 'owner.jar');
    fs.writeFileSync(kotlin, fixture.replace('    /* INSERT_PRODUCTION_METHOD */', source.slice(start, end)));
    let compiler, args, runArgs;
    if (lib) {
      const stdlib = fs.readdirSync(lib).find(name => /^kotlin-stdlib-[0-9].*\.jar$/.test(name));
      assert.ok(stdlib, 'Kotlin standard library not found');
      const stdlibPath = path.join(lib, stdlib);
      compiler = java;
      args = ['-cp', path.join(lib, '*'), 'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler', '-no-stdlib', '-no-reflect', '-classpath', stdlibPath, '-d', jar, kotlin];
      runArgs = ['-cp', [jar, stdlibPath].join(path.delimiter), 'OwnerFixtureKt'];
    } else {
      compiler = 'kotlinc';
      args = [kotlin, '-include-runtime', '-d', jar];
      runArgs = ['-jar', jar];
    }
    const compiled = spawnSync(compiler, args, {encoding: 'utf8', timeout: 60000});
    assert.equal(compiled.status, 0, compiled.stderr || String(compiled.error));
    const run = spawnSync(java, runArgs, {encoding: 'utf8', timeout: 30000});
    assert.equal(run.status, 0, run.stderr || String(run.error));
    assert.match(run.stdout, /Owner cases passed/);
  } finally {
    fs.rmSync(dir, {recursive: true, force: true});
  }
});
