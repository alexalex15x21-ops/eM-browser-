// Compiles and runs the real recovery target methods with in-memory Kotlin stubs.
// Use kotlinc on PATH, or set GRADLE_KOTLIN_LIB to a Gradle lib directory.
const {before, after, test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {spawnSync} = require('node:child_process');

const java = process.env.JAVA_HOME ? path.join(process.env.JAVA_HOME, 'bin/java') : 'java';
const lib = process.env.GRADLE_KOTLIN_LIB;
let dir, runArgs;

before(() => {
  const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
  const fixture = fs.readFileSync(path.join(__dirname, 'recovery-target-fixture.kt'), 'utf8');
  function method(name) {
    const start = source.indexOf(`    private fun ${name}(`);
    assert.notEqual(start, -1, `missing production method ${name}`);
    const end = source.indexOf('\n    private fun ', start + 1);
    assert.ok(end > start, `missing method boundary after ${name}`);
    return source.slice(start, end);
  }
  const marker = '    /* INSERT_PRODUCTION_METHODS */';
  assert.ok(fixture.includes(marker), 'missing fixture insertion marker');
  const methods = ['recoveryTargetForAccount', 'saveRecoveryTarget', 'clearStageCompleted'].map(method).join('\n\n');
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em-recovery-target-'));
  const kotlin = path.join(dir, 'RecoveryTargetFixture.kt');
  const jar = path.join(dir, 'recovery-target.jar');
  fs.writeFileSync(kotlin, fixture.replace(marker, methods));

  let compiler, args;
  if (lib) {
    const stdlib = fs.readdirSync(lib).find(name => /^kotlin-stdlib-[0-9].*\.jar$/.test(name));
    assert.ok(stdlib, 'Kotlin standard library not found');
    const stdlibPath = path.join(lib, stdlib);
    compiler = java;
    args = ['-cp', path.join(lib, '*'), 'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler', '-no-stdlib', '-no-reflect', '-classpath', stdlibPath, '-d', jar, kotlin];
    runArgs = ['-cp', [jar, stdlibPath].join(path.delimiter), 'RecoveryTargetFixtureKt'];
  } else {
    compiler = 'kotlinc';
    args = [kotlin, '-include-runtime', '-d', jar];
    runArgs = ['-jar', jar];
  }
  const compiled = spawnSync(compiler, args, {encoding: 'utf8', timeout: 60000});
  assert.equal(compiled.status, 0, compiled.stderr || String(compiled.error));
});

after(() => {
  if (dir) fs.rmSync(dir, {recursive: true, force: true});
});

for (const [name, description] of [
  ['isolation', 'account targets are isolated; account keys and target whitespace are normalized'],
  ['completion', 'changing or clearing a target invalidates only that account recovery completion'],
  ['first-target', 'a newly assigned target invalidates stale recovery completion'],
  ['unchanged', 'an unchanged target does not invalidate completion or pending action'],
  ['permit', 'a changed or cleared target revokes only its active owner pending action'],
  ['legacy', 'a legacy global recovery value is not silently assigned to an account'],
  ['blank-account', 'a blank account cannot mutate targets, completion or pending action'],
]) {
  test(description, () => {
    const result = spawnSync(java, [...runArgs, name], {encoding: 'utf8', timeout: 30000});
    assert.equal(result.status, 0, result.stderr || String(result.error));
    assert.match(result.stdout, new RegExp(`Recovery target case passed: ${name}`));
  });
}
