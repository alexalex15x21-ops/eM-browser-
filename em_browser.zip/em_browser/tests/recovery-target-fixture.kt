import java.util.Locale

// This stub supports the string-valued JSON objects used by recovery targets.
class JSONObject() {
    private val fields = linkedMapOf<String, String>()

    constructor(raw: String) : this() {
        var index = 0
        fun whitespace() { while (index < raw.length && raw[index].isWhitespace()) index++ }
        fun consume(char: Char) {
            whitespace()
            require(index < raw.length && raw[index++] == char) { "Invalid JSON" }
        }
        fun string(): String {
            consume('"')
            val result = StringBuilder()
            while (index < raw.length) {
                when (val char = raw[index++]) {
                    '"' -> return result.toString()
                    '\\' -> {
                        require(index < raw.length) { "Invalid escape" }
                        when (val escape = raw[index++]) {
                            '"', '\\', '/' -> result.append(escape)
                            'b' -> result.append('\b')
                            'f' -> result.append('\u000c')
                            'n' -> result.append('\n')
                            'r' -> result.append('\r')
                            't' -> result.append('\t')
                            'u' -> {
                                require(index + 4 <= raw.length) { "Invalid Unicode escape" }
                                result.append(raw.substring(index, index + 4).toInt(16).toChar())
                                index += 4
                            }
                            else -> error("Invalid escape")
                        }
                    }
                    else -> {
                        require(char >= ' ') { "Invalid JSON string" }
                        result.append(char)
                    }
                }
            }
            error("Unterminated JSON string")
        }
        consume('{')
        whitespace()
        if (index < raw.length && raw[index] != '}') {
            while (true) {
                val key = string()
                consume(':')
                fields[key] = string()
                whitespace()
                if (index < raw.length && raw[index] == ',') index++ else break
            }
        }
        consume('}')
        whitespace()
        require(index == raw.length) { "Invalid JSON suffix" }
    }

    fun optString(key: String): String = fields[key].orEmpty()
    fun has(key: String): Boolean = fields.containsKey(key)
    fun put(key: String, value: String) = apply { fields[key] = value }
    fun remove(key: String) = fields.remove(key)
    override fun toString(): String {
        fun quote(value: String): String = buildString {
            append('"')
            for (char in value) when (char) {
                '"', '\\' -> { append('\\'); append(char) }
                else -> if (char < ' ') append("\\u%04x".format(char.code)) else append(char)
            }
            append('"')
        }
        return fields.entries.joinToString(",", "{", "}") { (key, value) -> "${quote(key)}:${quote(value)}" }
    }
}

class Preferences {
    val values = mutableMapOf<String, String>()
    var writes = 0
    fun getString(key: String, default: String?): String? = values[key] ?: default
    fun edit() = Editor(this)

    class Editor(private val prefs: Preferences) {
        private val changes = mutableMapOf<String, String>()
        fun putString(key: String, value: String) = apply { changes[key] = value }
        fun apply() {
            prefs.values.putAll(changes)
            prefs.writes++
        }
    }
}

class Fixture {
    private val PREFS = "prefs"
    private val MODE_PRIVATE = 0
    val KEY_RECOVERY_TARGETS = "recovery_targets_by_account"
    val KEY_RECOVERY_EMAIL_VALUE = "recovery_email_value"
    val prefs = Preferences()
    val completedStagesByAccount = mutableMapOf<String, MutableSet<String>>()
    var persistedStages = mapOf<String, Set<String>>()
    var completionWrites = 0
    var devicesAutomationActive = false
    var devicesAutomationAccount = ""
    var recoveryActionPermit = ""

    fun getSharedPreferences(name: String, mode: Int): Preferences {
        check(name == PREFS && mode == MODE_PRIVATE)
        return prefs
    }
    fun accountKeyForStages(): String = error("Expected an explicit account")
    fun saveCompletedStages() {
        persistedStages = completedStagesByAccount.mapValues { it.value.toSet() }
        completionWrites++
    }
    fun target(account: String) = recoveryTargetForAccount(account)
    fun save(account: String, target: String) = saveRecoveryTarget(account, target)
    fun seedStages() {
        completedStagesByAccount[A] = mutableSetOf("recovery_set", "password")
        completedStagesByAccount[B] = mutableSetOf("recovery_set", "two_step")
        saveCompletedStages()
        completionWrites = 0
    }

    /* INSERT_PRODUCTION_METHODS */
}

private const val A = "alice@example.com"
private const val B = "bob@example.com"
private const val TARGET_A = "Recovery.A@Example.com"
private const val TARGET_B = "recovery.b@example.com"

private fun expect(actual: Any?, expected: Any?, message: String) {
    check(actual == expected) { "$message: expected <$expected>, got <$actual>" }
}

private fun isolationAndNormalization() {
    Locale.setDefault(Locale.forLanguageTag("tr-TR"))
    val f = Fixture()
    f.save("  ALICE@EXAMPLE.COM \t", "  $TARGET_A  ")
    f.save("Bob@Example.Com", "\t$TARGET_B\n")
    expect(f.target(A), TARGET_A, "Alice target is trimmed and case-preserved")
    expect(f.target(" \tAlIcE@EXAMPLE.COM\n"), TARGET_A, "Alice lookup normalizes account")
    expect(f.target(" BOB@EXAMPLE.COM "), TARGET_B, "Bob lookup normalizes account")
    expect(f.target("third@example.com"), "", "Unrelated account has no target")
    val stored = JSONObject(f.prefs.getString(f.KEY_RECOVERY_TARGETS, "{}").orEmpty())
    expect(stored.optString(A), TARGET_A, "Alice stored under normalized key")
    expect(stored.optString(B), TARGET_B, "Bob stored under normalized key")
    expect(stored.optString("ALICE@EXAMPLE.COM"), "", "No uppercase duplicate key")
    f.save(" ALICE@EXAMPLE.COM ", "new@example.com")
    expect(f.target(A), "new@example.com", "Alice target updated")
    expect(f.target(B), TARGET_B, "Bob target survives Alice update")
    f.save(A, " ")
    expect(f.target(A), "", "Alice target removed")
    expect(f.target(B), TARGET_B, "Bob target survives Alice removal")
    val afterClear = JSONObject(f.prefs.getString(f.KEY_RECOVERY_TARGETS, "{}").orEmpty())
    expect(afterClear.has(A), false, "Alice key is removed rather than left empty")
    expect(afterClear.has(B), true, "Bob key remains after Alice removal")
}

private fun changedAndClearedCompletion() {
    val f = Fixture()
    f.save(A, TARGET_A)
    f.save(B, TARGET_B)
    f.seedStages()
    f.save(" ALICE@EXAMPLE.COM ", "new@example.com")
    expect(f.completedStagesByAccount[A], setOf("password"), "Change clears only Alice recovery")
    expect(f.completedStagesByAccount[B], setOf("recovery_set", "two_step"), "Change preserves Bob stages")
    expect(f.persistedStages[A], setOf("password"), "Change persists Alice completion")
    expect(f.persistedStages[B], setOf("recovery_set", "two_step"), "Change persists Bob unchanged")
    expect(f.completionWrites, 1, "Change persists completion once")
    f.completedStagesByAccount.getValue(A).add("recovery_set")
    f.save(A, " \t\n")
    expect(f.target(A), "", "Whitespace clears Alice target")
    expect(f.target(B), TARGET_B, "Clear preserves Bob target")
    expect(f.completedStagesByAccount[A], setOf("password"), "Clear removes only Alice recovery")
    expect(f.completedStagesByAccount[B], setOf("recovery_set", "two_step"), "Clear preserves Bob stages")
    expect(f.persistedStages[A], setOf("password"), "Clear persists Alice completion")
    expect(f.persistedStages[B], setOf("recovery_set", "two_step"), "Clear persists Bob unchanged")
    expect(f.completionWrites, 2, "Clear persists completion once")
}

private fun firstTargetInvalidatesCompletion() {
    val f = Fixture()
    f.seedStages()
    f.save(" ALICE@EXAMPLE.COM ", TARGET_A)
    expect(f.completedStagesByAccount[A], setOf("password"), "First target clears stale recovery completion")
    expect(f.completedStagesByAccount[B], setOf("recovery_set", "two_step"), "First target preserves Bob stages")
    expect(f.persistedStages[A], setOf("password"), "First target persists invalidation")
}

private fun unchangedTargetDoesNotInvalidate() {
    val f = Fixture()
    f.save(A, TARGET_A)
    f.seedStages()
    f.devicesAutomationActive = true
    f.devicesAutomationAccount = A
    f.recoveryActionPermit = "pending"
    val writes = f.prefs.writes
    val raw = f.prefs.getString(f.KEY_RECOVERY_TARGETS, null)
    f.save(" ALICE@EXAMPLE.COM ", " \t$TARGET_A\n")
    f.save(B, "  ") // Bob has no target; clearing it again is a no-op.
    expect(f.target(A), TARGET_A, "Same trimmed target retained")
    expect(f.prefs.getString(f.KEY_RECOVERY_TARGETS, null), raw, "No target storage change")
    expect(f.prefs.writes, writes, "No target storage write")
    expect(f.completedStagesByAccount[A], setOf("recovery_set", "password"), "Alice completion retained")
    expect(f.completedStagesByAccount[B], setOf("recovery_set", "two_step"), "Bob completion retained")
    expect(f.completionWrites, 0, "No completion storage write")
    expect(f.recoveryActionPermit, "pending", "Unchanged owner target keeps pending action")
}

private fun pendingActionRevocation() {
    val f = Fixture()
    f.save(A, TARGET_A)
    f.save(B, TARGET_B)
    f.devicesAutomationActive = true
    f.devicesAutomationAccount = A
    f.recoveryActionPermit = "pending"
    f.save(" BOB@EXAMPLE.COM ", "bob-new@example.com")
    expect(f.recoveryActionPermit, "pending", "Another account cannot revoke owner action")
    f.save(" ALICE@EXAMPLE.COM ", "new@example.com")
    expect(f.recoveryActionPermit, "", "Changing owner target revokes pending action")
    f.recoveryActionPermit = "pending-again"
    f.save(A, " ")
    expect(f.recoveryActionPermit, "", "Clearing owner target revokes pending action")
    f.recoveryActionPermit = "still-pending"
    f.save(A, "")
    expect(f.recoveryActionPermit, "still-pending", "Repeated clear does not revoke")
    f.devicesAutomationActive = false
    f.save(A, TARGET_A)
    expect(f.recoveryActionPermit, "still-pending", "Inactive automation does not revoke")
}

private fun legacyGlobalNotAssigned() {
    val f = Fixture()
    f.prefs.edit().putString(f.KEY_RECOVERY_EMAIL_VALUE, "legacy@example.com").apply()
    expect(f.target(A), "", "Legacy value is not Alice target")
    expect(f.target(B), "", "Legacy value is not Bob target")
    f.save(A, " ")
    expect(f.prefs.getString(f.KEY_RECOVERY_TARGETS, null), null, "Blank save does not assign legacy value")
    f.save(A, TARGET_A)
    expect(f.target(A), TARGET_A, "Explicit target is saved")
    expect(f.target(B), "", "Legacy value is not assigned to Bob after Alice save")
    expect(f.prefs.getString(f.KEY_RECOVERY_EMAIL_VALUE, null), "legacy@example.com", "Legacy preference is untouched")
}

private fun blankAccountDoesNothing() {
    val f = Fixture()
    f.save(A, TARGET_A)
    f.seedStages()
    f.devicesAutomationActive = true
    f.devicesAutomationAccount = ""
    f.recoveryActionPermit = "pending"
    val writes = f.prefs.writes
    f.save(" \t\n", TARGET_B)
    expect(f.target(A), TARGET_A, "Blank account preserves Alice target")
    expect(f.target(""), "", "Blank account has no target")
    expect(f.prefs.writes, writes, "Blank account causes no preference write")
    expect(f.completionWrites, 0, "Blank account causes no completion write")
    expect(f.completedStagesByAccount[A], setOf("recovery_set", "password"), "Blank account preserves stages")
    expect(f.recoveryActionPermit, "pending", "Blank account does not revoke action")
}

fun main(args: Array<String>) {
    when (args.single()) {
        "isolation" -> isolationAndNormalization()
        "completion" -> changedAndClearedCompletion()
        "first-target" -> firstTargetInvalidatesCompletion()
        "unchanged" -> unchangedTargetDoesNotInvalidate()
        "permit" -> pendingActionRevocation()
        "legacy" -> legacyGlobalNotAssigned()
        "blank-account" -> blankAccountDoesNothing()
        else -> error("Unknown test case: ${args.single()}")
    }
    println("Recovery target case passed: ${args.single()}")
}
