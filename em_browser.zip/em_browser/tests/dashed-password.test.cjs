const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const pattern = source.match(/private val DASHED_PASSWORD = Regex\("([^"]+)"\)/)[1];
const passwordPattern = new RegExp(pattern, 'g');

test('mixed-case dashed passwords are masked intact before 2FA detection', () => {
  for (const password of ['abcDef-ghijK2-lmnopq', 'abcDef-ghijK2-lmnopqExtra', 'a1bCde-fG2hij-kLmno3']) {
    const input = `${password} ABCD EFGH IJKL MNOP`;
    const masked = input.replace(passwordPattern, match => '0'.repeat(match.length));
    assert.equal(masked, `${'0'.repeat(password.length)} ABCD EFGH IJKL MNOP`);
    assert.equal(masked.length, input.length);
  }
  assert.match(source, /DASHED_PASSWORD\.matches\(password\.trim\(\)\).*null else extractBase32Secret\(password\)/);
  assert.match(source, /extractBase32Secret\(secretSearchText\)/);
  assert.match(source, /remainder\.removeRange\(secretRange\)/);
});

test('grouped authenticator keys and adjacent text are not mistaken for dashed passwords', () => {
  for (const value of ['ABCD-EFGH-IJKL-MNOP', 'ABCDEF-GHIJKL-MNOPQR', 'ABCDEF-GHIJKL-MNOPQ2', 'xabcDef-ghijK2-lmnopq']) {
    assert.equal(value.replace(passwordPattern, 'MASKED'), value);
  }
});
