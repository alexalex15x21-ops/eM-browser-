const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const editor = source.split('private fun showAddEditor()')[1].split('\n    private fun ')[0];
const fill = source.split('private fun fillAddIdentifier(')[1].split('\n    private fun ')[0];
const url = 'https://accounts.google.com/v3/signin/identifier';
const script = fill.split('val script = """')[1].split('""".trimIndent()')[0]
  .replace('${JSONObject.quote(pageUrl)}', JSON.stringify(url))
  .replace('${JSONObject.quote(row.email)}', JSON.stringify('example@example.test'));

function run(options = {}) {
  class Input {
    constructor() { this._value = options.value || ''; this.type = options.type || 'email'; this.events = []; this.listeners = {}; }
    get value() { return this._value; }
    set value(v) { this._value = v; }
    getBoundingClientRect() { return {width: 100, height: 20}; }
    addEventListener(name, fn) { this.listeners[name] = fn; }
    dispatchEvent(event) { this.events.push(event.type); this.listeners[event.type]?.(event); }
  }
  const input = new Input();
  const signed = {getBoundingClientRect: () => ({width: 10, height: 10}), getAttribute: () => 'Google Account: other@example.test'};
  const location = {href: options.url || url};
  const window = {}; window.top = options.frame ? {} : window;
  const document = {readyState: 'complete', visibilityState: 'visible', activeElement: options.focused ? input : null,
    querySelector: () => input,
    querySelectorAll: selector => options.signed && selector === '[aria-label],[title]' ? [signed] : []};
  const context = {window, location, document, HTMLInputElement: Input,
    Event: class {constructor(type) { this.type = type; this.isTrusted = false; }},
    getComputedStyle: () => ({display:'block', visibility:'visible'})};
  const execute = () => vm.runInNewContext(script, context);
  return { input, execute };
}

test('actual identifier script inserts only email and emits input events without submitting', () => {
  for (const options of [{type:'text', focused:true}, {type:'email'}]) {
    const p = run(options);
    assert.equal(p.execute(), true);
    assert.equal(p.input.value, 'example@example.test');
    assert.deepEqual(p.input.events, ['input', 'change']);
  }
  assert.doesNotMatch(script, /\.click\(|\.submit\(/);
});

test('actual identifier script refuses existing, wrong-account, wrong-page and wrong-type inputs', () => {
  for (const options of [{value:'manual'}, {signed:true}, {frame:true},
    {url:'https://accounts.google.com/other'}, {type:'password'}]) {
    const p = run(options);
    assert.equal(p.execute(), false);
  }
  const p = run({value:'manual'});
  p.execute();
  p.input.listeners.input({isTrusted:true});
  p.input.value = '';
  assert.equal(p.execute(), false);
});

test('grid paste and serialization retain all export columns and reject overflow', () => {
  assert.match(editor, /maxOf\(50, addRows\.size\)/);
  assert.match(editor, /"Email", "Password", "2FA \/ Recovery", "Reserved"/);
  assert.match(editor, /\(1\.\.10\).*"Backup \$it"/);
  assert.match(editor, /"Created", "Ads", "YouTube", "App password"/);
  assert.match(editor, /row \+ data\.size > rowCount \|\| data\.any \{ col \+ it\.size > headers\.size \}/);
  assert.match(editor, /cells\[row \+ r\]\[col \+ c\]\?\.setText\(value\)/);
  assert.match(editor, /values\.joinToString\("\\t"\)/);
  assert.match(editor, /parseCredentialRow\(raw\) == null/);
  assert.match(editor, /columns\.slice\(4\.\.13\)/);
  assert.match(editor, /rows\.take\(addIndex\).*addRows\.take\(addIndex\)/);
  assert.match(editor, /putString\(KEY_ADD_ROWS.*putInt\(KEY_ADD_INDEX, nextIndex\)\.commit\(\)/);
  assert.match(source, /if \(fullExport\) appPassword = columns\.getOrNull\(17\)/);
});

test('injection is gated by ADD view, generation, document, URL and current tab', () => {
  for (const guard of ['addEnabled', 'addConfirmed', 'addView !== view', 'view !== currentWebView()',
    'credentialDocuments[view] !== document', 'document.committedUrl != pageUrl', 'addGeneration != generation',
    'credentialHost(uri) != "accounts.google.com"']) assert.ok(fill.includes(guard), guard);
  assert.match(source, /if \(addRun == addGeneration\) \{\s*fillAddIdentifier\(view, pageUrl\)/);
});
