const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');

test('drawer width is fixed independently of its labels while height remains scrollable', () => {
  assert.match(source, /drawerLayout\.addView\(sideMenuScroll, DrawerLayout\.LayoutParams\(dp\(216\), ViewGroup\.LayoutParams\.WRAP_CONTENT\)/);
  assert.match(source, /setPadding\(dp\(24\), 0, dp\(12\), 0\)/);
  assert.match(source, /addView\(sideMenu, ViewGroup\.LayoutParams\(ViewGroup\.LayoutParams\.MATCH_PARENT, ViewGroup\.LayoutParams\.WRAP_CONTENT\)\)/);
  assert.match(source, /sideMenuScroll\.maxHeightPx =/);
});
