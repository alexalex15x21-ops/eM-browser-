const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const start = source.indexOf('private fun injectAuthenticatorAutomation(');
const end = source.indexOf('private fun clickAuthenticatorSetupButton(', start);
const injection = source.slice(start, end);
const match = injection.match(/val successScript = """([\s\S]*?)"""\.trimIndent\(\)/);
assert.ok(match, 'success script found');

function probe(stage, markers = [], buttons = []) {
  const script = match[1].replace('${successCheckStage == "turn_on"}', String(stage === 'turn_on'));
  const document = {
    querySelectorAll(selector) {
      if (selector.includes('span[jsname="ZZJRD"]')) return markers.filter(m => m.matchesSelector);
      return buttons;
    }
  };
  return vm.runInNewContext(script, { document, window: { getComputedStyle: el => el.style } });
}

function marker(text = 'Added just now', options = {}) {
  return {
    matchesSelector: options.matchesSelector !== false,
    innerText: text,
    style: { display: options.display || 'block', visibility: options.visibility || 'visible' },
    getClientRects: () => options.noRects ? [] : [{}]
  };
}

test('visible inspected marker completes both post-code and waiting stages', () => {
  for (const stage of ['turn_on', 'waiting_success']) {
    assert.equal(probe(stage, [marker()]), 'success');
  }
});

test('hidden, unrelated and different text markers do not complete the stage', () => {
  for (const element of [marker('Added just now', { noRects: true }), marker('Added just now', { visibility: 'hidden' }), marker('Added just now', { display: 'none' }), marker('Added just now', { matchesSelector: false }), marker('Added yesterday')]) {
    assert.equal(probe('turn_on', [element]), 'wait');
    assert.equal(probe('waiting_success', [element]), 'wait');
  }
});

test('turn on stage does not click Skip and waiting stage can click it', () => {
  let clicked = 0;
  const skip = { offsetParent: {}, innerText: 'Skip', click: () => clicked++ };
  assert.equal(probe('turn_on', [], [skip]), 'wait');
  assert.equal(clicked, 0);
  assert.equal(probe('waiting_success', [], [skip]), 'skip');
  assert.equal(clicked, 1);
});

test('completion still checks run ownership and saves before marking the stage', () => {
  const finish = source.slice(source.indexOf('private fun finishAuthenticatorAutomation('), start);
  assert.match(injection, /authenticatorAutomationStage != successCheckStage/);
  assert.match(finish, /isAuthenticatorRun\(view, authenticatorAutomationRemovalToken\)/);
  assert.ok(finish.indexOf('saveAuthenticator(config, recordChange') < finish.indexOf('markStageCompleted("authenticator"'));
});
