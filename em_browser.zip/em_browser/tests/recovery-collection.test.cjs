const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

// Run with node --test tests/recovery-collection.test.cjs. The fixture executes
// the actual Kotlin-embedded scripts. The driver models only their native
// command ordering/callback guards; it is not an Android WebView integration.
const source = fs.readFileSync(process.env.RECOVERY_SOURCE ||
  path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const DESTINATION = 'https://myaccount.google.com/collection/recoveryemail';
const ACCOUNT = 'primary.account@example.com';
const TARGET = 'recovery.target@example.com';

function section(name) {
  const start = source.match(new RegExp(`^([ \\t]*)private fun ${name}\\s*\\(`, 'm'));
  assert.ok(start, `missing ${name}`);
  const from = start.index + start[0].length;
  const next = source.slice(from).search(new RegExp(`\n${start[1]}private fun \\w+\\s*\\(`));
  return source.slice(start.index, next < 0 ? undefined : from + next);
}
const pollSource = section('pollDevicesAutomation');
function scriptOf(name) {
  const match = pollSource.match(new RegExp(`\\bval\\s+${name}\\s*=\\s*"""([\\s\\S]*?)"""`));
  assert.ok(match, `missing ${name} in pollDevicesAutomation`);
  return match[1];
}
const probeScript = scriptOf('script');
const actionScript = scriptOf('actionScript');

function interpolate(script, fixture, command, snapshot, permit) {
  const values = {
    'JSONObject.quote(url)': JSON.stringify(snapshot.url),
    'JSONObject.quote(account)': JSON.stringify(fixture.account),
    'JSONObject.quote(recoveryTargetForRun)': JSON.stringify(fixture.target),
    'devicesAutomationDocumentOrigin ?: 0.0': String(snapshot.origin),
    'devicesAutomationPreviousDocumentOrigin ?: 0.0': String(fixture.previousOrigin),
    generation: String(snapshot.generation),
  };
  return script.replace(/\$\{([^{}]+)\}|\$([A-Za-z_]\w*)/g, (whole, expression, name) => {
    const key = (expression || name).trim();
    assert.ok(Object.hasOwn(values, key), `unmapped Kotlin interpolation: ${whole}`);
    return values[key];
  }).replaceAll('__EM_COMMAND__', JSON.stringify(command)).replaceAll('__EM_TOKEN__', JSON.stringify(permit));
}

// Small DOM fixture: selectors outside this subset throw instead of silently
// returning the wrong nodes. Save is inside the form; Done replaces the form.
class Element {
  constructor(tag, attrs = {}, text = '') {
    this.tagName = tag.toUpperCase();
    this.attrs = {...attrs};
    this.id = attrs.id || '';
    this.type = attrs.type || '';
    this.hidden = false;
    this.disabled = false;
    this.readOnly = false;
    this.style = {};
    this.parentElement = null;
    this.children = [];
    this.isConnected = true;
    this.listeners = {};
    this.clicks = 0;
    this._text = text;
  }
  get innerText() { return [this._text, ...this.children.filter(el => el.visible()).map(el => el.innerText)].filter(Boolean).join(' '); }
  set innerText(value) { this._text = value; }
  get textContent() { return [this._text, ...this.children.map(el => el.textContent)].filter(Boolean).join(' '); }
  set textContent(value) { this._text = value; }
  get offsetParent() { return this.visible() ? this.parentElement || this : null; }
  visible() {
    for (let el = this; el; el = el.parentElement) {
      if (el.hidden || el.style.display === 'none' || el.style.visibility === 'hidden' ||
          el.style.visibility === 'collapse' || Number(el.style.opacity ?? 1) === 0) return false;
    }
    return this.isConnected;
  }
  getBoundingClientRect() { return {width: this.visible() ? 100 : 0, height: this.visible() ? 24 : 0}; }
  getAttribute(name) {
    if (name === 'id' || name === 'type') return this[name] || null;
    if (name === 'disabled' || name === 'hidden') return this[name] ? '' : null;
    return Object.hasOwn(this.attrs, name) ? String(this.attrs[name]) : null;
  }
  setAttribute(name, value) {
    if (name === 'id' || name === 'type') this[name] = String(value);
    else if (name === 'disabled' || name === 'hidden') this[name] = true;
    else this.attrs[name] = String(value);
  }
  removeAttribute(name) {
    if (name === 'disabled' || name === 'hidden') this[name] = false;
    else if (name === 'id' || name === 'type') this[name] = '';
    else delete this.attrs[name];
  }
  matches(selector) {
    return selector.split(/,(?![^\[]*\])/).some(raw => {
      const part = raw.trim();
      const base = part.match(/^(\*|[a-zA-Z][\w-]*)?/)[0];
      if (base && base !== '*' && base.toUpperCase() !== this.tagName) return false;
      const suffix = part.slice(base.length);
      const pieces = suffix.match(/#[\w-]+|\.[\w-]+|\[[^\]]+\]|:disabled|:enabled/g) || [];
      if (pieces.join('') !== suffix) throw new Error(`Unsupported selector: ${part}`);
      return pieces.every(piece => {
        if (piece[0] === '#') return this.id === piece.slice(1);
        if (piece[0] === '.') return (this.getAttribute('class') || '').split(/\s+/).includes(piece.slice(1));
        if (piece === ':disabled') return this.disabled;
        if (piece === ':enabled') return !this.disabled;
        const attr = piece.match(/^\[([\w-]+)(?:\s*(=|\*=|\^=|\$=)\s*(?:"([^"]*)"|'([^']*)'|([^\]\s]+)))?\]$/);
        if (!attr) throw new Error(`Unsupported selector: ${part}`);
        const actual = this.getAttribute(attr[1]);
        if (!attr[2]) return actual !== null;
        const expected = attr[3] ?? attr[4] ?? attr[5];
        return actual !== null && (attr[2] === '=' ? actual === expected :
          attr[2] === '*=' ? actual.includes(expected) : attr[2] === '^=' ? actual.startsWith(expected) : actual.endsWith(expected));
      });
    });
  }
  closest(selector) { for (let el = this; el; el = el.parentElement) if (el.matches(selector)) return el; return null; }
  connected(value) { this.isConnected = value; for (const child of this.children) child.connected(value); }
  appendChild(child) { if (child.parentElement) child.remove(); child.parentElement = this; child.connected(this.isConnected); this.children.push(child); return child; }
  remove() {
    if (this.parentElement) this.parentElement.children = this.parentElement.children.filter(child => child !== this);
    this.parentElement = null;
    this.connected(false);
  }
  querySelectorAll(selector) {
    const nodes = [];
    const visit = el => { for (const child of el.children) { nodes.push(child); visit(child); } };
    visit(this);
    return nodes.filter(el => el.matches(selector));
  }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
  addEventListener(type, callback) { (this.listeners[type] ||= []).push(callback); }
  dispatchEvent(event) { for (const callback of this.listeners[event.type] || []) callback.call(this, event); return true; }
  click() { this.clicks++; this.dispatchEvent({type: 'click', isTrusted: false}); }
  focus() {}
}
class Input extends Element {
  constructor(attrs = {}, value = '') { super('input', attrs); this.value = value; }
  get value() { return this._value; }
  set value(value) { this._value = String(value); }
}

function page({url = DESTINATION, expectedUrl = url, account = ACCOUNT, target = TARGET, inputAttrs, initial = ''} = {}) {
  const body = new Element('body');
  const accountIndicator = body.appendChild(new Element('a', {'aria-label': `Google Account: Account User (${account})`}));
  const form = body.appendChild(new Element('form'));
  const input = form.appendChild(new Input(inputAttrs || {id: 'i2', 'aria-label': 'Your recovery email', type: 'email'}, initial));
  const save = form.appendChild(new Element('button', {type: 'submit'}, 'Save'));
  const location = new URL(url);
  const document = {
    body, documentElement: body, readyState: 'complete', visibilityState: 'visible',
    querySelectorAll: selector => body.querySelectorAll(selector),
    querySelector: selector => body.querySelector(selector),
  };
  const permitState = {current: '', sequence: 0};
  const window = {document, location, HTMLInputElement: Input, HTMLElement: Element,
    performance: {timeOrigin: 1000},
    EMRecoveryGuard: {permitted: token => typeof token === 'string' && token.length > 0 && permitState.current === token},
    Event: class { constructor(type, options = {}) { this.type = type; Object.assign(this, options); this.isTrusted = false; } },
    getComputedStyle: el => ({display: 'block', visibility: 'visible', opacity: '1', ...el.style}),
  };
  window.window = window;
  window.top = window;
  const context = vm.createContext(window);
  const p = {
    body, accountIndicator, form, input, save, document, window, location, account, target, permitState, importedTarget: target,
    url: expectedUrl, generation: 7, documentGeneration: 1, previousOrigin: 0, origin: 1000,
    active: true, enabled: true, paused: false, saveIssued: false, doneIssued: false,
    pending: false, failed: false, calls: [], done: null,
    snapshot() { return {url: this.url, generation: this.generation, documentGeneration: this.documentGeneration, origin: this.origin}; },
    current(s) {
      return this.active && this.enabled && !this.paused && !this.failed && this.generation === s.generation &&
        this.documentGeneration === s.documentGeneration && this.url === s.url && this.location.href === s.url;
    },
    issuePermit() { return permitState.current = `fixture-permit-${++permitState.sequence}`; },
    revokePermit() { permitState.current = ''; },
    evaluate(script, command, snapshot = this.snapshot(), permit = '') {
      return vm.runInContext(interpolate(script, this, command, snapshot, permit), context, {timeout: 1000});
    },
    runAction(command, snapshot, permit) { return this.evaluate(actionScript, command, snapshot, permit); },
    action(command, snapshot = this.snapshot()) {
      const permit = this.issuePermit();
      try { return this.runAction(command, snapshot, permit); }
      finally { if (permitState.current === permit) this.revokePermit(); }
    },
    type(value) { this.input.value = value; this.input.dispatchEvent({type: 'input', isTrusted: true}); },
    showDone() { this.form.remove(); this.done = this.body.appendChild(new Element('button', {}, 'Done')); return this.done; },
    navigate(url, origin = this.window.performance.timeOrigin) {
      this.revokePermit();
      this.location.href = url;
      this.window.performance.timeOrigin = origin;
      this.documentGeneration++;
      this.pending = false;
    },
    // Mirrors the probe and the actual prepare/save/check_done/done transitions.
    // Hooks represent page changes between JS evaluation and native callbacks.
    poll({beforeCommand, afterCommand} = {}) {
      const token = this.snapshot();
      if (!this.current(token) || this.pending || this.doneIssued) return 'inactive';
      const probe = this.evaluate(probeScript, '', token);
      if (probe === 'failed') { this.failed = true; return probe; }
      if (!probe.startsWith('ready:')) return probe;
      this.origin = Number(probe.slice('ready:'.length));
      token.origin = this.origin;
      if (!this.target || this.importedTarget !== this.target) { this.failed = true; return 'target_changed'; }
      const execute = command => {
        this.pending = true;
        const permit = this.issuePermit();
        beforeCommand?.(command, this);
        const result = this.runAction(command, token, permit);
        this.calls.push({command, result});
        afterCommand?.(command, this, result);
        if (permitState.current === permit) this.revokePermit();
        if (!this.current(token)) return 'stale';
        this.pending = false;
        if (this.importedTarget !== this.target) return 'stale';
        return result;
      };
      const result = execute(this.saveIssued ? 'check_done' : 'prepare');
      if (result === 'ready_save') {
        this.saveIssued = true;
        const clicked = execute('save');
        if (clicked !== 'stale' && clicked !== 'save_clicked') this.saveIssued = false;
        return clicked;
      }
      if (result === 'ready_done') {
        this.doneIssued = true;
        const clicked = execute('done');
        if (clicked !== 'stale' && clicked !== 'done_clicked') this.doneIssued = false;
        return clicked;
      }
      return result;
    },
  };
  return p;
}

test('production scripts and configured collection destination are extracted', () => {
  assert.match(actionScript, /__EM_COMMAND__/);
  assert.match(actionScript, /__EM_TOKEN__/);
  assert.match(probeScript, /performance\.timeOrigin/);
  const destination = source.match(/private const val DEVICES_URL = "([^"]+)"/);
  assert.ok(destination);
  assert.equal(destination[1], 'https://myaccount.google.com/collection/recoveryemail?oev=lytf%3D7%26wvtx%3D6%26trs%3Dsae&utm_source=security-advisor&utm_medium=App&utm_campaign=sae&continue=https%3A%2F%2Fmyaccount.google.com%2Fsecurity-checkup%2F1%3Fcontinue%3Dhttps%253A%252F%252Fmyaccount.google.com%252F%253Futm_source%253Dsign_in_no_continue%26continue%3Dhttps%253A%252F%252Faccounts.google.com%252FServiceLogin%253Fcontinue%253Dhttps%253A%252F%252Fmyaccount.google.com%252F%253Futm_source%25253Dsign_in_no_continue%2526hl%253Den%2526authuser%253D0%2526passive%253Dtrue%2526sarp%253D1%2526aodrpl%253D1%2526checkedDomains%253Dyoutube%2526checkConnection%253Dyoutube%253A118%2526pstMsg%253D1%26flowType%3D1%26hl%3Den%26hl%3Den%26rapt%3DAEjHL4PqZfupej-C9TBiwCYOUAmFRSkWzQdFUycXJL-syfdv63U-6OPvsNEDQ4CKF542DApKTMhhrdo9GRJ1mOvQf_stMUSsYg%26rapt%3DAEjHL4PqZfupej-C9TBiwCYOUAmFRSkWzQdFUycXJL-syfdv63U-6OPvsNEDQ4CKF542DApKTMhhrdo9GRJ1mOvQf_stMUSsYg%26pli%3D1%26arec%3D1&hl=en&roc=true&opendialog=collectemail&rapt=AEjHL4PqZfupej-C9TBiwCYOUAmFRSkWzQdFUycXJL-syfdv63U-6OPvsNEDQ4CKF542DApKTMhhrdo9GRJ1mOvQf_stMUSsYg');
  const url = new URL(destination[1]);
  assert.equal(url.origin, 'https://myaccount.google.com');
  assert.equal(url.pathname, '/collection/recoveryemail');
  assert.match(section('pollDevicesInitialNavigation'), /view\.loadUrl\(DEVICES_URL\)/);
});

test('native guard issues and revokes per-command tokens on cancellation and lifecycle changes', () => {
  assert.match(source, /@Volatile private var recoveryActionPermit = ""/);
  assert.match(source, /fun permitted\(token: String\): Boolean = token\.isNotBlank\(\) && recoveryActionPermit == token/);
  assert.match(source, /addJavascriptInterface\(recoveryActionGuard, "EMRecoveryGuard"\)/);
  assert.match(pollSource, /val permit = java\.util\.UUID\.randomUUID\(\)\.toString\(\)[\s\S]*?recoveryActionPermit = permit/);
  assert.match(pollSource, /replace\("__EM_TOKEN__", JSONObject\.quote\(permit\)\)/);
  assert.match(pollSource, /if \(recoveryActionPermit == permit\) recoveryActionPermit = ""/);
  assert.match(section('cancelSecurityAutomationForView'), /if \(cancelDevices\) stopDevicesAutomation\(\)/);
  assert.match(section('stopDevicesAutomation'), /recoveryActionPermit = ""/);
  assert.match(section('saveRecoveryTarget'), /if \(devicesAutomationActive && devicesAutomationAccount == key\) recoveryActionPermit = ""/);
  assert.match(section('showActiveWebView'), /devicesAutomationView !== webView\) \{\s*recoveryActionPermit = ""/);
  assert.match(section('noteDevicesVerification'), /recoveryActionPermit = ""/);
  for (const [start, end] of [
    ['override fun onPageStarted(', 'override fun onPageCommitVisible('],
    ['override fun doUpdateVisitedHistory(', 'override fun shouldOverrideUrlLoading('],
    ['override fun onPause()', 'override fun onStart()'],
    ['override fun onStop()', 'override fun onDestroy()'],
  ]) {
    const a = source.indexOf(start);
    const b = source.indexOf(end, a + start.length);
    assert.ok(a >= 0 && b > a, `missing ${start}`);
    assert.match(source.slice(a, b), /recoveryActionPermit = ""/, start);
  }
});

test('completion rechecks the currently strongly identified account', () => {
  const finish = section('finishRecoverySet');
  const strict = finish.search(/detectGoogleAccountKey\(view,\s*(?:true|strictIdentity\s*=\s*true)\)/);
  assert.ok(strict >= 0,
    'finishRecoverySet must re-identify the current account with strict identity before completion');
  const completion = finish.indexOf('markStageCompleted(');
  assert.ok(completion > strict,
    'strict identity recheck must precede marking completion');
  assert.match(finish.slice(strict, completion), /(?:\.equals\(account,\s*true\)|account\.equals\([^\n]*,\s*true\))/,
    'the freshly identified account must be compared to the run account');
});

test('revoked or missing permits block initial fill, queued Save, and queued Done', () => {
  for (const command of ['prepare', 'save', 'done']) {
    for (const mode of ['revoked', 'missing_bridge', 'missing_method', 'throws']) {
      const p = page();
      if (command !== 'prepare') assert.equal(p.poll(), 'filled');
      if (command === 'done') {
        assert.equal(p.poll(), 'save_clicked');
        p.showDone();
      }
      const original = p.window.EMRecoveryGuard;
      assert.equal(p.poll({beforeCommand: next => {
        if (next !== command) return;
        if (mode === 'revoked') p.revokePermit();
        if (mode === 'missing_bridge') delete p.window.EMRecoveryGuard;
        if (mode === 'missing_method') p.window.EMRecoveryGuard = {};
        if (mode === 'throws') p.window.EMRecoveryGuard = {permitted() { throw new Error('bridge unavailable'); }};
      }}), 'waiting', `${command}: ${mode}`);
      assert.equal(p.input.value, command === 'prepare' ? '' : TARGET, `${command}: ${mode}`);
      assert.equal(command === 'done' ? p.done.clicks : p.save.clicks, 0, `${command}: ${mode}`);
      p.window.EMRecoveryGuard = original;
      assert.equal(p.poll(), command === 'prepare' ? 'filled' : command === 'save' ? 'save_clicked' : 'done_clicked', `${command}: ${mode}`);
    }
  }
});

test('revocation at the final guard check blocks each mutation', () => {
  for (const command of ['prepare', 'save', 'done']) {
    const p = page();
    if (command !== 'prepare') assert.equal(p.poll(), 'filled');
    if (command === 'done') {
      assert.equal(p.poll(), 'save_clicked');
      p.showDone();
    }
    const permitted = p.window.EMRecoveryGuard.permitted;
    let checks = 0;
    assert.equal(p.poll({beforeCommand: next => {
      if (next !== command) return;
      p.window.EMRecoveryGuard.permitted = token => {
        if (++checks === 2) p.revokePermit();
        return permitted(token);
      };
    }}), 'waiting', command);
    assert.equal(checks, 2, command);
    assert.equal(p.input.value, command === 'prepare' ? '' : TARGET, command);
    assert.equal(command === 'done' ? p.done.clicks : p.save.clicks, 0, command);
  }
});

test('an old or blank token cannot use a newer command permit', () => {
  const p = page();
  const old = p.issuePermit();
  const fresh = p.issuePermit();
  assert.equal(p.runAction('prepare', p.snapshot(), old), 'waiting');
  assert.equal(p.runAction('prepare', p.snapshot(), ''), 'waiting');
  assert.equal(p.input.value, '');
  assert.equal(p.runAction('prepare', p.snapshot(), fresh), 'filled');
  assert.equal(p.input.value, TARGET);
  p.revokePermit();
});

test('prepare fills the actual form, Save occurs once, then Done occurs once', () => {
  const p = page();
  assert.equal(p.input.closest('form'), p.form);
  assert.equal(p.save.type, 'submit');
  assert.equal(p.poll(), 'filled');
  assert.equal(p.input.value, TARGET);
  assert.equal(p.save.clicks, 0);
  assert.equal(p.poll(), 'save_clicked');
  assert.equal(p.save.clicks, 1);
  assert.equal(p.action('save'), 'waiting');
  assert.equal(p.save.clicks, 1);
  for (let i = 0; i < 3; i++) assert.equal(p.poll(), 'waiting');
  assert.equal(p.save.clicks, 1);
  const done = p.showDone();
  assert.equal(p.poll(), 'done_clicked');
  assert.equal(done.clicks, 1);
  assert.equal(p.poll(), 'inactive');
  assert.equal(p.action('done'), 'waiting');
  assert.equal(done.clicks, 1);
  assert.deepEqual(p.calls.map(({command}) => command),
    ['prepare', 'prepare', 'save', 'check_done', 'check_done', 'check_done', 'check_done', 'done']);
});

test('native handoff requires Done and the same account target', () => {
  assert.match(pollSource, /execute\(if \(recoverySaveIssued\) "check_done" else "prepare"\)/);
  assert.match(pollSource, /"ready_save"\s*->\s*\{\s*recoverySaveIssued = true\s*execute\("save"\)/);
  assert.match(pollSource, /"ready_done"\s*->\s*\{\s*recoveryDoneIssued = true\s*execute\("done"\)/);
  assert.match(pollSource, /if \(clicked == "done_clicked"\) finishRecoverySet\(view\)/);
  const finish = section('finishRecoverySet');
  assert.match(finish, /!recoveryDoneAcknowledged/);
  assert.match(pollSource, /command == "done" && value == "done_clicked"[\s\S]*?recoveryDoneAcknowledged = true/);
  assert.match(finish, /recoveryTargetForAccount\(account\) != recoveryTargetForRun/);
  assert.match(finish, /updateSavedAccountRecovery\(recoveryTargetForRun, account\)/);
  assert.match(finish, /markStageCompleted\("recovery_set", view, account\)/);
  assert.match(finish, /startNextConfiguredStage\(view, "recovery_set"/);
  assert.match(section('pollDevicesInitialNavigation'), /recoveryTargetForRun = if \(android\.util\.Patterns\.EMAIL_ADDRESS\.matcher\(target\)\.matches\(\) && !target\.equals\(account, true\)\) target else ""/);
  assert.match(pollSource, /if \(recoveryTargetForRun\.isBlank\(\)\)[\s\S]*?Recovery is waiting for an email in Password settings[\s\S]*?retry\(\)/);
});

test('does not click Done before Save, including when the form disappears early', () => {
  const p = page();
  const done = p.showDone();
  assert.equal(p.poll(), 'waiting');
  assert.equal(done.clicks, 0);
  assert.equal(p.save.clicks, 0);
  assert.equal(p.doneIssued, false);
});

test('disabled or hidden controls are not clicked; enabled controls are clicked once', () => {
  for (const condition of ['disabled', 'hidden', 'aria-disabled', 'hidden-parent']) {
    const p = page();
    assert.equal(p.poll(), 'filled');
    const set = (el, blocked) => {
      if (condition === 'aria-disabled') blocked ? el.setAttribute('aria-disabled', 'true') : el.removeAttribute('aria-disabled');
      else if (condition === 'hidden-parent') el.parentElement.hidden = blocked;
      else el[condition] = blocked;
    };
    set(p.save, true);
    assert.equal(p.poll(), 'waiting', `Save: ${condition}`);
    assert.equal(p.save.clicks, 0);
    set(p.save, false);
    assert.equal(p.poll(), 'save_clicked');
    const done = p.showDone();
    const wrapper = p.body.appendChild(new Element('div'));
    wrapper.appendChild(done);
    set(done, true);
    assert.equal(p.poll(), 'waiting', `Done: ${condition}`);
    assert.equal(done.clicks, 0);
    set(done, false);
    assert.equal(p.poll(), 'done_clicked');
    assert.equal(done.clicks, 1);
  }
});

test('duplicate visible Save or Done buttons are rejected; hidden duplicates are ignored', () => {
  const p = page();
  const otherSave = p.form.appendChild(new Element('button', {type: 'submit'}, 'Save'));
  assert.equal(p.poll(), 'filled');
  assert.equal(p.poll(), 'waiting');
  assert.equal(p.save.clicks + otherSave.clicks, 0);
  otherSave.hidden = true;
  assert.equal(p.poll(), 'save_clicked');
  const done = p.showDone();
  const otherDone = p.body.appendChild(new Element('button', {}, 'Done'));
  assert.equal(p.poll(), 'waiting');
  assert.equal(done.clicks + otherDone.clicks, 0);
  otherDone.hidden = true;
  assert.equal(p.poll(), 'done_clicked');
  assert.equal(done.clicks, 1);
});

test('missing, duplicate, wrong, disabled, hidden or read-only inputs are never filled', () => {
  for (const setup of [
    p => p.input.remove(),
    p => p.form.appendChild(new Input({id: 'i2', 'aria-label': 'Your recovery email', type: 'email'})),
    p => { p.input.id = 'other'; },
    p => p.input.setAttribute('aria-label', 'Contact email'),
    p => { p.input.type = 'text'; },
    p => { p.input.disabled = true; },
    p => { p.input.hidden = true; },
    p => { p.input.readOnly = true; },
  ]) {
    const p = page();
    setup(p);
    assert.equal(p.poll(), 'waiting');
    assert.equal(p.input.value, '');
    assert.equal(p.save.clicks, 0);
  }
});

test('an exactly matching prefilled target can be saved once without rewriting it', () => {
  const p = page({initial: TARGET});
  let inputEvents = 0;
  p.input.addEventListener('input', () => inputEvents++);
  assert.equal(p.poll(), 'save_clicked');
  assert.equal(p.input.value, TARGET);
  assert.equal(inputEvents, 0);
  assert.equal(p.save.clicks, 1);
  assert.equal(p.poll(), 'waiting');
  assert.equal(p.save.clicks, 1);
  const done = p.showDone();
  assert.equal(p.poll(), 'done_clicked');
  assert.equal(done.clicks, 1);
});

test('differing prefilled values and manual edits are preserved and never submitted', () => {
  for (const initial of ['manual@example.com', TARGET.toUpperCase()]) {
    const p = page({initial});
    assert.equal(p.poll(), 'manual');
    assert.equal(p.input.value, initial);
    assert.equal(p.save.clicks, 0);
    p.type('');
    assert.equal(p.poll(), 'manual');
    assert.equal(p.input.value, '');
    assert.equal(p.save.clicks, 0);
  }
  for (const value of ['manual@example.com', '', TARGET]) {
    const p = page();
    assert.equal(p.poll(), 'filled');
    assert.equal(p.poll({beforeCommand: command => { if (command === 'save') p.type(value); }}), 'manual');
    assert.equal(p.input.value, value);
    assert.equal(p.save.clicks, 0);
    assert.equal(p.poll(), 'manual');
  }
});

test('a field value changed without an input event is rechecked before Save', () => {
  const p = page();
  assert.equal(p.poll(), 'filled');
  assert.equal(p.poll({beforeCommand: command => {
    if (command === 'save') p.input.value = 'different@example.com';
  }}), 'manual');
  assert.equal(p.input.value, 'different@example.com');
  assert.equal(p.save.clicks, 0);
});

test('a conflicting visible recovery address blocks Done; the target permits it', () => {
  const p = page();
  assert.equal(p.poll(), 'filled');
  assert.equal(p.poll(), 'save_clicked');
  const done = p.showDone();
  p.body.appendChild(new Element('div', {}, `Account: ${ACCOUNT}`));
  const recovery = p.body.appendChild(new Element('div', {}, 'Recovery email: different@example.com'));
  assert.equal(p.poll(), 'unexpected_target');
  assert.equal(p.poll(), 'unexpected_target');
  assert.equal(done.clicks, 0);
  assert.equal(p.doneIssued, false);
  recovery.innerText = `Recovery email: ${TARGET.toUpperCase()}`;
  assert.equal(p.poll(), 'done_clicked');
  assert.equal(done.clicks, 1);
});

test('a conflicting address appearing between check_done and Done prevents the click', () => {
  const p = page();
  assert.equal(p.poll(), 'filled');
  assert.equal(p.poll(), 'save_clicked');
  const done = p.showDone();
  const recovery = p.body.appendChild(new Element('div', {}, `Recovery email: ${TARGET}`));
  assert.equal(p.poll({beforeCommand: command => {
    if (command === 'done') recovery.innerText = 'Recovery email: different@example.com';
  }}), 'unexpected_target');
  assert.equal(done.clicks, 0);
  assert.equal(p.doneIssued, false);
  recovery.innerText = `Recovery email: ${TARGET}`;
  assert.equal(p.poll(), 'done_clicked');
  assert.equal(done.clicks, 1);
});

test('the primary account and hidden addresses do not count as visible conflicts', () => {
  const p = page();
  assert.equal(p.poll(), 'filled');
  assert.equal(p.poll(), 'save_clicked');
  const done = p.showDone();
  p.body.appendChild(new Element('div', {}, `Account: ${ACCOUNT.toUpperCase()}`));
  const hidden = p.body.appendChild(new Element('div', {}, 'Recovery email: different@example.com'));
  hidden.hidden = true;
  assert.equal(p.poll(), 'done_clicked');
  assert.equal(done.clicks, 1);
});

test('only visible recovery-specific text, aria-labels, or data attributes identify conflicting targets', () => {
  for (const evidence of [
    () => new Element('p', {}, 'Recovery email: different@example.com'),
    () => new Element('span', {}, 'Recovery email: different@example.com'),
    () => new Element('div', {}, 'Recovery email: different@example.com'),
    () => new Element('div', {'aria-label': 'Recovery email: different@example.com'}),
    () => new Element('div', {'data-recovery-email': 'different@example.com'}),
  ]) {
    const p = page();
    assert.equal(p.poll(), 'filled');
    assert.equal(p.poll(), 'save_clicked');
    const done = p.showDone();
    const node = p.body.appendChild(evidence());
    assert.equal(p.poll(), 'unexpected_target');
    assert.equal(done.clicks, 0);
    node.remove();
    p.body.appendChild(new Element('div', {'data-recovery-email': TARGET}));
    assert.equal(p.poll(), 'done_clicked');
    assert.equal(done.clicks, 1);
  }
});

test('unrelated visible email addresses do not block Done', () => {
  const p = page();
  assert.equal(p.poll(), 'filled');
  assert.equal(p.poll(), 'save_clicked');
  const done = p.showDone();
  p.body.appendChild(new Element('p', {}, 'Contact support@example.com for assistance'));
  p.body.appendChild(new Element('span', {'aria-label': 'Contact: other@example.com'}));
  p.body.appendChild(new Element('div', {'data-email': 'different@example.com'}, 'Other contact'));
  assert.equal(p.poll(), 'done_clicked');
  assert.equal(done.clicks, 1);
});

test('visible Google Account aria-label, title, and profileIdentifier establish the account', () => {
  for (const indicator of [
    () => new Element('a', {'aria-label': `Google Account: User (${ACCOUNT.toUpperCase()})`}),
    () => new Element('a', {title: `Google Account: User (${ACCOUNT})`}),
    () => new Element('div', {id: 'profileIdentifier'}, ACCOUNT),
  ]) {
    const p = page();
    p.accountIndicator.remove();
    p.body.appendChild(indicator());
    assert.equal(p.poll(), 'filled');
    assert.equal(p.input.value, TARGET);
  }
});

test('missing, hidden, unrelated, or ambiguous account indicators cannot fill or click', () => {
  for (const setup of [
    p => p.accountIndicator.remove(),
    p => { p.accountIndicator.hidden = true; },
    p => p.accountIndicator.setAttribute('aria-label', `Profile: ${ACCOUNT}`),
    p => p.body.appendChild(new Element('a', {title: 'Google Account: other@example.com'})),
  ]) {
    const p = page();
    setup(p);
    for (const command of ['prepare', 'save', 'check_done', 'done']) {
      assert.equal(p.action(command), 'account_unverified', command);
    }
    assert.equal(p.input.value, '');
    assert.equal(p.save.clicks, 0);
    assert.equal(p.poll(), 'account_unverified');
  }
});

test('a verified Save permits Done after account indicator loss on the same document', () => {
  const p = page();
  assert.equal(p.poll(), 'filled');
  assert.equal(p.poll(), 'save_clicked');
  p.accountIndicator.remove();
  const done = p.showDone();
  assert.equal(p.action('check_done'), 'ready_done');
  assert.equal(p.poll(), 'done_clicked');
  assert.equal(done.clicks, 1);
  assert.equal(p.poll(), 'inactive');

  // A fresh document has no page-local evidence of the earlier Save.
  const reloaded = page();
  reloaded.accountIndicator.remove();
  reloaded.saveIssued = true;
  const reloadedDone = reloaded.showDone();
  assert.equal(reloaded.poll(), 'account_unverified');
  assert.equal(reloadedDone.clicks, 0);
});

test('account indicator loss between check_done and Done is allowed only after a verified Save', () => {
  const p = page();
  assert.equal(p.poll(), 'filled');
  assert.equal(p.poll(), 'save_clicked');
  const done = p.showDone();
  assert.equal(p.poll({beforeCommand: command => {
    if (command === 'done') p.accountIndicator.remove();
  }}), 'done_clicked');
  assert.equal(done.clicks, 1);
});

test('losing the account indicator before Save blocks it, even after a verified fill', () => {
  const prefilled = page({initial: TARGET});
  prefilled.accountIndicator.remove();
  assert.equal(prefilled.poll(), 'account_unverified');
  assert.equal(prefilled.input.value, TARGET);
  assert.equal(prefilled.save.clicks, 0);
  for (const when of ['before_poll', 'before_save']) {
    const p = page();
    assert.equal(p.poll(), 'filled');
    if (when === 'before_poll') p.accountIndicator.remove();
    assert.equal(p.poll({beforeCommand: command => {
      if (when === 'before_save' && command === 'save') p.accountIndicator.remove();
    }}), 'account_unverified', when);
    assert.equal(p.save.clicks, 0, when);
    assert.equal(p.saveIssued, false, when);
    p.body.appendChild(p.accountIndicator);
    assert.equal(p.poll(), 'save_clicked', when);
    assert.equal(p.save.clicks, 1, when);
  }
});

test('a mismatched or ambiguous account after Save blocks Done', () => {
  const p = page();
  assert.equal(p.poll(), 'filled');
  assert.equal(p.poll(), 'save_clicked');
  const done = p.showDone();
  p.accountIndicator.setAttribute('aria-label', 'Google Account: Other User (other@example.com)');
  assert.equal(p.poll(), 'account_mismatch');
  assert.equal(done.clicks, 0);
  p.body.appendChild(new Element('a', {title: `Google Account: User (${ACCOUNT})`}));
  assert.equal(p.poll(), 'account_unverified');
  assert.equal(done.clicks, 0);
});

test('account ambiguity appearing between check_done and Done prevents the click', () => {
  const p = page();
  assert.equal(p.poll(), 'filled');
  assert.equal(p.poll(), 'save_clicked');
  const done = p.showDone();
  assert.equal(p.poll({beforeCommand: command => {
    if (command === 'done') p.body.appendChild(new Element('a', {title: 'Google Account: other@example.com'}));
  }}), 'account_unverified');
  assert.equal(done.clicks, 0);
  assert.equal(p.doneIssued, false);
});

test('a visible different account blocks all actions', () => {
  const p = page();
  p.accountIndicator.setAttribute('aria-label', 'Google Account: Other User (other@example.com)');
  for (const command of ['prepare', 'save', 'check_done', 'done']) {
    assert.equal(p.action(command), 'account_mismatch', command);
  }
  assert.equal(p.poll(), 'account_mismatch');
  assert.equal(p.input.value, '');
  assert.equal(p.save.clicks, 0);
  assert.match(pollSource, /"account_mismatch"\s*->\s*\{\s*cancelSecurityAutomationForView\(view\)/);
});

test('an account change between prepare and Save or check_done and Done prevents the click', () => {
  for (const command of ['save', 'done']) {
    const p = page();
    assert.equal(p.poll(), 'filled');
    if (command === 'done') {
      assert.equal(p.poll(), 'save_clicked');
      p.showDone();
    }
    assert.equal(p.poll({beforeCommand: next => {
      if (next === command) p.accountIndicator.setAttribute('aria-label', 'Google Account: Other User (other@example.com)');
    }}), 'account_mismatch', command);
    assert.equal(command === 'save' ? p.save.clicks : p.done.clicks, 0, command);
    assert.equal(command === 'save' ? p.saveIssued : p.doneIssued, false, command);
    p.accountIndicator.setAttribute('aria-label', `Google Account: Account User (${ACCOUNT})`);
    assert.equal(p.poll(), command === 'save' ? 'save_clicked' : 'done_clicked', command);
  }
});

test('verification appearing before Save or Done prevents the click', () => {
  for (const command of ['save', 'done']) {
    for (const overlay of [
      () => new Element('div', {}, 'Verify your identity'),
      () => new Element('input', {type: 'password'}),
      () => new Element('iframe', {src: 'https://www.google.com/recaptcha/api'}),
    ]) {
      const p = page();
      assert.equal(p.poll(), 'filled');
      if (command === 'done') {
        assert.equal(p.poll(), 'save_clicked');
        p.showDone();
      }
      let challenge;
      assert.equal(p.poll({beforeCommand: next => {
        if (next === command) challenge = p.body.appendChild(overlay());
      }}), 'verification', command);
      assert.equal(command === 'save' ? p.save.clicks : p.done.clicks, 0, command);
      assert.equal(command === 'save' ? p.saveIssued : p.doneIssued, false, command);
      challenge.remove();
      assert.equal(p.poll(), command === 'save' ? 'save_clicked' : 'done_clicked', command);
    }
  }
});

test('background document visibility blocks each command and click until visible again', () => {
  const p = page();
  p.document.visibilityState = 'hidden';
  for (const command of ['prepare', 'save', 'check_done', 'done']) assert.equal(p.action(command), 'waiting', command);
  assert.equal(p.poll(), 'waiting');
  assert.equal(p.input.value, '');
  p.document.visibilityState = 'visible';
  assert.equal(p.poll(), 'filled');
  assert.equal(p.poll({beforeCommand: command => {
    if (command === 'save') p.document.visibilityState = 'hidden';
  }}), 'waiting');
  assert.equal(p.save.clicks, 0);
  p.document.visibilityState = 'visible';
  assert.equal(p.poll(), 'save_clicked');
  const done = p.showDone();
  assert.equal(p.poll({beforeCommand: command => {
    if (command === 'done') p.document.visibilityState = 'hidden';
  }}), 'waiting');
  assert.equal(done.clicks, 0);
  p.document.visibilityState = 'visible';
  assert.equal(p.poll(), 'done_clicked');
  assert.equal(done.clicks, 1);
});

test('invalid or changed account targets never submit', () => {
  for (const target of ['', 'not-an-email', 'missing-domain@', 'a@example.com\nother@example.com']) {
    const p = page({target});
    assert.notEqual(p.poll(), 'save_clicked', JSON.stringify(target));
    assert.equal(p.input.value, '');
    assert.equal(p.save.clicks, 0);
  }
  const p = page();
  assert.equal(p.poll(), 'filled');
  p.importedTarget = 'changed@example.com';
  assert.equal(p.poll(), 'target_changed');
  assert.equal(p.save.clicks, 0);
});

test('action script rejects wrong origins, paths, subframes, document states and origins', () => {
  for (const url of [
    'http://myaccount.google.com/collection/recoveryemail',
    'https://myaccount.google.com:8443/collection/recoveryemail',
    'https://myaccount.google.com.evil.test/collection/recoveryemail',
    'https://accounts.google.com/collection/recoveryemail',
    'https://myaccount.google.com/collection/other',
  ]) {
    const p = page({url});
    assert.equal(p.action('prepare'), 'waiting', url);
    assert.equal(p.input.value, '', url);
    assert.equal(p.save.clicks, 0, url);
  }
  for (const setup of [
    p => { p.window.top = {}; },
    p => { p.document.readyState = 'loading'; },
    p => { p.window.performance.timeOrigin = 1001; },
    p => { p.location.href += '?changed=1'; },
  ]) {
    const p = page();
    setup(p);
    assert.equal(p.action('prepare'), 'waiting');
    assert.equal(p.input.value, '');
    assert.equal(p.save.clicks, 0);
  }
});

test('navigation or reload between prepare and Save cannot click the stale form', () => {
  for (const change of [
    p => p.navigate('https://myaccount.google.com/security'),
    p => p.navigate(DESTINATION + '?other=1'),
    p => p.navigate(DESTINATION, 2000),
  ]) {
    const p = page();
    assert.equal(p.poll(), 'filled');
    assert.equal(p.poll({beforeCommand: command => { if (command === 'save') change(p); }}), 'stale');
    assert.equal(p.calls.at(-1).result, 'waiting');
    assert.equal(p.save.clicks, 0);
    assert.equal(p.doneIssued, false);
  }
});

test('navigation between check_done and Done cannot click or hand off', () => {
  const p = page();
  p.poll();
  assert.equal(p.poll(), 'save_clicked');
  const done = p.showDone();
  assert.equal(p.poll({beforeCommand: command => { if (command === 'done') p.navigate(DESTINATION + '#other'); }}), 'stale');
  assert.equal(p.calls.at(-1).result, 'waiting');
  assert.equal(done.clicks, 0);
});

test('a callback arriving after navigation cannot deliver a stale Save result', () => {
  const p = page();
  p.poll();
  assert.equal(p.poll({afterCommand: command => { if (command === 'save') p.navigate('https://myaccount.google.com/security'); }}), 'stale');
  assert.equal(p.save.clicks, 1);
  assert.equal(p.poll(), 'inactive');
  assert.equal(p.doneIssued, false);
  assert.match(pollSource, /view\.evaluateJavascript\(executable\)[\s\S]*?if \(!current\(\)\) return@evaluateJavascript/);
  assert.match(pollSource, /documentGeneration == devicesAutomationDocumentGeneration/);
});

test('load errors and verification challenges block all recovery actions', () => {
  for (const [text, expected] of [
    ["This site can't be reached", 'failed'], ['Something went wrong', 'failed'],
    ['Verify your identity', 'verification'], ['Checking your browser', 'verification'],
  ]) {
    const p = page();
    p.body.innerText = text;
    assert.equal(p.poll(), expected, text);
    assert.equal(p.input.value, '');
    assert.equal(p.save.clicks, 0);
    assert.equal(p.calls.length, 0);
  }
  const afterSave = page();
  afterSave.poll();
  assert.equal(afterSave.poll(), 'save_clicked');
  const done = afterSave.showDone();
  afterSave.body.innerText = 'Something went wrong';
  assert.equal(afterSave.poll(), 'failed');
  assert.equal(done.clicks, 0);
});
