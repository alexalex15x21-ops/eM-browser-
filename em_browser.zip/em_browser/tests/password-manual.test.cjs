const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const section = source.split('private fun injectPasswordChangeScript(')[1].split('\n    private fun ')[0];
const script = section.match(/val script = """([\s\S]*?)"""\.trimIndent\(\)/)[1];

class Input {
  constructor(value = '') { this.value = value; this.offsetParent = {}; this.listeners = {}; }
  closest(selector) { return selector === 'form' ? this.form : null; }
  addEventListener(type, fn) { (this.listeners[type] ||= []).push(fn); }
  dispatchEvent(event) { for (const fn of this.listeners[event.type] || []) fn(event); }
  type(value) { this.value = value; this.dispatchEvent({type: 'input', isTrusted: true}); }
}
function page(count, current = 'old', next = 'new', initial = [], shared = new Map()) {
  const inputs = Array.from({length: count}, (_, i) => new Input(initial[i] || ''));
  const form = {};
  for (const input of inputs) input.form = form;
  const button = {offsetParent: {}, innerText: count === 1 ? 'Next' : 'Change password', disabled: false,
    closest: selector => selector === 'form' ? form : selector.startsWith('button,') ? button : null,
    getAttribute: () => '', clicks: 0, click() { this.clicks++; }};
  const storage = shared;
  const listeners = {};
  const messages = [];
  const document = {body: {innerText: ''}, documentElement: {innerText: ''},
    addEventListener(type, fn) { (listeners[type] ||= []).push(fn); },
    querySelectorAll(selector) {
      if (selector === 'button, input[type=submit]') return [button];
      if (selector === 'input[type=password]') return inputs;
      if (selector.endsWith('h1,h2')) return messages;
      return [];
    }};
  const window = {}; window.top = window;
  const context = vm.createContext({window, document, location: new URL('https://myaccount.google.com/signinoptions/password'),
    HTMLInputElement: Input, Event: class { constructor(type) { this.type = type; } },
    sessionStorage: {getItem: key => storage.get(key), setItem: (key, value) => storage.set(key, value), removeItem: key => storage.delete(key)}});
  const code = script.replaceAll('$current', JSON.stringify(current)).replaceAll('$newPassword', JSON.stringify(next))
    .replaceAll('${JSONObject.quote(confirmationToken)}', '"token"')
    .replaceAll('${passwordChangeSubmitted}', 'false').replaceAll('${passwordReauthSubmitted}', 'false')
    .replaceAll('${passwordConfirmationClickIssued}', 'false');
  return {inputs, button, document, context, storage, messages, run: () => vm.runInContext(code, context),
    click(trusted = true) { for (const fn of listeners.click || []) fn({isTrusted: trusted, target: button}); },
    success(text = 'Your password was changed successfully') { messages.push({offsetParent: {}, innerText: text}); }};
}

test('start does not require saved passwords', () => {
  const start = source.split('private fun startPasswordChange(')[1].split('\n    private fun ')[0];
  assert.doesNotMatch(start, /passwordAutomation(?:Current|New)\.isBlank\(\)/);
});
test('missing passwords wait without filling or submitting', () => {
  for (const count of [1, 2, 3]) {
    const p = page(count, '', '');
    assert.equal(p.run(), 'waiting');
    assert.deepEqual(p.inputs.map(x => x.value), Array(count).fill(''));
    assert.equal(p.button.clicks, 0);
  }
});
test('new and confirmation fill even without a current password, but do not submit', () => {
  const p = page(3, '', 'new');
  assert.equal(p.run(), 'waiting');
  assert.deepEqual(p.inputs.map(x => x.value), ['', 'new', 'new']);
  p.inputs[0].type('manual');
  assert.equal(p.run(), 'waiting');
  assert.equal(p.button.clicks, 0);
});
test('manual values and clearing are not overwritten or submitted', () => {
  for (const count of [1, 2, 3]) {
    const p = page(count, 'old', 'new', ['manual']);
    assert.equal(p.run(), 'waiting');
    p.inputs[0].type('');
    assert.equal(p.run(), 'waiting');
    assert.equal(p.inputs[0].value, '');
    assert.equal(p.button.clicks, 0);
  }
});
test('fully app-owned fields submit once', () => {
  for (const count of [1, 2, 3]) {
    const p = page(count);
    assert.equal(p.run(), count === 1 ? 'reauth' : 'submitted');
    p.run();
    assert.equal(p.button.clicks, 1);
  }
});

test('trusted manual click and explicit later success return the exact submitted password', () => {
  const p = page(3, '', 'configured');
  p.run();
  p.inputs[0].type('old manual password');
  p.inputs[1].type('different manual password');
  p.inputs[2].type('different manual password');
  p.click();
  assert.equal(p.run(), 'manual_wait');
  assert.equal(p.button.clicks, 0);
  // A same-origin navigation retains only the run-scoped session record.
  const resultPage = page(0, '', 'configured', [], p.storage);
  resultPage.success();
  const result = JSON.parse(resultPage.run());
  assert.equal(result.status, 'manual_success');
  assert.equal(result.password, 'different manual password');
  assert.equal(result.url, 'https://myaccount.google.com/signinoptions/password');
});

test('requires trusted click, matching values, exact button and no pre-existing success', () => {
  for (const scenario of ['untrusted', 'mismatch', 'wrong-button', 'existing-success', 'different-form', 'wrong-route', 'subframe']) {
    const p = page(2, '', '');
    p.run();
    p.inputs[0].type('manual');
    p.inputs[1].type(scenario === 'mismatch' ? 'other' : 'manual');
    if (scenario === 'wrong-button') p.button.innerText = 'Cancel';
    if (scenario === 'existing-success') p.success();
    if (scenario === 'different-form') p.inputs[0].form = {};
    if (scenario === 'wrong-route') p.context.location.pathname = '/security';
    if (scenario === 'subframe') p.context.window.top = {};
    p.click(scenario !== 'untrusted');
    assert.equal(p.storage.has('__emPasswordManualSubmit'), false, scenario);
  }
});

test('success requires an explicit visible message and no remaining password fields', () => {
  for (const text of ['Your password was not changed', 'You can change your password', 'Password changed?']) {
    const p = page(2, '', ''); p.run();
    p.inputs[0].type('manual'); p.inputs[1].type('manual'); p.click();
    p.inputs.length = 0; p.success(text);
    assert.equal(p.run(), 'manual_wait', text);
  }
  const p = page(2, '', ''); p.run();
  p.inputs[0].type('manual'); p.inputs[1].type('manual'); p.click();
  p.success();
  assert.equal(p.run(), 'manual_wait');
});

test('error, expired records and different run tokens cannot complete a manual submission', () => {
  for (const mode of ['error', 'expired', 'different-token']) {
    const p = page(2, '', ''); p.run();
    p.inputs[0].type('manual'); p.inputs[1].type('manual'); p.click();
    const record = JSON.parse(p.storage.get('__emPasswordManualSubmit'));
    if (mode === 'expired') record.time = Date.now() - 300001;
    if (mode === 'different-token') record.token = 'other';
    p.storage.set('__emPasswordManualSubmit', JSON.stringify(record));
    p.inputs.length = 0;
    if (mode === 'error') p.document.body.innerText = 'Unable to change your password';
    p.success();
    assert.notEqual(p.run().includes('manual_success'), true, mode);
  }
});

test('native completion retains account and lifecycle guards and persists the submitted password', () => {
  assert.match(section, /passwordAutomationAccount\.equals\(observedAccount, true\)/);
  assert.match(section, /manualResult\.optString\("url"\) == view\.url/);
  assert.match(section, /completePasswordAutomationFromSuccess\(view, submittedPassword\)/);
  const complete = source.split('private fun completePasswordAutomationFromSuccess(')[1].split('\n    private fun ')[0];
  assert.match(complete, /val changedPassword = confirmedPassword \?: passwordAutomationNew/);
  assert.match(complete, /updateSavedAccountPassword\(changedPassword, accountOverride = account\)/);
  assert.match(complete, /isPasswordRun\(view, passwordConfirmationToken\)/);
});
