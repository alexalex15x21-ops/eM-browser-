const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(process.env.DEVICES_SOURCE || path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const start = source.indexOf('private fun pollDevicesInitialNavigation(');
const end = source.indexOf('private fun stopDevicesAutomation(', start);
assert.ok(start >= 0 && end > start);
const gate = source.slice(start, end);
const script = gate.match(/val script = """([\s\S]*?)"""\.trimIndent\(\)/)[1];

function element({ tag = 'div', text = '', type = 'text', id = '', name = '', autocomplete = '',
  label = '', placeholder = '', hidden = false, style = {}, parentElement = null, children = [] } = {}) {
  return {
    tag, innerText: text, type, id, name, autocomplete, placeholder, hidden, style, parentElement, children,
    getAttribute: key => key === 'aria-label' ? label : '',
    getBoundingClientRect: () => ({ width: 100, height: 30 }),
    matches: selector => (selector.includes('[role="heading"]') && /^h[123]$/.test(tag)) ||
      (selector.includes('p,label') && ['p', 'label'].includes(tag)),
  };
}

function probe({ url = 'https://accounts.google.com/v3/signin/challenge/totp', expected = url,
  state = 'complete', body = 'Google Account', inputs = [], nodes = [], frames = [], origin = 1234 } = {}) {
  const parsed = new URL(url);
  const document = {
    readyState: state, body: element({ tag: 'body', text: body }),
    querySelectorAll: selector => selector === 'input' ? inputs : selector.startsWith('iframe') ? frames : nodes,
  };
  return vm.runInNewContext(script.replaceAll('${JSONObject.quote(url)}', JSON.stringify(expected)), {
    location: { href: url, protocol: parsed.protocol, hostname: parsed.hostname, port: parsed.port },
    document, performance: { timeOrigin: origin },
    getComputedStyle: el => ({ display: 'block', visibility: 'visible', opacity: '1', ...el.style }),
  });
}

test('screenshot authenticator prompt waits for manual verification', () => {
  const heading = element({ tag: 'h1', text: 'Verify it’s you' });
  const instructions = element({ tag: 'p', text: 'Get a verification code from the Google Authenticator app' });
  const input = element({ id: 'totpPin', label: 'Enter code' });
  assert.equal(probe({ body: 'Verify it’s you Get a verification code from the Google Authenticator app Enter code More ways to verify Next',
    nodes: [heading, instructions], inputs: [input] }), 'challenge');
  assert.equal(probe({ nodes: [heading] }), 'challenge');
  assert.doesNotMatch(gate, /\.click\s*\(|\.value\s*=|dispatchEvent/);
});

test('visible Google login, password, backup, phone and verification challenges wait', () => {
  const cases = [
    { nodes: [element({ tag: 'h1', text: 'Sign in' })], inputs: [element({ type: 'email', id: 'identifierId' })] },
    { nodes: [element({ tag: 'h1', text: 'Welcome' })], inputs: [element({ type: 'password', name: 'Passwd' })] },
    { inputs: [element({ id: 'backupCodePin', label: 'Enter a backup code' })] },
    { inputs: [element({ autocomplete: 'one-time-code' })] },
    { nodes: [element({ tag: 'h1', text: 'Check your phone' })] },
    { nodes: [element({ tag: 'h1', text: 'Choose an account' })] },
    { nodes: [element({ tag: 'h1', text: 'تحقق من هويتك' })] },
    { frames: [element()] },
  ];
  for (const scenario of cases) assert.equal(probe(scenario), 'challenge');
  assert.equal(probe({ nodes: [element({ tag: 'h1', text: 'Just a sec...' })] }), 'waiting');
});

test('signed-in homepage and hidden challenge remnants are not blocked', () => {
  const hiddenParent = element({ style: { display: 'none' } });
  const input = element({ type: 'password', parentElement: hiddenParent });
  const hiddenPrompt = element({ tag: 'h1', text: 'Verify it’s you', parentElement: hiddenParent });
  const home = [element({ tag: 'h1', text: 'Welcome to your Google Account' }),
    element({ tag: 'p', text: 'Security, 2-Step Verification, Password, Your devices' }), hiddenPrompt];
  assert.equal(probe({ url: 'https://myaccount.google.com/', body: 'Welcome to your Google Account Security', nodes: home, inputs: [input] }), 'ready:1234');
  assert.equal(probe({ url: 'https://accounts.google.com/challenge/old', nodes: [element({ tag: 'h1', text: 'Signed in' })] }), 'ready:1234');
});

test('JavaScript refuses wrong URL, non-HTTPS, untrusted host, port, loading and blank document', () => {
  assert.equal(probe({ expected: 'https://accounts.google.com/other' }), 'waiting');
  assert.equal(probe({ url: 'http://accounts.google.com/signin' }), 'waiting');
  assert.equal(probe({ url: 'https://accounts.google.com.evil.test/signin' }), 'waiting');
  assert.equal(probe({ url: 'https://accounts.google.com:8443/signin' }), 'waiting');
  assert.equal(probe({ state: 'loading' }), 'waiting');
  assert.equal(probe({ body: '' }), 'waiting');
});

test('native preflight guards current owner, lifecycle, document, account and stable recheck before Recovery', () => {
  for (const check of [
    /generation == devicesAutomationGeneration/, /isSecurityStageOwner\(view\)/,
    /tabs\.any \{ it\.webView === view \}/, /automationActivityStopped \|\| devicesAutomationPaused \|\| view !== currentWebView\(\)/,
    /!document\.committed \|\| !document\.finished \|\| document\.url != url/,
    /devicesPageDocuments\[view\] !== document/, /document\.revision != revision/,
    /documentGeneration != devicesAutomationDocumentGeneration/, /view\.url\.orEmpty\(\) != url/,
    /now - devicesAutomationInitialReadyAt < 700L/, /devicesAutomationAccount\.equals\(account, true\)/,
  ]) assert.match(gate, check);
  const origin = gate.indexOf('devicesAutomationDocumentOrigin = origin');
  const load = gate.indexOf('view.loadUrl(DEVICES_URL)');
  assert.ok(origin >= 0 && load > origin);
  assert.match(source, /if \(ownsDevices && devicesAutomationInitialPending\) return/);
  assert.match(source, /devicesAutomationFailed \|\| devicesAutomationInitialPending \|\|/);
});

// The model covers callback ordering, not Android WebView integration.
class GateModel {
  constructor() { this.run = 1; this.revision = 0; this.document = 0; this.active = true; this.foreground = true; this.enabled = true; this.readyAt = 0; this.opened = 0; }
  navigate() { this.document++; this.revision = 0; this.readyAt = 0; }
  spa() { this.revision++; this.readyAt = 0; }
  token() { return [this.run, this.document, this.revision]; }
  deliver(token, status, now) {
    if (!this.enabled || !this.active || !this.foreground || token.some((n, i) => n !== this.token()[i])) { this.readyAt = 0; return; }
    if (!status.startsWith('ready:')) { this.readyAt = 0; return; }
    if (!this.readyAt) { this.readyAt = now; return; }
    if (now - this.readyAt >= 700) this.opened++;
  }
  disable() { this.enabled = false; this.run++; }
}

test('simulated login through screenshot challenge resumes only after a fresh signed-in document', () => {
  const gate = new GateModel();
  const login = gate.token();
  gate.deliver(login, probe({ inputs: [element({ id: 'identifierId' })] }), 100);
  gate.navigate();
  const password = gate.token();
  gate.deliver(password, probe({ inputs: [element({ type: 'password' })] }), 1000);
  gate.navigate();
  const authenticator = gate.token();
  gate.deliver(authenticator, probe({ nodes: [element({ tag: 'h1', text: 'Verify it’s you' })] }), 2000);
  gate.deliver(password, 'ready:1234', 3000);
  assert.equal(gate.opened, 0);
  gate.navigate();
  const home = gate.token();
  const signedIn = probe({ url: 'https://myaccount.google.com/', nodes: [element({ tag: 'h1', text: 'Welcome' })] });
  gate.deliver(home, signedIn, 4000);
  gate.deliver(home, signedIn, 4700);
  assert.equal(gate.opened, 1);
});

test('simulated reload, SPA, tab switch, pause, disable and late challenge invalidate readiness', () => {
  const gate = new GateModel();
  let token = gate.token();
  gate.deliver(token, 'ready:1234', 1000);
  gate.foreground = false;
  gate.deliver(token, 'ready:1234', 1800);
  gate.foreground = true;
  gate.deliver(token, 'ready:1234', 2000);
  gate.spa();
  gate.deliver(token, 'ready:1234', 2800);
  token = gate.token();
  gate.deliver(token, 'ready:1234', 3000);
  gate.deliver(token, 'challenge', 3500);
  gate.deliver(token, 'ready:1234', 4000);
  gate.navigate();
  gate.deliver(token, 'ready:1234', 5000);
  token = gate.token();
  gate.deliver(token, 'ready:1234', 6000);
  gate.active = false;
  gate.deliver(token, 'ready:1234', 7000);
  gate.active = true;
  gate.deliver(token, 'ready:1234', 8000);
  gate.disable();
  gate.deliver(token, 'ready:1234', 9000);
  assert.equal(gate.opened, 0);
});
