const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const stage = source.slice(source.indexOf('private fun injectAdsAutomation('), source.indexOf('// ---- YouTube premium stage'));
const finish = source.slice(source.indexOf('private fun finishAdsAutomation('), source.indexOf('private fun injectAdsAutomation('));
const script = stage.match(/val script = """([\s\S]*?)"""\.trimIndent\(\)/)[1]
  .replaceAll("${'$'}", '$').replace('${JSONObject.quote(adsAutomationAccount)}', '"user@example.com"');

function run(options = {}) {
  const element = (text = '', hidden = false) => ({ innerText: text, hidden, parentElement: null,
    getBoundingClientRect: () => ({ width: 100, height: 50 }), getAttribute: () => '' });
  const marker = element(options.text || 'You have no accounts', options.hidden);
  const selection = element(options.selectionText || 'Google Ads 계정 선택', options.selectionHidden);
  const shell = element(options.heading ?? 'Tell us about your business');
  const heading = element(options.heading ?? 'Tell us about your business', options.hiddenHeading);
  shell.contains = el => el === heading;
  const avatar = element();
  avatar.getAttribute = key => key === 'aria-label' ? `Google Account: ${options.account || 'user@example.com'}` : '';
  const document = {
    readyState: 'complete', body: { innerText: options.body || options.text || 'Google Ads account selection' },
    querySelectorAll(selector) {
      if (selector === 'multiaccount-view div.no-accounts-container > h2.no-accounts-tag') return options.marker === false ? [] : [marker];
      if (selector === 'multiaccount-view h2.selection-header-new, multiaccount-view button.new-account-button') return options.selection ? [selection] : [];
      if (selector === 'ufo-root,.awsm-content-main') return options.shell ? [shell] : [];
      if (selector === 'h1.ufo-page-header') return options.shell ? [heading] : [];
      if (selector === '[aria-label],[title]') return options.unverified ? [] : [avatar];
      return [];
    }
  };
  const location = { protocol: options.protocol || 'https:', hostname: options.host || 'ads.google.com', port: '', pathname: options.pathname || '/nav/selectaccount' };
  return vm.runInNewContext(script, { document, location, getComputedStyle: () => ({ display: 'block', visibility: 'visible', opacity: '1' }) });
}

test('no-account marker is available in any language and on the selection route', () => {
  for (const text of ['You don’t have any Google Ads accounts.', 'ليس لديك حسابات في إعلانات Google', 'Google 広告アカウントがありません']) {
    assert.equal(run({ text }), 'found_no_accounts_verified');
  }
  assert.equal(run({ unverified: true }), 'found_no_accounts_unverified');
});

test('hidden or missing marker, wrong account, untrusted host and challenges do not produce availability', () => {
  assert.equal(run({ hidden: true }), 'waiting');
  assert.equal(run({ marker: false }), 'waiting');
  assert.equal(run({ account: 'other@example.com' }), 'account_mismatch');
  assert.equal(run({ host: 'example.com' }), 'waiting');
  assert.equal(run({ body: 'Verify your identity' }), 'waiting');
});

test('existing Ads signup success remains supported', () => {
  assert.equal(run({ marker: false, shell: true, pathname: '/aw/signup' }), 'found_verified');
});

test('signup heading is recognized structurally in different languages', () => {
  for (const heading of ['Tell us about your business', 'أخبرنا عن نشاطك التجاري', '告诉我们有关您的商家信息', 'ビジネスについてお知らせください', '귀하의 비즈니스에 대해 알려주세요', 'Décrivez votre entreprise']) {
    assert.equal(run({ marker: false, shell: true, pathname: '/aw/signup/mobile/business', heading }), 'found_verified');
  }
  assert.equal(run({ marker: false, shell: true, pathname: '/aw/other', heading: '任意のページ' }), 'loaded_verified');
  assert.equal(run({ marker: false, shell: true, pathname: '/aw/signup', hiddenHeading: true }), 'loaded_verified');
  assert.equal(run({ marker: false, shell: true, pathname: '/aw/signup', heading: '' }), 'waiting');
});

test('either visible selection marker records availability independent of language', () => {
  for (const selectionText of ['Google Ads 계정 선택', 'اختر حساب Google Ads', '選択', '选择账号', 'Select a Google Ads account']) {
    assert.equal(run({ marker: false, selection: 'heading', selectionText }), 'found_selection_verified');
    assert.equal(run({ marker: false, selection: 'button', selectionText }), 'found_selection_verified');
  }
  assert.equal(run({ marker: false, selection: 'heading', unverified: true }), 'found_selection_unverified');
  assert.equal(run({ marker: false, selection: 'button', selectionHidden: true }), 'waiting');
  assert.equal(run({ marker: false, selection: 'heading', account: 'other@example.com' }), 'account_mismatch');
  assert.equal(run({ marker: false, selection: 'button', host: 'example.com' }), 'waiting');
});

test('availability notifications match saved result', () => {
  assert.match(finish, /if \(found\) "ads available" else "ads not available/);
  assert.match(stage, /scriptResult == "found_selection_verified" \|\| scriptResult == "found_selection_unverified"/);
});

test('account mismatch is retained on account selection routes', () => {
  assert.match(stage, /scriptResult == "account_mismatch"/);
});

test('new result uses existing persistence and stage completion flow', () => {
  assert.match(stage, /value == "found_no_accounts_verified"/);
  assert.match(finish, /persistAdsResult\(account, found\)/);
  assert.match(finish, /markStageCompleted\("ads", view, account\)/);
  assert.match(source, /ADS_DETECTION_TIMEOUT_MS = 5_000L/);
  assert.match(stage, /adsAutomationLoadedAt > 0L && now - adsAutomationLoadedAt >= ADS_DETECTION_TIMEOUT_MS/);
  assert.match(source, /pageUrl == view\.url && !adsAutomationLoadFailed/);
  assert.match(source, /adsAutomationLoadedAt = android\.os\.SystemClock\.elapsedRealtime\(\)/);
  assert.match(stage, /ADS_LOAD_TIMEOUT_MS/);
  assert.match(stage, /Ads page did not load; no result saved/);
  assert.match(finish, /startNextConfiguredStage\(view, "ads", immediate = true/);
});
