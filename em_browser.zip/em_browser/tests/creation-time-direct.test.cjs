const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const setting = source.slice(source.indexOf('addSettingRow("Creation Time"'), source.indexOf('addSettingRow("Password"'));
const start = source.slice(source.indexOf('private fun startCreationTimeAutomation('), source.indexOf('private fun stopCreationTimeAutomation('));
const extract = source.slice(source.indexOf('private fun extractCreationTime('), source.indexOf('private fun startDevicesAutomation('));
const script = extract.match(/val script = """([\s\S]*?)"""\.trimIndent\(\)/)[1];

function parse(text) {
  const element = { innerText: text, closest: () => ({ innerText: 'When you created your account' }) };
  return vm.runInNewContext(script, { document: { querySelectorAll: () => [element] } });
}

test('Creation Time starts only through the Auto pipeline', () => {
  assert.match(setting, /restartConfiguredAutomationIfMasterIsAlreadyOn\(\)/);
  assert.doesNotMatch(setting, /startCreationTimeAutomation\(view\)/);
  assert.match(start, /view\.loadUrl\(withSelectedLanguage\(CREATION_TIME_URL\)\)/);
  assert.match(start, /!automationMasterEnabled/);
});

test('extracts only the year with or without a day', () => {
  assert.equal(parse('On since January 12, 2018'), '2018');
  assert.equal(parse('Off since November 2005'), '2005');
  assert.equal(parse('On since January 12, 1890'), '');
});

test('new records remove month and all views use year only', () => {
  const save = source.slice(source.indexOf('private fun saveAccountCreationTime('), source.indexOf('private fun backupCodesKey('));
  assert.match(source, /private fun accountCreationTime\(item: JSONObject\): String = item\.optString\("creationYear"\)/);
  assert.match(save, /item\.put\("creationYear", year\)/);
  assert.match(save, /item\.remove\("creationMonth"\)/);
  assert.doesNotMatch(save, /item\.put\("creationMonth"/);
});

test('missing year uses 2023 only on a loaded target page and preserves an existing year', () => {
  const fallback = source.slice(source.indexOf('private fun finishCreationTimeWithoutYear('), source.indexOf('private fun injectCreationTimeAutomation('));
  const code = fallback.match(/val script = """([\s\S]*?)"""\.trimIndent\(\)/)[1];
  const page = (overrides = {}) => vm.runInNewContext(code, {
    location: {protocol: 'https:', hostname: 'myactivity.google.com', pathname: '/product/youtube/controls', ...overrides.location},
    document: {readyState: 'complete', body: {innerText: 'YouTube History controls'}, ...overrides.document}
  });
  assert.equal(page(), 'ready');
  assert.equal(page({location: {hostname: 'example.com'}}), '');
  assert.equal(page({document: {readyState: 'loading'}}), '');
  assert.equal(page({document: {body: {innerText: 'Verify your identity'}}}), '');
  assert.match(fallback, /existing\.takeIf \{ it\.matches\(Regex\([^\n]+\)\) \} \?: "2023"/);
  assert.match(fallback, /generation != creationTimeAutomationGeneration/);
  assert.match(fallback, /accountKeyByWebView\[view\]/);
});
