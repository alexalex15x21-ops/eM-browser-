const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const autofill = source.split('private fun startBackupCodePromptAutofill(')[1].split('\n    private fun ')[0];
const context = autofill.match(/val promptContext = """([\s\S]*?)"""\.trimIndent\(\)/)[1]
  .replace('${JSONObject.quote(promptUrl)}', '"https://accounts.google.com/challenge"')
  .replaceAll("${'$'}", '$');

function prompt(options = {}) {
  const events = {};
  const input = { id: 'backupCodePin', value: options.value || '', disabled: !!options.disabled, readOnly: false,
    nodeType: 1, parentElement: null, getBoundingClientRect: () => ({width: 100, height: 30}),
    getAttribute: () => '', addEventListener: (name, handler) => { events[name] = handler; } };
  const profile = { id: 'profileIdentifier', innerText: options.account || 'user@example.com', nodeType: 1,
    parentElement: null, getBoundingClientRect: () => ({width: 100, height: 30}), getAttribute: () => '' };
  const location = { href: options.url || 'https://accounts.google.com/challenge', protocol: 'https:', hostname: 'accounts.google.com', port: '' };
  const window = { location }; window.top = window;
  const document = { visibilityState: 'visible', querySelectorAll: selector => selector === 'input' ? [input] : (options.noIdentity ? [] : [profile]) };
  const sandbox = { window, location, document, getComputedStyle: () => ({display:'block', visibility:'visible', opacity:'1'}) };
  const run = () => vm.runInNewContext(`(() => { ${context}\nreturn backupPrompt()?.account || ''; })()`, sandbox);
  return { run, events, input };
}

test('backup codes are account-scoped and validated as distinct eight digit entries', () => {
  const dialog = source.split('private fun showPasswordChangeDialog()')[1].split('\n    private fun ')[0];
  assert.match(dialog, /values\.distinct\(\)\.size != values\.size/);
  assert.match(dialog, /\[0-9\]\{8\}/);
  assert.match(dialog, /saveAccountBackupCodes\(backupAccount, values\)/);
  assert.doesNotMatch(source, /Backup codes \(Import \/ Export\)|showBackupCodesDialog/);
});

test('selects the last unused of the final two codes per tab and never submits', () => {
  assert.match(autofill, /backupCodesUsedByWebView\.getOrPut\(view\)/);
  assert.match(autofill, /takeLast\(2\)\.asReversed\(\)\.firstOrNull/);
  assert.match(autofill, /if \(filled == "true"\) used\.add\(code\)/);
  assert.match(autofill, /backupImportAccountByWebView\[view\]/);
  assert.match(autofill, /observed != bound/);
  assert.doesNotMatch(autofill, /\.submit\(|\.click\(/);
});

test('imports valid codes from exported rows and shows account-scoped current backup', () => {
  const parser = source.split('private fun parseCredentialRow(')[1].split('\n    private fun ')[0];
  const save = source.split('private fun saveCredentialRow(')[1].split('\n    private fun ')[0];
  const passwordDialog = source.split('private fun showPasswordChangeDialog()')[1].split('\n    private fun ')[0];
  assert.match(parser, /columns\.drop\(3\)\.flatMap/);
  assert.match(parser, /filter \{ it\.matches\(Regex\("\[0-9\]\{8\}"\)\) \}\.distinct\(\)/);
  assert.match(parser, /codes\.isNotEmpty\(\) \|\|/);
  assert.match(parser, /\[0-9\]\{7,8\}/);
  assert.match(save, /saveAccountBackupCodes\(account, row\.backupCodes\)/);
  assert.match(save, /current_backup_account/);
  assert.match(passwordDialog, /hint = "Current backup"/);
  assert.match(passwordDialog, /readAccountBackupCodes\(it\)/);
  assert.doesNotMatch(source, /Invalid backup codes skipped|Password\/2FA saved from pasted text/);
});

test('backup-code token rules accept spaced and grouped columns without treating 7 digits as a code', () => {
  const parser = source.split('private fun parseCredentialRow(')[1].split('\n    private fun ')[0];
  const pattern = parser.match(/filter \{ it\.matches\(Regex\("(\[0-9\]\{8\})"\)\) \}\.distinct\(\)/)[1];
  const row = ['user@example.com', 'example-password', 'ABCDEFGHIJKLMNOP', '', '2026', 'extra metadata',
    ' 12345678 ', '23456789 34567890', '7654321', '23456789'];
  const codes = [...new Set(row.slice(3).flatMap(column => column.trim().split(/[\s,;|]+/))
    .filter(value => new RegExp(`^${pattern}$`).test(value)))];
  assert.deepEqual(codes, ['12345678', '23456789', '34567890']);
});

test('recognizes the inspected field but preserves manual edits', () => {
  const p = prompt();
  assert.equal(p.run(), 'user@example.com');
  p.events.input({isTrusted: true});
  assert.equal(p.run(), '');
  assert.equal(prompt({value:'12345678'}).run(), '');
  assert.equal(prompt({disabled:true}).run(), '');
  assert.equal(prompt({url:'https://accounts.google.com/other'}).run(), '');
  assert.equal(prompt({noIdentity:true}).run(), '__no_identity__');
});
