const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const dialog = source.split('private fun showBackupCodesDialog()')[1].split('\n    private fun ')[0];
const autofill = source.split('private fun startBackupCodePromptAutofill(')[1].split('\n    private fun ')[0];
const context = autofill.match(/val promptContext = """([\s\S]*?)"""\.trimIndent\(\)/)[1]
  .replace('${JSONObject.quote(promptUrl)}', '"https://accounts.google.com/challenge"')
  .replaceAll("${'$'}", '$');

function prompt(options = {}) {
  const events = {};
  const input = { id: 'backupCodePin', value: options.value || '', disabled: !!options.disabled, readOnly: false,
    nodeType: 1, parentElement: null, getBoundingClientRect: () => ({width: 100, height: 30}),
    getAttribute: () => '', addEventListener: (name, handler) => { events[name] = handler; } };
  const profile = { id: 'profileIdentifier', innerText: options.account || 'user@example.com', nodeType: 1,
    parentElement: null, getBoundingClientRect: () => ({width: 100, height: 30}), getAttribute: () => '' };
  const location = { href: options.url || 'https://accounts.google.com/challenge', protocol: 'https:', hostname: 'accounts.google.com', port: '' };
  const window = { location }; window.top = window;
  const document = { visibilityState: 'visible', querySelectorAll: selector => selector === 'input' ? [input] : [profile] };
  const sandbox = { window, location, document, getComputedStyle: () => ({display:'block', visibility:'visible', opacity:'1'}) };
  const run = () => vm.runInNewContext(`(() => { ${context}\nreturn backupPrompt()?.account || ''; })()`, sandbox);
  return { run, events, input };
}

test('backup codes are account-scoped and validated as distinct eight digit entries', () => {
  assert.match(dialog, /Google account email/);
  assert.match(dialog, /values\.size !in 2\.\.10/);
  assert.match(dialog, /values\.distinct\(\)\.size != values\.size/);
  assert.match(dialog, /\[0-9\]\{8\}/);
  assert.match(dialog, /saveAccountBackupCodes\(key, values\)/);
  assert.match(dialog, /readAccountBackupCodes\(it\)/);
  assert.match(source, /text = "Backup codes \(Import \/ Export\)"/);
});

test('selects last code and never submits the challenge', () => {
  assert.match(autofill, /readAccountBackupCodes\(item\)\.lastOrNull\(\)/);
  assert.doesNotMatch(autofill, /\.submit\(|\.click\(/);
  assert.match(autofill, /filled == "true"/);
});

test('imports valid codes from exported rows and shows account-scoped current backup', () => {
  const parser = source.split('private fun parseCredentialRow(')[1].split('\n    private fun ')[0];
  const save = source.split('private fun saveCredentialRow(')[1].split('\n    private fun ')[0];
  const passwordDialog = source.split('private fun showPasswordChangeDialog()')[1].split('\n    private fun ')[0];
  assert.match(parser, /columns\.drop\(4\)/);
  assert.match(parser, /backupColumns\.filter \{ it\.matches\(Regex\("\[0-9\]\{8\}"\)\) \}/);
  assert.match(parser, /\[0-9\]\{7\}/);
  assert.match(save, /saveAccountBackupCodes\(account, row\.backupCodes\)/);
  assert.match(save, /current_backup_account/);
  assert.match(passwordDialog, /hint = "Current backup"/);
  assert.match(passwordDialog, /readAccountBackupCodes\(it\)/);
});

test('recognizes the inspected field but preserves manual edits', () => {
  const p = prompt();
  assert.equal(p.run(), 'user@example.com');
  p.events.input({isTrusted: true});
  assert.equal(p.run(), '');
  assert.equal(prompt({value:'12345678'}).run(), '');
  assert.equal(prompt({disabled:true}).run(), '');
  assert.equal(prompt({url:'https://accounts.google.com/other'}).run(), '');
});
