const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const dialog = source.split('private fun showPasswordChangeDialog()')[1].split('\n    private fun ')[0];

test('new password menu shows the requested suggestions on the right', () => {
  assert.match(dialog, /passwordField\("New password", savedNew\)/);
  assert.doesNotMatch(dialog, /passwordField\("Confirm new password"/);
  assert.ok(dialog.includes(`listOf("horiyamo12", "HRN12##99${"${'$'}"}", "Homjdjfhghd", "Teghdjdjkdj646")`));
  assert.doesNotMatch(dialog, /popup\.menu\.add\("Add"\)|popup\.menu\.add\("Edit"\)/);
  assert.match(dialog, /newPassword\.setText\(item\.title\)/);
  assert.match(dialog, /container\.addView\(currentRecovery, LinearLayout\.LayoutParams\(-1, dp\(56\)\)\)/);
  assert.doesNotMatch(dialog, /oldPassword\.isBlank\(\)|newValue\.isBlank\(\)/);
  assert.match(dialog, /val button = TextView\(this\)/);
  assert.match(dialog, /text = "⋮"/);
  assert.match(dialog, /textSize = 20f/);
  assert.match(dialog, /background = null/);
  assert.match(dialog, /layoutDirection = View\.LAYOUT_DIRECTION_LTR/);
  assert.match(dialog, /row\.addView\(newPassword[^\n]*\n\s*row\.addView\(button, LinearLayout\.LayoutParams\(dp\(32\), dp\(40\)\)\)/);
});
