const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const dialog = source.split('private fun showPasswordChangeDialog()')[1].split('\n    private fun ')[0];

test('one new password field and selectable password and recovery suggestions', () => {
  assert.match(dialog, /passwordField\("New password", savedNew\)/);
  assert.doesNotMatch(dialog, /passwordField\("Confirm new password"/);
  assert.match(dialog, /addSuggestions\(newPassword, listOf\("horiyamo12", "Homjdjfhghd", "Teghdjdjkdj646"\)\)/);
  assert.match(dialog, /addSuggestions\(currentRecovery, listOf\("alexalex15x21@gmail.com", "so4173j9@gmail.com"\)\)/);
  assert.match(dialog, /field\.setText\(item\.title\)/);
  assert.doesNotMatch(dialog, /oldPassword\.isBlank\(\)|newValue\.isBlank\(\)/);
  assert.match(dialog, /val button = TextView\(this\)/);
  assert.match(dialog, /text = "⋮"/);
  assert.match(dialog, /textSize = 24f/);
  assert.match(dialog, /background = null/);
  assert.match(dialog, /row\.addView\(button, LinearLayout\.LayoutParams\(dp\(36\), dp\(40\)\)\)/);
});
