const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const dialog = source.split('private fun showPasswordChangeDialog()')[1].split('\n    private fun ')[0];

test('new password menu manages saved passwords and recovery has no side button', () => {
  assert.match(dialog, /passwordField\("New password", savedNew\)/);
  assert.doesNotMatch(dialog, /passwordField\("Confirm new password"/);
  assert.doesNotMatch(dialog, /horiyamo12|Homjdjfhghd|Teghdjdjkdj646|alexalex15x21@gmail\.com|so4173j9@gmail\.com/);
  assert.match(dialog, /popup\.menu\.add\("Add"\)/);
  assert.match(dialog, /popup\.menu\.add\("Edit"\)/);
  assert.match(dialog, /values\.add\(value\) else values\[index\] = value/);
  assert.match(dialog, /values\.removeAt\(index\)/);
  assert.match(dialog, /savePasswords\(values\)/);
  assert.match(dialog, /container\.addView\(currentRecovery, LinearLayout\.LayoutParams\(-1, dp\(56\)\)\)/);
  assert.doesNotMatch(dialog, /oldPassword\.isBlank\(\)|newValue\.isBlank\(\)/);
  assert.match(dialog, /val button = TextView\(this\)/);
  assert.match(dialog, /text = "⋮"/);
  assert.match(dialog, /textSize = 20f/);
  assert.match(dialog, /background = null/);
  assert.match(dialog, /row\.addView\(button, LinearLayout\.LayoutParams\(dp\(32\), dp\(40\)\)\)[\s\S]*row\.addView\(newPassword/);
});
