const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const dialog = source.split('private fun showPasswordChangeDialog()')[1].split('\n    private fun ')[0];

test('new password is editable without a side suggestions button', () => {
  assert.match(dialog, /passwordField\("New password", savedNew\)/);
  assert.doesNotMatch(dialog, /passwordField\("Confirm new password"/);
  assert.doesNotMatch(dialog, /PopupMenu|Show new password suggestions/);
  assert.match(dialog, /container\.addView\(newPassword, LinearLayout\.LayoutParams\(-1, dp\(56\)\)\)/);
  assert.match(dialog, /val newValue = newPassword\.text\?\.toString\(\)\.orEmpty\(\)/);
  assert.match(dialog, /container\.addView\(currentRecovery, LinearLayout\.LayoutParams\(-1, dp\(56\)\)\)/);
  assert.doesNotMatch(dialog, /oldPassword\.isBlank\(\)|newValue\.isBlank\(\)/);
});
