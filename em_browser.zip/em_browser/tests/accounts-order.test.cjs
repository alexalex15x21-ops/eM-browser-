const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const dialog = source.slice(source.indexOf('private fun showSavedAuthenticatorAccountsDialog()'), source.indexOf('private fun showRecoveryEmailInfoDialog()'));
const exportRow = source.split('private fun accountExportRow(')[1].split('\n    private fun ')[0];

test('single and bulk copy share fixed columns including ten backup slots', () => {
  assert.equal((dialog.match(/accountExportRow\(item\)/g) || []).length, 2);
  assert.match(exportRow, /twoFa\.ifBlank \{ item\.optString\("recoveryEmail"\) \}, ""/);
  assert.match(exportRow, /List\(10\) \{ backupCodes\.getOrNull\(it\)\.orEmpty\(\) \}/);
  assert.match(exportRow, /accountCreationTime\(item\), item\.optString\("ads"\),\s*item\.optString\("youtubePremium"\), item\.optString\("appPassword"\)/);
  assert.match(exportRow, /joinToString\("\\t"\)/);
});

test('display follows the same field order without altering encrypted backup storage', () => {
  const display = dialog.slice(dialog.indexOf('text = buildString'), dialog.indexOf('textSize = 14f'));
  const fields = ['account.isNotBlank()', 'password.isNotBlank()', 'twoFa.isNotBlank()', 'backupCodes.isNotEmpty()', 'creationTime.isNotBlank()', 'ads.isNotBlank()', 'youtubePremium.isNotBlank()', 'appPassword.isNotBlank()'];
  const positions = fields.map(field => display.indexOf(field));
  assert.ok(positions.every((position, i) => position >= 0 && (i === 0 || position > positions[i - 1])));
  assert.match(source, /cipher\.doFinal\(JSONArray\(codes\)\.toString\(\)\.toByteArray/);
});
