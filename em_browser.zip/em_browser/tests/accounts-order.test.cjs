const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const dialog = source.slice(source.indexOf('private fun showSavedAuthenticatorAccountsDialog()'), source.indexOf('private fun showRecoveryEmailInfoDialog()'));

test('single and bulk copy keep the same column order and an empty fourth column', () => {
  const row = /append\(account\)\.append\('\\t'\)\.append\(password\)\.append\('\\t'\)\s*\.append\(twoFa\.ifBlank \{ recovery \}\)\.append\("\\t\\t"\)\.append\(backupCodes(?:\.joinToString\("\\t"\))?\)\s*\.append\('\\t'\)\.append\(creationTime\)\.append\('\\t'\)\.append\(ads\)\.append\('\\t'\)\.append\(youtubePremium\)\s*\.append\('\\t'\)\.append\(appPassword\)/g;
  assert.equal([...dialog.matchAll(row)].length, 2);
  assert.match(dialog, /val backupCodes = readAccountBackupCodes\(item\)\.joinToString\("\\t"\)/);
});

test('display follows the same field order without altering encrypted backup storage', () => {
  const display = dialog.slice(dialog.indexOf('text = buildString'), dialog.indexOf('textSize = 14f'));
  const fields = ['account.isNotBlank()', 'password.isNotBlank()', 'twoFa.isNotBlank()', 'backupCodes.isNotEmpty()', 'creationTime.isNotBlank()', 'ads.isNotBlank()', 'youtubePremium.isNotBlank()', 'appPassword.isNotBlank()'];
  const positions = fields.map(field => display.indexOf(field));
  assert.ok(positions.every((position, i) => position >= 0 && (i === 0 || position > positions[i - 1])));
  assert.match(source, /cipher\.doFinal\(JSONArray\(codes\)\.toString\(\)\.toByteArray/);
});
