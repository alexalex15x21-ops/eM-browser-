const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require('node:path').join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const section = source.split('private fun scheduleAddProbe(')[1].split('private fun recordAddLogin(')[0];
const scripts = [...section.matchAll(/val script = """([\s\S]*?)"""\.trimIndent\(\)/g)].map(m => m[1]
  .replaceAll('${JSONObject.quote(url)}', JSON.stringify('https://myaccount.google.com/'))
  .replaceAll('${JSONObject.quote(email)}', JSON.stringify('a@example.com')));

function success({origin = 'https://myaccount.google.com', pathname = '/', visible = true, labels = ['Google Account: a@example.com'], challenge = false} = {}) {
  const elements = labels.map(label => ({getBoundingClientRect: () => ({width: 10, height: 10}), getAttribute: key => key === 'aria-label' ? label : null}));
  const document = {readyState: 'complete', visibilityState: visible ? 'visible' : 'hidden',
    querySelector: () => challenge ? {} : null, querySelectorAll: () => elements};
  const context = {document, location: {origin, pathname, href: 'https://myaccount.google.com/'}, getComputedStyle: () => ({visibility: 'visible', display: 'block'})};
  context.window = {}; context.window.top = context.window;
  return vm.runInNewContext(scripts[1], context);
}

test('ADD success requires trusted, visible matching account context', () => {
  assert.equal(scripts.length, 2);
  assert.equal(success(), 'a@example.com');
  assert.equal(success({origin: 'https://evil.example'}), '');
  assert.equal(success({pathname: '/challenge/password'}), '');
  assert.equal(success({visible: false}), '');
  assert.equal(success({challenge: true}), '');
  assert.equal(success({labels: ['Google Account: a@example.com', 'Google Account: b@example.com']}), '');
  assert.equal(success({labels: ['a@example.com']}), '');
});

test('ADD queue is bounded, manual and saves only after the owned success callback', () => {
  const dialog = source.split('private fun showAddDialog()')[1].split('private fun advanceAddAccount()')[0];
  assert.match(dialog, /rows\.size > 50/);
  assert.doesNotMatch(dialog, /saveAuthenticatorAccounts|saveCredentialRow|recordAddLogin/);
  assert.match(section, /addRows\.first\(\)/);
  assert.match(section, /host == "accounts\.google\.com"/);
  assert.match(section, /view\.url == url && credentialDocuments\[view\] === document/);
  assert.match(section, /result == JSONObject\.quote\(email\)/);
  assert.match(section, /addAttemptView === view && addAttemptRow == row/);
  assert.equal((source.match(/recordAddLogin\(row, email\)/g) || []).length, 1);
  assert.match(source.split('private fun advanceAddAccount()')[1].split('private fun scheduleAddProbe(')[0], /addRows = addRows\.drop\(1\)/);
});
