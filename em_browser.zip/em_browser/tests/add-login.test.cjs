const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require('node:path').join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const section = source.split('private fun scheduleAddProbe(')[1].split('private fun recordAddLogin(')[0];
const scripts = [...section.matchAll(/val script = """([\s\S]*?)"""\.trimIndent\(\)/g)].map(m => m[1]
  .replaceAll('${JSONObject.quote(url)}', JSON.stringify('https://myaccount.google.com/'))
  .replaceAll('${JSONObject.quote(email)}', JSON.stringify('a@example.com')));

function success({origin = 'https://myaccount.google.com', pathname = '/', visible = true, labels = ['Google Account: a@example.com'], challenge = false} = {}) {
  const elements = labels.map(label => ({getBoundingClientRect: () => ({width: 10, height: 10}), getAttribute: key => key === 'aria-label' ? label : null}));
  const document = {readyState: 'complete', visibilityState: visible ? 'visible' : 'hidden',
    querySelector: () => challenge ? {} : null, querySelectorAll: () => elements};
  const context = {document, location: {origin, pathname, href: 'https://myaccount.google.com/'}, getComputedStyle: () => ({visibility: 'visible', display: 'block'})};
  context.window = {}; context.window.top = context.window;
  return vm.runInNewContext(scripts[1], context);
}

test('ADD success requires trusted, visible matching account context', () => {
  assert.equal(scripts.length, 2);
  assert.equal(success(), 'a@example.com');
  assert.equal(success({origin: 'https://evil.example'}), '');
  assert.equal(success({pathname: '/challenge/password'}), '');
  assert.equal(success({visible: false}), '');
  assert.equal(success({challenge: true}), '');
  assert.equal(success({labels: ['Google Account: a@example.com', 'Google Account: b@example.com']}), '');
  assert.equal(success({labels: ['a@example.com']}), '');
});

test('ADD queue is bounded and manual completion saves before advancing', () => {
  const dialog = source.split('private fun showAddDialog()')[1].split('private fun advanceAddAccount(')[0];
  assert.match(dialog, /rows\.size > 50/);
  assert.doesNotMatch(dialog, /saveAuthenticatorAccounts|saveCredentialRow|recordAddLogin/);
  assert.match(section, /addRows\.first\(\)/);
  assert.match(section, /host == "accounts\.google\.com"/);
  assert.match(section, /view\.url == url && credentialDocuments\[view\] === document/);
  assert.match(section, /result == JSONObject\.quote\(email\)/);
  assert.match(section, /addAttemptView === view && addAttemptRow == row/);
  assert.equal((source.match(/recordAddLogin\(row, email\)/g) || []).length, 1);
  const advance = source.split('private fun advanceAddAccount(')[1].split('private fun clearAddCredential(')[0];
  assert.match(advance, /saveSkippedAccount\(raw\)/);
  assert.match(advance, /recordAddLogin\(raw, email, confirmed = false\)/);
  assert.match(advance, /if \(!saved\)[\s\S]*?return[\s\S]*?addRows = addRows\.drop\(1\)/);
  assert.match(dialog, /setHorizontallyScrolling\(true\)/);
});

test('ADD bridge uses only the owned in-memory row and never persists pasted rows', () => {
  const bridge = source.split('private inner class CredentialBridge')[1].split('private val credentialBridge')[0];
  assert.match(bridge, /row != null && !addEnabled[\s\S]*?saveCredentialRow\(row\)/);
  assert.match(bridge, /"password" -> if \(addEnabled\) boundAddCredential\(view\)\?\.password\.orEmpty\(\) else/);
  assert.match(bridge, /boundAddCredential\(view\)\?\.twoFa\.orEmpty\(\)/);
  assert.match(bridge, /totpCode\(secret, "SHA1", 6, 30L\)/);
  assert.match(bridge, /else currentTotpCode\(\)/);
  const bound = source.split('private fun boundAddCredential(')[1].split('private fun scheduleAddProbe(')[0];
  for (const guard of ['!addEnabled', 'addAttemptView !== view',
    'addBoundGeneration != addCredentialGeneration', 'addRows.firstOrNull() != addAttemptRow']) assert.ok(bound.includes(guard));
  assert.doesNotMatch(bound, /addRowRecorded/);
  assert.match(section, /result == "true"[\s\S]*?addCredential = parseCredentialRow\(row\)\?\.takeIf/);
  assert.match(section, /credentialDocuments\[view\] === document && addRows\.firstOrNull\(\) == row/);
});

test('ADD transitions revoke the bound row and pending replies without changing non-ADD saves', () => {
  for (const name of ['showAddDialog()', 'advanceAddAccount(skip: Boolean)', 'clearAllBrowserData()']) {
    const body = source.split(`private fun ${name}`)[1].split('\n    private fun ')[0];
    assert.match(body, /clearAddCredential\(\)/);
  }
  assert.match(source, /menuSwitchItem\("ADD", addEnabled\)[\s\S]*?clearAddCredential\(\)/);
  assert.match(source, /addAttemptView === tabs\[index\]\.webView[\s\S]*?clearAddCredential\(\)/);
  assert.match(source, /addAttemptView !== webView[\s\S]*?__emCancelCredentialRequests/);
  const result = section.split('if (recordAddLogin(row, email)) {')[1].split('} else {');
  assert.match(result[0], /addRowRecorded = true/);
  assert.doesNotMatch(result[0], /clearAddCredential\(|addAttemptView = null|saveCredentialRow/);
  assert.match(result[1], /clearAddCredential\(\)/);
  assert.match(section, /addRows\.isEmpty\(\) \|\| addRowRecorded/);
  assert.match(source, /if \(!addEnabled\) \{\s*saveCredentialRow\(row\)/);
});

test('retained bridge credentials remain view and row scoped after success', () => {
  const body = source.split('private fun boundAddCredential(')[1].split('private fun scheduleAddProbe(')[0];
  assert.match(body, /!addEnabled \|\| addAttemptView !== view \|\| addBoundGeneration != addCredentialGeneration/);
  assert.match(body, /addRows\.firstOrNull\(\) != addAttemptRow/);
  assert.match(body, /return addCredential/);
  const bridge = source.split('private inner class CredentialBridge')[1].split('private val credentialBridge')[0];
  assert.match(bridge, /view !== currentWebView\(\) \|\| !view\.isAttachedToWindow/);
  assert.match(bridge, /"password" -> if \(addEnabled\) boundAddCredential\(view\)\?\.password\.orEmpty\(\)/);
  assert.match(bridge, /boundAddCredential\(view\)\?\.twoFa\.orEmpty\(\)/);
});
