const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const section = (a, b) => source.slice(source.indexOf(a), source.indexOf(b, source.indexOf(a)));

test('settings and pipeline use the requested order', () => {
  const pipeline = section('private val AUTOMATION_PIPELINE', 'private const val APP_PASSWORD_AUTOMATION_TIMEOUT_MS');
  assert.deepEqual([...pipeline.matchAll(/"([a-z_]+)"/g)].map(m => m[1]),
    ['authenticator', 'two_step', 'backup', 'password', 'creation_time', 'ads', 'youtube_premium', 'app_password']);
  const order = source.match(/val order = listOf\(([^\n]+)\)/)[1];
  assert.deepEqual([...order.matchAll(/"([^"]+)"/g)].map(m => m[1]),
    ['Authenticator', '2-Step', 'Backup', 'Password', 'Creation Time', 'Ads', 'YouTube premium', 'App password', 'Inspect']);
  assert.match(source, /settingsLayout\.addView\(settingRow, index/);
});

test('Backup is controlled by Auto, stage selection, ownership and cancellation', () => {
  const start = section('private fun startBackupAutomation(', 'private fun resetBackupAutomationCandidate(');
  const setting = section('addSettingRow("Backup"', 'addSettingRow("App password"');
  assert.match(start, /!automationMasterEnabled \|\| !backupAutomationEnabled/);
  assert.match(setting, /restartConfiguredAutomationIfMasterIsAlreadyOn/);
  assert.match(setting, /clearStageCompleted\("backup", account\)/);
  assert.match(setting, /startNextConfiguredStage\(owner, "backup", immediate = true, accountOverride = account\)/);
  assert.match(source, /"backup" -> backupAutomationEnabled/);
  assert.match(source, /"backup" -> startBackupAutomation\(view\)/);
  assert.equal([...source.matchAll(/startBackupAutomation\(view\)/g)].length, 1);
  assert.match(source, /backupAutomationView == null \|\| backupAutomationView === view/);
  assert.match(source, /if \(cancelBackup\) stopBackupAutomation\(\)/);
});

test('Backup completion requires settled valid matching account codes and durable storage', () => {
  const probe = section('private fun probeBackupAutomation(', 'private fun clearPasswordAutomationState(');
  assert.match(probe, /backupAutomationDocumentGeneration != documentGeneration/);
  assert.match(probe, /googleVerificationActive \|\| googleVerificationCheckPending/);
  assert.match(probe, /knownAccount != account/);
  assert.match(probe, /detectedAccount != account/);
  assert.match(probe, /codes\.distinct\(\)\.size != codes\.size/);
  assert.match(probe, /BACKUP_AUTOMATION_SETTLE_MS/);
  assert.match(probe, /!backupAutomationSaveFailed && existing != null/);
  assert.match(probe, /backupAutomationSaveFailed = !saved/);
  assert.match(probe, /matchesSaved \|\| runCatching \{ saveAccountBackupCodes\(account, codes\) \}/);
  assert.match(probe, /if \(saved\) \{[\s\S]*markStageCompleted\("backup", view, account\)[\s\S]*stopBackupAutomation\(\)[\s\S]*startNextConfiguredStage\(view, "backup", accountOverride = account\)/);
  const save = section('private fun saveAccountBackupCodes(', 'private fun readAccountBackupCodes(');
  assert.match(save, /AES\/GCM\/NoPadding/);
  assert.match(save, /\.commit\(\)/);
});

test('Backup suspends and resumes on lifecycle and tab changes without restarting', () => {
  const suspend = section('private fun suspendBackupAutomation(', 'private fun cancelBackupAutomationForView(');
  assert.match(suspend, /backupAutomationGeneration\+\+/);
  assert.doesNotMatch(suspend, /backupAutomationView = null/);
  assert.match(section('override fun onPause()', 'override fun onStart()'), /suspendBackupAutomation\(\)/);
  assert.match(section('override fun onStop()', 'override fun onDestroy()'), /suspendBackupAutomation\(\)/);
  assert.match(section('override fun onResume()', 'override fun onPause()'), /scheduleBackupAutomationProbe/);
  assert.match(section('private fun showActiveWebView(', 'private fun setAccountRecoveryMode('), /suspendBackupAutomation\(\)/);
  assert.match(section('private fun showActiveWebView(', 'private fun setAccountRecoveryMode('), /scheduleBackupAutomationProbe/);
});
