import java.util.Locale

class JSONObject(private val fields: MutableMap<String, String> = mutableMapOf()) {
    fun optString(key: String): String = fields[key].orEmpty()
    fun put(key: String, value: String) { fields[key] = value }
}
class JSONArray(private val items: List<JSONObject>) {
    fun length(): Int = items.size
    fun optJSONObject(index: Int): JSONObject? = items.getOrNull(index)
}
class Staged(private val items: Map<String, JSONObject>) {
    fun keys() = items.keys.iterator()
    fun optJSONObject(key: String) = items[key]
}
class Prefs {
    val values = mutableMapOf<String, Any>()
    fun getString(key: String, default: String?): String? = values[key] as? String ?: default
    fun edit() = Editor(this)
    class Editor(private val prefs: Prefs) {
        private val changes = mutableMapOf<String, Any?>()
        fun putString(key: String, value: String) = apply { changes[key] = value }
        fun putInt(key: String, value: Int) = apply { changes[key] = value }
        fun putLong(key: String, value: Long) = apply { changes[key] = value }
        fun remove(key: String) = apply { changes[key] = null }
        fun apply() { changes.forEach { (key, value) -> if (value == null) prefs.values.remove(key) else prefs.values[key] = value } }
    }
}
class Fixture {
    data class CredentialRow(val email: String, val password: String, val twoFa: String, val recoveryEmail: String = "", val appPassword: String = "")
    val PREFS = "prefs"
    val MODE_PRIVATE = 0
    val KEY_PASSWORD_CURRENT = "password"
    val KEY_TWO_FA_LINK = "link"
    val KEY_TOTP_SECRET = "secret"
    val KEY_TOTP_OWNER = "owner"
    val KEY_TOTP_LABEL = "label"
    val KEY_TOTP_ALGORITHM = "algorithm"
    val KEY_TOTP_DIGITS = "digits"
    val KEY_TOTP_PERIOD = "period"
    val KEY_RECOVERY_EMAIL_VALUE = "recovery"
    val prefs = Prefs()
    val staged = mutableMapOf<String, JSONObject>()
    val accounts = mutableListOf<JSONObject>()
    var passwordAutomationCurrent = ""
    var authenticatorSecret = ""
    var authenticatorLabel = ""
    var authenticatorAlgorithm = "SHA1"
    var authenticatorDigits = 6
    var authenticatorPeriod = 30L
    var authenticatorOtpauthUri = ""
    var recoveryEmailValue = ""
    fun getSharedPreferences(name: String, mode: Int) = prefs
    fun extractBase32Secret(value: String): String? = value.takeIf { it.isNotBlank() }
    fun formatSavedAuthenticatorKey(value: String) = value.replace("\\s".toRegex(), "").uppercase(Locale.US)
    fun stagedSignInCredentials(account: String) = staged[account.lowercase(Locale.US)]
    fun loadStagedSignInCredentials() = Staged(staged)
    fun loadAuthenticatorAccounts() = JSONArray(accounts)
    fun saveRecoveryTarget(account: String, target: String) = Unit
    fun saveStagedSignInCredentials(row: CredentialRow) {
        val item = staged.getOrPut(row.email.lowercase(Locale.US)) { JSONObject() }
        item.put("account", row.email.lowercase(Locale.US))
        if (row.password.isNotBlank()) item.put("password", row.password)
        if (row.twoFa.isNotBlank()) {
            item.put("twoFa", row.twoFa)
            item.put("secret", row.twoFa)
        }
    }
    fun seed(secret: String, owner: String?) {
        prefs.edit().putString(KEY_TWO_FA_LINK, secret).putString(KEY_TOTP_SECRET, secret).apply()
        if (owner != null) prefs.edit().putString(KEY_TOTP_OWNER, owner).apply()
        authenticatorSecret = secret
    }
    fun import(email: String, secret: String = "") = saveCredentialRow(CredentialRow(email, "password", secret))
    fun key() = prefs.getString(KEY_TWO_FA_LINK, "").orEmpty()
    fun owner() = prefs.getString(KEY_TOTP_OWNER, null)
    /* INSERT_PRODUCTION_METHOD */
}
fun main() {
    val a = "a@example.com"
    val b = "b@example.com"
    val first = "ABCDEFGHIJKLMNOP"
    val second = "QRSTUVWX234567AB"
    val f = Fixture()
    f.import(a, first)
    check(f.owner() == a && f.key() == first)
    f.import(b)
    check(f.owner() == null && f.key() == "" && f.authenticatorSecret == "")
    check(f.staged[a]?.optString("twoFa") == first && f.staged[b]?.optString("twoFa") == "")
    f.import(b, second)
    f.import("B@EXAMPLE.COM")
    check(f.owner() == b && f.key() == second && f.staged[b]?.optString("twoFa") == second)
    val manual = Fixture()
    manual.seed(first, "")
    manual.import(a)
    check(manual.key() == first && manual.owner() == a && manual.staged[a]?.optString("twoFa") == first)
    manual.import(b)
    check(manual.key() == "" && manual.owner() == null && manual.staged[a]?.optString("twoFa") == first)
    val stagedLegacy = Fixture()
    stagedLegacy.seed(first, null)
    stagedLegacy.staged[a] = JSONObject(mutableMapOf("twoFa" to first))
    stagedLegacy.import(a)
    check(stagedLegacy.key() == first && stagedLegacy.owner() == a)
    val loggedLegacy = Fixture()
    loggedLegacy.seed(first, null)
    loggedLegacy.accounts.add(JSONObject(mutableMapOf("account" to a, "secret" to first)))
    loggedLegacy.import(a)
    check(loggedLegacy.key() == first && loggedLegacy.owner() == a)
    val unknownLegacy = Fixture()
    unknownLegacy.seed(first, null)
    unknownLegacy.staged[a] = JSONObject(mutableMapOf("twoFa" to first))
    unknownLegacy.import(b)
    check(unknownLegacy.key() == "" && unknownLegacy.owner() == null)
    val unassociatedLegacy = Fixture()
    unassociatedLegacy.seed(first, null)
    unassociatedLegacy.import(a)
    check(unassociatedLegacy.key() == first && unassociatedLegacy.owner() == a &&
        unassociatedLegacy.staged[a]?.optString("twoFa") == first)
    println("Owner cases passed")
}
