const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const projectSource = path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt');
const source = fs.readFileSync(process.env.DEVICES_SOURCE || (fs.existsSync(projectSource) ? projectSource : path.join(__dirname, 'MainActivity.kt')), 'utf8');
const section = (start, end) => {
  const a = source.indexOf(start);
  const b = source.indexOf(end, a + start.length);
  assert.ok(a >= 0 && b > a, `Missing section ${start}`);
  return source.slice(a, b);
};
const devices = section('private fun startDevicesAutomation(', 'private fun startBackupAutomation(');
const poll = section('private fun pollDevicesAutomation(', 'private fun startBackupAutomation(');
const verifier = section('private fun injectGoogleVerification(', 'private fun installInspectMode(');
const scriptOf = text => {
  const match = text.match(/val script = """([\s\S]*?)"""\.trimIndent\(\)/);
  assert.ok(match, 'Missing JavaScript probe');
  return match[1];
};
const destination = source.match(/private const val DEVICES_URL = "([^"]+)"/)[1];

function pageProbe({ href = destination, expected = destination, origin = 200, previous = 0,
  state = 'complete', body = 'Recovery email', inputs = [] } = {}) {
  const script = scriptOf(poll)
    .replaceAll('${JSONObject.quote(url)}', JSON.stringify(expected))
    .replaceAll('${devicesAutomationPreviousDocumentOrigin ?: 0.0}', String(previous));
  return vm.runInNewContext(script, {
    location: { href }, performance: { timeOrigin: origin },
    document: { readyState: state, body: { innerText: body }, querySelectorAll: () => inputs },
    getComputedStyle: () => ({ display: 'block', visibility: 'visible' }),
  });
}

function verificationProbe({ device = true, host = 'myaccount.google.com', scheme = 'https:', port = '',
  body = 'Account overview', inputs = [] } = {}) {
  const script = scriptOf(verifier)
    .replaceAll('${devicesRun != null}', String(device))
    .replaceAll('$current', JSON.stringify('unused-password'));
  let clicks = 0;
  const document = {
    readyState: 'complete', body: { innerText: body },
    querySelectorAll: selector => selector.includes('password') ? inputs : [],
    querySelector: () => ({ click: () => { clicks++; } }),
  };
  const result = vm.runInNewContext(script, {
    location: { protocol: scheme, hostname: host, port }, document,
    getComputedStyle: () => ({ display: 'block', visibility: 'visible', opacity: '1' }),
  });
  return { result, clicks };
}

const visibleInput = {
  type: 'password', getBoundingClientRect: () => ({ width: 100, height: 20 }),
  getAttribute: () => '', parentElement: null,
};

test('configured Recovery destination uses the trusted recovery options URL', () => {
  const url = new URL(destination);
  assert.equal(destination, 'https://gds.google.com/web/recoveryoptions?cardIndex=0&hl=en&authuser=0&tda=CAA');
  assert.equal(url.origin, 'https://gds.google.com');
  assert.equal(url.pathname, '/web/recoveryoptions');
  assert.equal(url.username, '');
  assert.equal(url.password, '');
  const destinationCheck = section('private fun isDevicesDestination(', 'private fun failDevicesDocument(');
  assert.match(destinationCheck, /\/web\/recoveryoptions/);
});

test('Recovery follows Creation Time in the pipeline and keeps lifecycle routing', () => {
  assert.ok(/"creation_time",\s*"recovery_set",\s*"ads"/.test(source));
  assert.ok(/"recovery_set"\s*->\s*devicesAutomationEnabled/.test(source), 'Recovery must use the Devices enable flag');
  assert.ok(/"recovery_set"\s*->\s*startDevicesAutomation\(view\)/.test(source), 'Recovery must start the Devices lifecycle');
  assert.ok(/markStageCompleted\("recovery_set",\s*view,\s*account\)/.test(devices), 'Completion must use the Recovery stage ID');
  assert.ok(/startNextConfiguredStage\(view,\s*"recovery_set"/.test(devices), 'Handoff must use the Recovery stage ID');
  assert.match(devices, /!automationMasterEnabled \|\| !devicesAutomationEnabled/);
});

test('Recovery follows Creation Time in settings and keeps passive preflight', () => {
  assert.match(source, /"Password", "Creation Time", "Recovery", "Ads"/);
  assert.doesNotMatch(section('private fun startDevicesAutomation(', 'private fun pollDevicesAutomation('), /\.click\s*\(/);
});

test('Recovery requires a separate, default-off opt-in', () => {
  const preference = source.match(/private const val KEY_DEVICES_AUTOMATION_ENABLED = "([^"]+)"/);
  assert.equal(preference?.[1], 'recovery_stage_enabled');
  assert.ok(/devicesAutomationEnabled = prefs\.getBoolean\(KEY_DEVICES_AUTOMATION_ENABLED, false\)/.test(source),
    'Recovery must load its own preference with a default of false');
  const legacyKeys = [...source.matchAll(/\b(?:const\s+)?val\s+(\w+)\s*=\s*"devices_automation_enabled"/g)].map(match => match[1]);
  assert.ok(!/\bgetBoolean\s*\(\s*"devices_automation_enabled"/.test(source), 'Legacy Devices opt-in must not be read');
  for (const key of legacyKeys) {
    assert.ok(!new RegExp(`\\bgetBoolean\\s*\\(\\s*${key}\\b`).test(source), 'Legacy Devices opt-in must not be read');
  }
  const toggle = section('addSettingRow("Recovery"', 'addSettingRow("Password"');
  assert.match(toggle, /devicesAutomationEnabled = checked/);
  assert.match(toggle, /\.putBoolean\(KEY_DEVICES_AUTOMATION_ENABLED, checked\)/);
  assert.match(toggle, /clearStageCompleted\("recovery_set",\s*account\)/);
  assert.match(toggle, /startNextConfiguredStage\(owner,\s*"recovery_set"/);
});

test('page probe rejects stale reload, wrong URL, loading, verification and errors', () => {
  assert.equal(pageProbe({ previous: 100, origin: 100 }), 'waiting');
  assert.equal(pageProbe({ previous: 100, origin: 101 }), 'ready:101');
  assert.equal(pageProbe({ href: destination + '#spa' }), 'waiting');
  assert.equal(pageProbe({ href: destination + (destination.includes('?') ? '&' : '?') + 'changed=1' }), 'waiting');
  assert.equal(pageProbe({ state: 'loading' }), 'waiting');
  assert.equal(pageProbe({ body: '' }), 'waiting');
  assert.equal(pageProbe({ body: 'Verify your identity' }), 'verification');
  assert.equal(pageProbe({ inputs: [visibleInput] }), 'verification');
  assert.equal(pageProbe({ body: 'This site can’t be reached'.replace('’', "'") }), 'failed');
});

test('Recovery stage verification never clicks and rejects unsafe origins or modes', () => {
  assert.deepEqual(verificationProbe({ body: 'Verify your identity' }), { result: 'devices_verification', clicks: 0 });
  assert.deepEqual(verificationProbe({ inputs: [visibleInput] }), { result: 'devices_verification', clicks: 0 });
  assert.equal(verificationProbe({ body: '' }).result, 'waiting');
  assert.equal(verificationProbe({ host: 'myaccount.google.com.evil.test' }).result, 'waiting');
  assert.equal(verificationProbe({ scheme: 'http:' }).result, 'waiting');
  assert.equal(verificationProbe({ port: '8443' }).result, 'waiting');
  assert.equal(verificationProbe({ device: false }).result, 'none');
});

test('source guards disable, ownership, stale callbacks, SPA, retry and pause', () => {
  const toggle = section('addSettingRow("Recovery"', 'addSettingRow("Password"');
  assert.match(toggle, /googleVerificationGeneration\+\+/);
  assert.match(toggle, /googleVerificationActive \|\| googleVerificationCheckPending \|\| devicesAutomationAwaitingVerification/);
  assert.match(toggle, /googleVerificationCheckPending = true/);
  assert.match(toggle, /injectGoogleVerification\(owner\)/);
  assert.match(toggle, /isSecurityStageOwner\(owner\)/);
  const started = section('override fun onPageStarted(', '// Invalidate the old document');
  assert.doesNotMatch(started, /evaluateJavascript/);
  assert.match(started, /sameDestination && previousOrigin == null/);
  assert.match(devices, /devicesAutomationDocumentOrigin = origin/);
  assert.ok(devices.indexOf('pollDevicesInitialNavigation(view, devicesAutomationGeneration)') < devices.indexOf('view.loadUrl(DEVICES_URL)'));
  assert.match(poll, /generation == devicesAutomationGeneration/);
  assert.match(poll, /documentGeneration == devicesAutomationDocumentGeneration/);
  assert.match(poll, /isSecurityStageOwner\(view\)/);
  assert.match(poll, /minOf\(500L, remaining\)/);
  assert.match(devices, /(?:Devices|Recovery) could not load safely/);
  assert.match(devices, /postDelayed\(watchdog, 30_000L\)/);
  assert.match(verifier, /devicesUrl != view.url.orEmpty\(\)/);
  assert.match(verifier, /devicesAutomationAwaitingVerification && !devicesAutomationFailed/);
  assert.doesNotMatch(verifier, /loadUrl\(DEVICES_URL\)/);
  assert.equal((source.match(/view\.loadUrl\(DEVICES_URL\)/g) || []).length, 1);
  assert.match(source, /view\.url\.orEmpty\(\) == pageUrl && isSecurityStageOwner\(view\)/);
  assert.match(source, /override fun doUpdateVisitedHistory[\s\S]*?devicesAutomationDocumentGeneration\+\+/);
  assert.match(source, /view\.url == pageUrl && !devicesAutomationFailed\) \{\s*if \(devicesAutomationFinishedAt == 0L\)[\s\S]*?if \(isDevicesDestination\(pageUrl\)\) scheduleDevicesAutomation/);
  assert.match(source, /override fun onPause\(\)[\s\S]*?devicesAutomationReadyAt = 0L/);
  assert.match(source, /devicesAutomationFailed &&\s*isSecurityStageOwner\(webView\)[\s\S]*?startDevicesAutomation\(webView\)/);
});

// This model exercises event ordering; the JavaScript and source assertions above
// exercise production text, but a model is not an Android WebView integration test.
class NavigationModel {
  constructor() { this.run = 1; this.doc = 0; this.enabled = true; this.active = true; this.url = ''; this.readyAt = 0; this.verified = false; this.failed = false; this.advanced = false; }
  navigate(url) { this.url = url; this.doc++; this.readyAt = 0; this.failed = false; return [this.run, this.doc, url]; }
  current(token) { return this.enabled && this.active && token[0] === this.run && token[1] === this.doc && token[2] === this.url; }
  probe(token, now, status, paused = false) {
    if (!this.current(token) || this.failed) return;
    if (paused || status !== 'ready') { this.readyAt = 0; return; }
    if (!this.readyAt) this.readyAt = now;
    if (now - this.readyAt >= 3000) this.advanced = true;
  }
  challenge() { this.verified = true; this.readyAt = 0; }
  resume(url) { if (this.verified && new URL(url).origin === 'https://myaccount.google.com') { this.verified = false; return this.navigate(destination); } return null; }
  disable() { this.enabled = false; this.active = false; this.verified = false; this.run++; }
  retry() { this.run++; this.failed = false; return this.navigate(destination); }
}

test('simulated navigation, verification redirect, disable, reload, SPA and timer reset', () => {
  const m = new NavigationModel();
  const first = m.navigate(destination);
  m.probe(first, 100, 'ready');
  m.probe(first, 2000, 'ready', true);
  m.probe(first, 2500, 'ready');
  m.probe(first, 5499, 'ready');
  assert.equal(m.advanced, false);
  m.challenge();
  const challenge = m.navigate('https://accounts.google.com/challenge/password');
  assert.equal(m.resume('https://accounts.google.com/signin'), null);
  const resumed = m.resume('https://myaccount.google.com/security');
  assert.ok(resumed);
  m.probe(challenge, 10000, 'ready');
  m.probe(first, 10000, 'ready');
  assert.equal(m.advanced, false);
  const reload = m.navigate(destination);
  m.probe(resumed, 11000, 'ready');
  const spa = m.navigate(destination + '#route');
  m.probe(reload, 12000, 'ready');
  m.probe(spa, 13000, 'ready');
  m.probe(spa, 16000, 'ready');
  assert.equal(m.advanced, true);
  const disabled = new NavigationModel();
  const token = disabled.navigate(destination);
  disabled.challenge();
  disabled.disable();
  disabled.probe(token, 10000, 'ready');
  assert.equal(disabled.verified, false);
  assert.equal(disabled.advanced, false);
});

test('simulated load failure blocks success until a fresh manual retry', () => {
  const m = new NavigationModel();
  const failed = m.navigate(destination);
  m.failed = true;
  m.probe(failed, 1000, 'ready');
  m.probe(failed, 5000, 'ready');
  assert.equal(m.advanced, false);
  const retry = m.retry();
  m.probe(failed, 6000, 'ready');
  m.probe(retry, 7000, 'ready');
  m.probe(retry, 10000, 'ready');
  assert.equal(m.advanced, true);
});
