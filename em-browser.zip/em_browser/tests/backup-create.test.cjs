const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const start = source.indexOf('private fun probeBackupAutomation(');
const end = source.indexOf('private fun clearPasswordAutomationState(', start);
const probe = source.slice(start, end);
const match = probe.match(/val script = """([\s\S]*?)"""\.trimIndent\(\)/);
assert.ok(match);

function fixture(options = {}) {
  let clicks = 0;
  const base = {
    nodeType: 1, parentElement: null, hidden: false,
    getBoundingClientRect: () => ({ width: 100, height: 40 }),
    getAttribute: () => ''
  };
  const avatar = { ...base, getAttribute: name => name === 'aria-label' ? 'Google Account: user@example.com' : '' };
  const button = { ...base, innerText: 'Get backup codes', disabled: false, click: () => clicks++ };
  const container = { ...base, innerText: '', querySelectorAll: selector => selector.includes('SDMsce') ? (options.codeNodes || []) : [] };
  const document = {
    visibilityState: options.visibility || 'visible', readyState: 'complete',
    querySelectorAll: selector => selector === '[aria-label],[title]' ? (options.noAvatar ? [] : [avatar]) :
      selector === 'div.Hm1X5.JH1xTd' ? [container] : selector.includes('button.AeBiU') ? [button] : []
  };
  const window = {};
  window.top = window;
  const context = { document, window, URL, location: { href: options.url || 'https://myaccount.google.com/two-step-verification/backup-codes?hl=en' },
    getComputedStyle: () => ({ display: 'block', visibility: 'visible', opacity: '1' }) };
  const script = match[1].replaceAll("${'$'}", '$').replace('$knownAccountJson', JSON.stringify(options.account ?? 'user@example.com'));
  return { run: () => vm.runInNewContext(script, context), clicks: () => clicks, button };
}

test('creates backup codes only once for the matching account', () => {
  const f = fixture();
  f.run(); f.run();
  assert.equal(f.clicks(), 1);
});

test('does not click for a different or unidentified account, wrong page or hidden document', () => {
  for (const opts of [{ account: 'other@example.com' }, { account: '' }, { noAvatar: true }, { url: 'https://example.com/two-step-verification/backup-codes' }, { visibility: 'hidden' }]) {
    const f = fixture(opts); f.run(); assert.equal(f.clicks(), 0);
  }
});

test('does not create a new set when any existing code is visible', () => {
  const code = { nodeType: 1, parentElement: null, getBoundingClientRect: () => ({ width: 50, height: 20 }) };
  const f = fixture({ codeNodes: [code] }); f.run(); assert.equal(f.clicks(), 0);
});

test('disabled and differently named buttons are not clicked', () => {
  const a = fixture(); a.button.disabled = true; a.run(); assert.equal(a.clicks(), 0);
  const b = fixture(); b.button.innerText = 'Get new codes'; b.run(); assert.equal(b.clicks(), 0);
});

test('navigation omits session token and existing secure recording remains intact', () => {
  assert.match(source, /view\.loadUrl\("https:\/\/myaccount\.google\.com\/two-step-verification\/backup-codes\?hl=en"\)/);
  assert.match(probe, /saveAccountBackupCodes\(account, codes\)/);
  assert.match(probe, /BACKUP_AUTOMATION_SETTLE_MS/);
  assert.match(probe, /backupAutomationDocumentGeneration != documentGeneration/);
});
