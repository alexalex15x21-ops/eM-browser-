// Source-level regression checks, not Kotlin execution or Android integration tests.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
function section(startMarker, endMarker) {
  const start = source.indexOf(startMarker);
  assert.notEqual(start, -1, `missing ${startMarker}`);
  const end = source.indexOf(endMarker, start + startMarker.length);
  assert.ok(end > start, `missing ${endMarker} after ${startMarker}`);
  return source.slice(start, end);
}

test('shared formatter specifies exactly ten columns in the required order', () => {
  const formatter = section('private fun formatAccountRow(', 'private fun showSavedAuthenticatorAccountsDialog()');
  const list = formatter.match(/=\s*listOf\(([\s\S]*?)\)\.joinToString\("\\t"\)/);
  assert.ok(list, 'formatter must join a fixed column list using tabs');
  const columns = list[1].trim().split(/,\s*\n/).map(column => column.trim());
  assert.deepEqual(columns, [
    'item.optString("account")', 'item.optString("password")',
    'formatSavedAuthenticatorKey(item.optString("twoFa").ifBlank { item.optString("secret") })',
    '""', 'item.optString("recoveryEmail")',
    'if (includeBackupCodes) readAccountBackupCodes(item).joinToString(" ") else ""',
    'accountCreationTime(item)', 'item.optString("ads")',
    'item.optString("youtubePremium")', 'item.optString("appPassword")',
  ]);
  assert.match(formatter, /includeBackupCodes:\s*Boolean\s*=\s*true/);
});

test('display, row clipboard and Copy All use the same formatter', () => {
  const dialog = section('private fun showSavedAuthenticatorAccountsDialog()', 'private fun showRecoveryEmailInfoDialog()');
  assert.match(dialog, /val valueToCopy = formatAccountRow\(item\)/);
  assert.match(dialog, /text = valueToCopy/);
  assert.match(dialog, /copyToClipboard\("Account",\s*valueToCopy\)/);
  assert.match(dialog, /append\(formatAccountRow\(item\)\)\.append\('\\n'\)/);
  assert.match(dialog, /trimEnd\('\\n'\)/);
  assert.match(dialog, /copyToClipboard\("Accounts",\s*all\)/);
});

test('private account log retains ten-column header but never emits decrypted backup codes', () => {
  const log = section('private fun saveAuthenticatorLogFile(', 'private fun accountCreationTime(');
  const header = log.match(/out\.append\("([^"\n]*)\\n"\)/);
  assert.ok(header, 'missing log header');
  assert.deepEqual(header[1].split('\\t'), ['Gmail', 'Password', 'Authenticator', '', 'Recovery Email',
    'Backup Codes', 'Creation Time', 'Ads', 'YouTube Premium', 'App Password']);
  assert.match(log, /out\.append\(formatAccountRow\(item,\s*false\)\)/);
  assert.doesNotMatch(log, /readAccountBackupCodes|backupCodesEncrypted/);
  assert.match(log, /file\.writeText\(out\.toString\(\),\s*Charsets\.UTF_8\)/);
});

test('ten-column parser preserves password, recovery and app password independently', () => {
  const parser = section('private fun parseCredentialRow(', 'private fun recoveryTargetForAccount(');
  const explicit = parser.slice(parser.indexOf("if (raw.contains('\\t'))"), parser.indexOf('while (columns.isNotEmpty()'));
  assert.match(explicit, /raw\.trimEnd\('\\r', '\\n'\)\.split\('\\t'\)/);
  assert.match(explicit, /columns\.size == 10 && columns\[3\]\.isEmpty\(\)/);
  assert.match(explicit, /columns\[0\]\.trim\(\)\.lowercase\(Locale\.US\)/);
  assert.match(explicit, /EMAIL_ADDRESS\.matcher\(account\)\.matches\(\)/);
  assert.match(explicit, /CredentialRow\(\s*account,\s*columns\[1\],\s*extractBase32Secret\(columns\[2\]\)\.orEmpty\(\),\s*columns\[4\]\.trim\(\)\.lowercase\(Locale\.US\),\s*columns\[9\]\s*\)/);
  assert.doesNotMatch(explicit, /columns\[[5-8]\]/, 'backup codes and metadata must not become credentials');
});

test('recovery updates are account-scoped, persisted and marked changed only when requested', () => {
  const update = section('private fun updateSavedAccountRecovery(', 'private fun loadAddress(');
  assert.match(update, /recordChange: Boolean = false/);
  assert.match(update, /accountOverride\.orEmpty\(\)\.trim\(\)\.lowercase\(Locale\.US\)/);
  assert.match(update, /EMAIL_ADDRESS\.matcher\(account\)\.matches\(\)\) return/);
  assert.match(update, /optString\("account"\)\.orEmpty\(\)\.equals\(account, true\)/);
  assert.match(update, /if \(index == null && !recordChange\) return/);
  assert.match(update, /stagedSignInCredentials\(account\)/);
  assert.match(update, /item\.put\("recoveryEmail", accountEmail\)/);
  assert.match(update, /if \(recordChange\) item\.put\("recoveryEmailChangedAt", System\.currentTimeMillis\(\)\)/);
  assert.match(update, /if \(index != null\) accounts\.put\(index, item\) else accounts\.put\(item\)/);
  assert.match(update, /saveAuthenticatorAccounts\(accounts\)[\s\S]*saveAuthenticatorLogFile\(accounts\)/);
  const changed = section('private fun isAccountChangeRecord(', 'private fun changedAccountRecords(');
  assert.match(changed, /item\.optLong\("recoveryEmailChangedAt", 0L\) > 0L/);
});

test('loading and saving an authenticator do not explicitly erase recovery', () => {
  for (const text of [section('private fun saveAuthenticator(', 'private fun stagePendingAuthenticatorChange('),
    section('private fun loadAuthenticatorAccounts()', 'private fun saveAuthenticatorAccounts(')]) {
    assert.doesNotMatch(text, /put\(\s*"recoveryEmail"\s*,\s*""\s*\)|remove\(\s*"recoveryEmail"\s*\)/);
  }
});

test('authenticator save preserves existing recovery when staged credentials supply the base item', () => {
  const save = section('private fun saveAuthenticator(', 'private fun stagePendingAuthenticatorChange(');
  // An unchanged saved account can have recovery while staged credentials do not.
  // Require an explicit merge when choosing a staged base over an existing item.
  assert.match(save, /existingItem\??\.optString\("recoveryEmail"\)/,
    'existing recovery must be merged when the staged item is selected');
});
