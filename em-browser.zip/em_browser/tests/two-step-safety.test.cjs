const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
function scriptIn(method, variable = 'script') {
  const start = source.indexOf(`private fun ${method}(`);
  assert.notEqual(start, -1, `missing ${method}`);
  const end = source.indexOf('\n    private fun ', start + 1);
  const section = source.slice(start, end < 0 ? undefined : end);
  const match = section.match(new RegExp(`val ${variable} = """([\\s\\S]*?)"""\\.trimIndent\\(\\)`));
  assert.ok(match, `missing ${variable} in ${method}`);
  return match[1];
}
const autofill = scriptIn('injectCredentialAutofill');
const twoStep = scriptIn('injectTwoStepAutomation');
const skipClick = scriptIn('injectTwoStepAutomation', 'skipClickScript');

// A small DOM fixture, not a WebView or a model of the production logic.
class Element {
  constructor({tag = 'div', text = '', label = '', id = '', name = '', type = '', hidden = false} = {}) {
    Object.assign(this, {tag, innerText: text, textContent: text, label, id, name, type, hidden,
      parentElement: null, isConnected: true, disabled: false, readOnly: false, clicks: 0});
    this.listeners = {};
  }
  getBoundingClientRect() { return {width: this.hidden ? 0 : 100, height: this.hidden ? 0 : 20}; }
  getAttribute(name) { return name === 'aria-label' ? this.label : name === 'name' ? this.name : ''; }
  matches(selector) {
    if (selector === ':disabled') return this.disabled;
    if (selector === '[tabindex]') return false;
    return selector.split(',').some(part => part.trim() === this.tag ||
      (this.tag === 'button' && part.trim() === '[role="button"]'));
  }
  closest(selector) {
    for (let el = this; el; el = el.parentElement) if (el.matches(selector)) return el;
    return null;
  }
  querySelector() { return null; }
  addEventListener(name, callback) { (this.listeners[name] ||= []).push(callback); }
  removeEventListener(name, callback) { this.listeners[name] = (this.listeners[name] || []).filter(fn => fn !== callback); }
  dispatchEvent(event) { for (const callback of this.listeners[event.type] || []) callback(event); }
  focus() {}
  scrollIntoView() {}
  click() { this.clicks++; }
}
class Input extends Element {
  constructor({value = '', id = 'totpPin', name = 'totpPin', label = 'Enter code', ...rest} = {}) {
    super({tag: 'input', type: 'text', id, name, label, ...rest});
    this.value = value;
  }
  get value() { return this._value; }
  set value(value) { this._value = value; }
}

function page({url = 'https://accounts.google.com/challenge/totp', subframe = false,
  prompt = 'Get a verification code from the Google Authenticator app', initial = '',
  input = {}, buttons = ['Next']} = {}) {
  const location = new URL(url);
  const clock = {now: 1000};
  const requests = [];
  const intervals = [];
  const body = new Element({tag: 'body'});
  const promptElement = new Element({text: prompt});
  promptElement.parentElement = body;
  const document = {
    body, documentElement: body,
    inputs: [new Input({value: initial, ...input})],
    buttons: buttons.map(text => new Element({tag: 'button', text})),
    querySelector(selector) {
      if (selector === 'h1.cdaFgf') return null;
      return null;
    },
    querySelectorAll(selector) {
      if (selector === 'input') return this.inputs;
      if (selector === 'input[type="password"], input[name="Passwd"]') return [];
      if (selector === 'input[type="password"]' || selector === 'h1') return [];
      if (selector === 'body *') return [promptElement, ...this.buttons];
      if (selector.includes('button')) return this.buttons;
      return [];
    },
    createTreeWalker() {
      const nodes = [promptElement, ...this.buttons].map(el => ({parentElement: el, nodeValue: el.innerText}));
      let index = 0;
      return {currentNode: null, nextNode() { return this.currentNode = nodes[index++] || null; }};
    },
  };
  const window = {
    __emCredentialRequest(operation) {
      return new Promise(resolve => requests.push({operation, resolve}));
    },
  };
  window.top = subframe ? {} : window;
  const style = el => ({display: el.hidden ? 'none' : 'block', visibility: 'visible', opacity: '1'});
  window.getComputedStyle = style;
  class Clock extends Date { static now() { return clock.now; } }
  const context = vm.createContext({window, document, location, HTMLInputElement: Input, HTMLElement: Element,
    getComputedStyle: style, NodeFilter: {SHOW_TEXT: 4}, Date: Clock,
    Event: class { constructor(type) { this.type = type; } },
    MutationObserver: class { observe() {} }, setInterval: fn => intervals.push(fn)});
  const runTwoStep = (stage = 'direct_click') => vm.runInContext(
    twoStep.replaceAll('${twoStepAutomationStage}', stage), context);
  return {
    context, window, document, location, clock, requests, promptElement,
    get input() { return document.inputs[0]; },
    get buttons() { return document.buttons; },
    inject() { return vm.runInContext(autofill, context); },
    runTwoStep,
    runSkipClick() { return vm.runInContext(skipClick, context); },
    tick() { assert.equal(intervals.length, 1); intervals[0](); },
    type(value) { this.input.value = value; this.input.dispatchEvent({type: 'input', isTrusted: true}); },
    remount(value = '') {
      this.input.isConnected = false;
      document.inputs = [new Input({value})];
    },
    async reply(index, value = {code: '112233', expiresAt: 30000}) {
      assert.equal(requests[index].operation, 'totp');
      requests[index].resolve(typeof value === 'string' ? value : JSON.stringify(value));
      await new Promise(resolve => setImmediate(resolve));
    },
  };
}

test('only top-level exact HTTPS Google origins can fill and submit', async () => {
  for (const url of [
    'https://accounts.google.com/challenge/totp',
    'https://myaccount.google.com/security/verify',
    'https://ACCOUNTS.GOOGLE.COM:443/challenge/totp',
    'https://myaccount.google.com:443/security/verify',
  ]) {
    const p = page({url});
    p.inject();
    assert.equal(p.requests.length, 1, url);
    await p.reply(0);
    assert.equal(p.input.value, '112233', url);
    assert.equal(p.runTwoStep(), 'code_submitted', url);
    assert.equal(p.buttons[0].clicks, 1, url);
  }
  for (const options of [
    {url: 'http://accounts.google.com/challenge/totp'},
    {url: 'http://myaccount.google.com/security/verify'},
    {url: 'https://accounts.google.com:8443/challenge/totp'},
    {url: 'https://myaccount.google.com:80/security/verify'},
    {url: 'https://accounts.google.com.evil.test/challenge/totp'},
    {url: 'https://evil.test/accounts.google.com'},
    {url: 'https://accounts.google.com@evil.test/challenge/totp'},
    {url: 'https://sub.accounts.google.com/challenge/totp'},
    {url: 'https://google.com/challenge/totp'},
    {subframe: true},
  ]) {
    const p = page(options);
    p.inject();
    assert.equal(p.window.__emAutofillHooked, undefined, JSON.stringify(options));
    assert.equal(p.requests.length, 0, JSON.stringify(options));
    assert.equal(p.runTwoStep(), 'untrusted', JSON.stringify(options));
    assert.equal(p.buttons[0].clicks, 0, JSON.stringify(options));
  }
});

test('an app-filled code is submitted once per period, including repeated polling', async () => {
  const p = page();
  p.inject();
  p.inject();
  assert.equal(p.requests.length, 1);
  await p.reply(0);
  assert.equal(p.runTwoStep(), 'code_submitted');
  assert.equal(p.runTwoStep(), 'code_filled');
  p.tick();
  await p.reply(1);
  assert.equal(p.runTwoStep(), 'code_filled');
  assert.equal(p.buttons[0].clicks, 1);
  p.clock.now = 30000;
  assert.equal(p.runTwoStep(), 'wait');
  p.tick();
  // A TOTP can coincidentally be identical in consecutive periods.
  await p.reply(2, {code: '112233', expiresAt: 60000});
  assert.equal(p.runTwoStep(), 'code_submitted');
  assert.equal(p.runTwoStep(), 'code_filled');
  assert.equal(p.buttons[0].clicks, 2);
});

test('remounting the same challenge must not submit the same period twice', async () => {
  const p = page();
  p.inject();
  await p.reply(0);
  assert.equal(p.runTwoStep(), 'code_submitted');
  const button = p.buttons[0];
  p.remount();
  p.tick();
  await p.reply(1);
  p.runTwoStep();
  assert.equal(button.clicks, 1, 'a replacement input must not reset the period submission guard');
});

test('manual values, including clearing an initial value, are neither overwritten nor submitted', () => {
  const p = page({initial: '987654'});
  p.inject();
  assert.equal(p.requests.length, 0);
  assert.equal(p.runTwoStep(), 'wait');
  p.type('');
  p.tick();
  assert.equal(p.requests.length, 0);
  assert.equal(p.input.value, '');
  assert.equal(p.runTwoStep(), 'wait');
  assert.equal(p.buttons[0].clicks, 0);
});

test('typing and clearing while a reply is pending invalidates that reply and future autofill', async () => {
  const p = page();
  p.inject();
  p.type('987654');
  p.type('');
  await p.reply(0);
  assert.equal(p.input.value, '');
  p.tick();
  assert.equal(p.requests.length, 1);
  assert.equal(p.runTwoStep(), 'wait');
  assert.equal(p.buttons[0].clicks, 0);
});

test('manual editing or clearing an app-filled code prevents submission and refilling', async () => {
  for (const edited of ['987654', '112233', '']) {
    const p = page();
    p.inject();
    await p.reply(0);
    p.type(edited);
    assert.equal(p.runTwoStep(), 'wait');
    p.tick();
    assert.equal(p.requests.length, 1);
    assert.equal(p.input.value, edited);
    assert.equal(p.buttons[0].clicks, 0);
  }
});

test('a manually cleared challenge stays manual after its input is remounted', async () => {
  const p = page();
  p.inject();
  await p.reply(0);
  p.type('');
  p.remount();
  p.tick();
  assert.equal(p.requests.length, 1);
  assert.equal(p.input.value, '');
  assert.equal(p.runTwoStep(), 'wait');
  assert.equal(p.buttons[0].clicks, 0);
});

test('backup, recovery and SMS challenges are ignored even with a TOTP-like input', () => {
  for (const options of [
    {prompt: 'Enter a backup code'},
    {prompt: 'Enter a recovery code'},
    {prompt: 'Enter the SMS code'},
    {prompt: 'Enter the code sent to your phone'},
    {input: {id: 'backupCodePin', name: 'backupCodePin', label: 'Enter a backup code'}},
    {input: {id: 'smsPin', name: 'smsPin', label: 'Enter text message code'}},
  ]) {
    const p = page(options);
    p.inject();
    assert.equal(p.requests.length, 0, JSON.stringify(options));
    assert.equal(p.runTwoStep(), 'wait', JSON.stringify(options));
    assert.equal(p.input.value, '', JSON.stringify(options));
    assert.equal(p.buttons[0].clicks, 0, JSON.stringify(options));
  }
});

test('a challenge changing to SMS before an in-flight reply cannot be filled or submitted', async () => {
  const p = page();
  p.inject();
  p.promptElement.innerText = 'Enter the SMS code';
  await p.reply(0);
  assert.equal(p.input.value, '');
  assert.equal(p.runTwoStep(), 'wait');
  assert.equal(p.buttons[0].clicks, 0);
});

test('a filled authenticator code is not submitted after the challenge changes to SMS', async () => {
  const p = page();
  p.inject();
  await p.reply(0);
  p.promptElement.innerText = 'Enter the SMS code';
  assert.equal(p.runTwoStep(), 'wait');
  assert.equal(p.buttons[0].clicks, 0);
});

test('late replies are rejected and readiness is initially withheld on same-origin navigation', async () => {
  for (const suffix of ['?different=1', '#different', '/different']) {
    const p = page();
    p.inject();
    p.location.href += suffix;
    await p.reply(0);
    assert.equal(p.input.value, '', suffix);
    assert.equal(p.runTwoStep(), 'wait', suffix);
    p.tick();
    await p.reply(1);
    assert.equal(p.runTwoStep(), 'code_submitted', suffix);
    assert.equal(p.buttons[0].clicks, 1, suffix);
  }
  const p = page();
  p.inject();
  await p.reply(0);
  p.location.hash = '#new-challenge';
  assert.equal(p.runTwoStep(), 'wait');
  assert.equal(p.buttons[0].clicks, 0);
});

test('a poll must not make a pre-navigation code ready on a new same-origin route', async () => {
  const p = page();
  p.inject();
  await p.reply(0);
  p.location.href = 'https://accounts.google.com/challenge/totp?authuser=1';
  assert.equal(p.runTwoStep(), 'wait');
  p.tick();
  assert.equal(p.requests.length, 2);
  assert.equal(p.runTwoStep(), 'wait', 'the new route has not received a credential reply');
  assert.equal(p.buttons[0].clicks, 0);
});

test('the two-step script rechecks the origin and frame after navigation', async () => {
  const p = page();
  p.inject();
  await p.reply(0);
  p.location.href = 'https://accounts.google.com.evil.test/challenge/totp';
  assert.equal(p.runTwoStep(), 'untrusted');
  p.location.href = 'http://accounts.google.com/challenge/totp';
  assert.equal(p.runTwoStep(), 'untrusted');
  p.location.href = 'https://accounts.google.com:8443/challenge/totp';
  assert.equal(p.runTwoStep(), 'untrusted');
  p.location.href = 'https://accounts.google.com/challenge/totp';
  p.window.top = {};
  assert.equal(p.runTwoStep(), 'untrusted');
  assert.equal(p.buttons[0].clicks, 0);
});

test('expired or malformed replies never fill or submit', async () => {
  for (const reply of [
    'not JSON', {code: '12345', expiresAt: 30000}, {code: '123456', expiresAt: 1000},
    {code: '123456', expiresAt: '30000'}, {code: '123456', expiresAt: 30000.5},
  ]) {
    const p = page();
    p.inject();
    await p.reply(0, reply);
    assert.equal(p.input.value, '', JSON.stringify(reply));
    assert.equal(p.runTwoStep(), 'wait', JSON.stringify(reply));
    assert.equal(p.buttons[0].clicks, 0, JSON.stringify(reply));
  }
  const p = page();
  p.inject();
  await p.reply(0, {code: '12345678', expiresAt: 2000});
  p.clock.now = 2000;
  assert.equal(p.runTwoStep(), 'wait');
  assert.equal(p.buttons[0].clicks, 0);
});

test('a disabled or hidden verification control is not clicked', async () => {
  for (const property of ['disabled', 'hidden']) {
    const p = page();
    p.inject();
    await p.reply(0);
    p.buttons[0][property] = true;
    assert.equal(p.runTwoStep(), 'code_filled', property);
    assert.equal(p.buttons[0].clicks, 0, property);
    p.buttons[0][property] = false;
    assert.equal(p.runTwoStep(), 'code_submitted', property);
    assert.equal(p.buttons[0].clicks, 1, property);
  }
});

test('authenticator setup owns its field, but ordinary Google challenges still fill', async () => {
  const setup = page({url: 'https://myaccount.google.com/two-step-verification/authenticator'});
  setup.window.__emAuthenticatorSetupClickIssued = true;
  setup.inject();
  assert.equal(setup.requests.length, 0);
  assert.equal(setup.runTwoStep(), 'wait');
  const signin = page({url: 'https://accounts.google.com/challenge/totp'});
  signin.window.__emAuthenticatorSetupClickIssued = true;
  signin.inject();
  await signin.reply(0);
  assert.equal(signin.runTwoStep(), 'code_submitted');
});

test('normal Google two-step flow activates Turn On once, then Skip, then recognizes success', () => {
  const p = page({url: 'https://myaccount.google.com/signinoptions/twosv', prompt: '2-Step Verification',
    buttons: ['Turn on 2-Step Verification', 'Cancel', 'Skip']});
  assert.equal(p.runTwoStep(), 'turn_on_dom');
  assert.equal(p.buttons[0].clicks, 1);
  assert.equal(p.runTwoStep(), 'wait');
  assert.equal(p.runTwoStep('confirm'), 'skip_dom');
  assert.equal(p.runSkipClick(), 'clicked');
  assert.equal(p.buttons[1].clicks, 0);
  assert.equal(p.buttons[2].clicks, 1);
  assert.equal(p.runTwoStep('confirm'), 'wait');
  assert.equal(p.runTwoStep('waiting_success'), 'wait');
  p.document.body.innerText = '2-Step Verification is enabled';
  assert.equal(p.runTwoStep('waiting_success'), 'success');
});
