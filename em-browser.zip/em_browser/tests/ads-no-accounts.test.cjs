const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../app/src/main/java/com/em/browser/MainActivity.kt'), 'utf8');
const stage = source.slice(source.indexOf('private fun injectAdsAutomation('), source.indexOf('// ---- YouTube premium stage'));
const script = stage.match(/val script = """([\s\S]*?)"""\.trimIndent\(\)/)[1]
  .replaceAll("${'$'}", '$').replace('${JSONObject.quote(adsAutomationAccount)}', '"user@example.com"');

function run(options = {}) {
  const element = (text = '', hidden = false) => ({ innerText: text, hidden, parentElement: null,
    getBoundingClientRect: () => ({ width: 100, height: 50 }), getAttribute: () => '' });
  const marker = element(options.text || 'You have no accounts', options.hidden);
  const shell = element('Tell us about your business');
  const heading = element('Tell us about your business');
  shell.contains = el => el === heading;
  const avatar = element();
  avatar.getAttribute = key => key === 'aria-label' ? `Google Account: ${options.account || 'user@example.com'}` : '';
  const document = {
    readyState: 'complete', body: { innerText: options.body || options.text || 'Google Ads account selection' },
    querySelectorAll(selector) {
      if (selector === 'multiaccount-view div.no-accounts-container > h2.no-accounts-tag') return options.marker === false ? [] : [marker];
      if (selector === 'ufo-root,.awsm-content-main') return options.shell ? [shell] : [];
      if (selector === 'h1.ufo-page-header') return options.shell ? [heading] : [];
      if (selector === '[aria-label],[title]') return options.unverified ? [] : [avatar];
      return [];
    }
  };
  const location = { protocol: options.protocol || 'https:', hostname: options.host || 'ads.google.com', port: '', pathname: options.pathname || '/nav/selectaccount' };
  return vm.runInNewContext(script, { document, location, getComputedStyle: () => ({ display: 'block', visibility: 'visible', opacity: '1' }) });
}

test('no-account marker is available in any language and on the selection route', () => {
  for (const text of ['You don’t have any Google Ads accounts.', 'ليس لديك حسابات في إعلانات Google', 'Google 広告アカウントがありません']) {
    assert.equal(run({ text }), 'found_no_accounts_verified');
  }
  assert.equal(run({ unverified: true }), 'found_no_accounts_unverified');
});

test('hidden or missing marker, wrong account, untrusted host and challenges do not produce availability', () => {
  assert.equal(run({ hidden: true }), 'waiting');
  assert.equal(run({ marker: false }), 'waiting');
  assert.equal(run({ account: 'other@example.com' }), 'account_mismatch');
  assert.equal(run({ host: 'example.com' }), 'waiting');
  assert.equal(run({ body: 'Verify your identity' }), 'waiting');
});

test('existing Ads signup success remains supported', () => {
  assert.equal(run({ marker: false, shell: true, pathname: '/aw/signup' }), 'found_verified');
});

test('new result uses existing persistence and stage completion flow', () => {
  assert.match(stage, /value == "found_no_accounts_verified"/);
  assert.match(stage, /persistAdsResult\(account, found\)/);
  assert.match(stage, /markStageCompleted\("ads", view, account\)/);
});
